# WKG Realm Pack — project notes for Claude

This folder is Minecraft Bedrock's `com.mojang` folder on the user's Windows PC. The project is the
**WKG Realm Pack**: one behavior pack + one resource pack that combine two addons:

- **Cannabis Craft** (namespace `cc:`) — ours. Growing, breeding, drying, pressing, and smoking custom
  cannabis strains, plus tobacco. This is where nearly all work happens.
- **Farmer's Delight Bedrock** (namespaces `farmersdelight:`, `better_on_bedrock:`) — an unofficial MIT-licensed
  port merged in by the user. **Don't modify it unless the user asks.**

The user plays on a Realm, tests in-game, and reports back. They are not a programmer, so explain changes
in plain language and be clear about what was verified by tests versus what still needs an in-game check.

**Bedrock add-on reference:** `BEDROCK_ADDONS.md` (this folder) — a researched guide to all of Bedrock add-on
development (versions, manifests, items, blocks, entities, attachables, Molang, scripting V2, Realms) plus an audit of
this pack with prioritized recommendations. Read the relevant section before building something new. Include it in
source zips for the other dev.

## Where things are

- Behavior pack: `development_behavior_packs/WKG_Realm_Pack_BP/` (verify the folder name; the user unzipped it)
- Resource pack: `development_resource_packs/WKG_Realm_Pack_RP/`
- Logic tests: `cc_tests/` (see **Testing**)
- The user's original feature list lives in `Drawing Board.txt` if they add it here; the roadmap below reflects it.

Packs in the development folders reload when the world is reopened. No reimport or version bump is needed
while testing locally. Realms need an exported `.mcaddon` (see **Releasing**).

### Key files (BP)
- `scripts/main.js` — entry point; only imports `fd_main.js` and `cc_main.js`
- `scripts/cc_main.js` — **all Cannabis Craft logic** (single file, ~2100 lines)
- `blocks/`, `items/`, `recipes/`, `entities/genetics_marker.json`, `loot_tables/blocks/empty.json`
- `item_catalog/crafting_item_catalog.json` — creative-menu groups
- `typescripts/` — FD's TypeScript source; the game ignores it (could be stripped from release zips)

### Key files (RP)
- `textures/item_texture.json`, `textures/terrain_texture.json`, `blocks.json` (sounds)
- `models/blocks/*.geo.json` — custom block geometry
- `attachables/` — held-item models + raise-to-mouth pose. Joints, blunts and the vape pen are 3D sticks
  (`models/entity/cc_smokable_sticks.geo.json`): one 1-pixel slice per icon column, lying along **z**.
  Learned in-game: in first person **-z is the far end** (toward screen centre), +z is the hand; bone
  rotation applies **x first in the model's own frame**, so rotating a stick about its own long axis just
  spins it (the old "roll" bug); y turns it, x tilts it. A single long UV strip per face came out mirrored
  on some faces, hence the per-column slices. The far end reads as the MOUTH end. Joint/blunt: filter far (fixed at z=-6), lit end near the hand and
  tilted up 20 degrees and turned 90 (idle [-20,90,0], drag to [-20,105,0], set by the user in-game; 105 still landed right of the mouth; 125 went further WRONG, so a LOWER y swings the stick toward the mouth -
  70 was right direction but not far enough; now 50). Hit position z on the stick and vape poses: +3.5 moved
  them AWAY from the mouth in-game, so for these -z = toward the face (the bong's -4 pushed it away - the axis
  differs between them; test each in-game). Sticks -4.5 = "better" (user). Vape needed more: -8.5, plus bone `scale` 0.667
  on both vape poses (user asked for "8x8", i.e. half of full 16x16 size; the geo is already 75%); untested). Vape: mouthpiece far, battery near
  (user-approved), 25% smaller, uses `cc_vape_pen_model.png`; a thinner black mouthpiece tip cube (half thickness, uv column 15) sticks out past the far cap. Poses: `animation.cc.stick.idle/raised`, `animation.cc.vape.idle`,
  `animation.cc.vape.raised` (raised poses must be `hold_on_last_frame`). Bongs use a 3D glass bong
  (`models/entity/cc_bong.geo.json`, downstem + bowl on +x). In held-item space **+y is DOWN on
  screen**, so the bong is modelled upside down (foot at +y, bowl contents on the `down` face; generator mirrors it) with one 32x32 texture per stage
  (`cc_bong_model_empty|packed|s1|s2.png`, bowl colour = contents), posed by `animation.cc.bong.idle/raised`.
  Two bones: `cc_bong_shape` holds the rest orientation [20,-90,0] (x = sideways lean on screen, + = top RIGHT; in-game 15 ~ straight, 30 ~ 18 deg right) (**never name an attachable bone after a player
  bone** like `body`/`head` - a bone named `body` glued the bong to the player's torso/face); animated `root` (pivot [11,6.9,2.6], near the hand) does the hit:
  rotation 0 -> [-30,9.5,46.8] (in-game tuning, 2026-09-27; user: "perfect"), plus position [0,19,0] -> [0,19,-4]
  to push it away from the face (untested guess: -z = away from camera, as with the sticks). Observed on root: z -46.8 tipped it AWAY;
  z +46.8 tipped it toward the camera but fell to the RIGHT (x was +10.8); root x negative moves the top LEFT.
  The renderer does NOT reproduce root z rotations (even with z flipped) - tune the hit in-game, not with it
  (`hit_design.json` still holds the old designed value; the old root x -40 just stood it up straight). Generator: `cc_tools/gen_bong.py`.
  Animation `position` is uncalibrated, so the hit uses rotation about the pivot only. Size 80% (60 too small, 100 too big).
- `cc_tools/pose_study/` (not part of the packs) - a small renderer that previews held-bong poses. `calib.json`
  was fitted to 5 in-game screenshots in `images/` (shape overlap ~89% for 4 of 5; the lean-0 shot is off, and
  in-game lean 15 looked about straight). Checked without refitting against 2 later screenshots it never saw
  (19 = hold at lean 30, 20 = old hit tip -40): 81% / 79% overlap, and it correctly predicted the hit standing straight. Fitted rotation convention: x sign -1, y +1, z -1, x applied first.
  The Python tools need `pip install numpy pillow scipy`; paths are relative to the repo, so they run on any PC.
  Re-render the sheets with `python study.py . .` from that folder (edit the rows in `study.py`); `fit2.py` refits.
- `animations/cc_smokable_pose.animation.json`, `animation_controllers/cc_smokable_pose.animation_controllers.json`
- `sounds/sound_definitions.json` (`cc.smoke_hit` → `sounds/cc/smoke_hit_1|2.ogg`)
- `texts/*.lang` — 7 language files (en_US, es_ES, it_IT, pt_BR, tr_TR, zh_CN, zh_TW)

## Scripting rules (@minecraft/server 2.10.0, @minecraft/server-ui 2.2.0 — stable only, it's a Realm pack)

- Forms use option objects: `.dropdown(label, items, { defaultValueIndex })`,
  `.slider(label, min, max, { valueStep, defaultValue })`, `.textField(label, placeholder, { defaultValue })`,
  `.toggle(label, { defaultValue })`.
- `world.beforeEvents.itemUseOn` **no longer exists** in 2.0 — use `world.beforeEvents.playerInteractWithBlock`.
- Before-events are read-only: never change world state inside them. Do the work in `system.run(...)`.
- FD registers custom components in `system.beforeEvents.startup`. Cannabis Craft doesn't use custom components.
- Every click-triggered action goes through `debounced(player, purpose, ms, fn)`. Interaction events re-fire
  while the button is held, and several events can fire for one click (this once made nutrients get used 4 at a time).
- Always open forms through `showForm(player, form)`. It retries when the game rejects a form as "UserBusy",
  which happens right after a block click.
- Every flow re-verifies inventory slots after a form closes, because the player can move items while it's open.
- Wrap cosmetic calls (particles, sounds) in try/catch so they can never break a gameplay flow.
- **`isValid` is a property in API 2.x, not a method.** `marker.isValid()` threw inside the growth loop's try/catch,
  silently skipping every plant — nothing grew until 2026-09-28. try/catch hides API mistakes; test loops
  (`growPlants` has a suite).
- In form text (titles, bodies, labels, buttons) a lone `%` is swallowed as a format code. Write `%%` to show `%`.

## How Cannabis Craft works

**Genetics registry.** Item dynamic properties only work on items with stack size 1, but seeds and buds stack to 64.
So genetics are stored in a world dynamic property `cc:g:<id>`, where `<id>` is a hash of the canonical genetics
JSON. The item's lore carries a final line `§8#<id>`. Identical genetics give an identical ID, so the items stack.
- `getGenetics(item)` resolves, in order: the lore ID, legacy item dynamic property, or a base seed item type.
- **User rule: no two newly obtained seeds share values** — only harvesting copies a plant's exact genetics.
  Named-strain seeds (`isPureBase`: has `key`, gen 0, not boosted — stats may differ from STRAINS) use their own
  `cc:seed_<key>` item (icon + coloured lang name) with `geneticsLore` (THC, yield/growth, effects, rarity, **ID**).
  `rollStrain(key)` = same name/effects, THC ±20% (0.1 steps), yield ±1, growth ±15%; used for grass drops, rare
  breed discoveries, and (via `describePlayerSeeds` on `playerInventoryItemChange` + join) any **unrolled** seed —
  one with no ID line (crafted, traded, creative, or described by the older no-ID version). A plain stack is rolled
  once as a whole. Harvested seeds of one plant share an ID and stack; fresh rolls don't. Hybrids: `cc:seed_hybrid`,
  THC to 0.1. Rare-breed recipes still work with rolled parents (they check key/gen, not stats).
- Genetics fields: `key, name, color, thc, yieldStat, growth, effects:[[effectId, amplifier]], gen, boosted`.
- Buds carry a state line: `§7State: §bWet` / `§7State: §6Dried`. Rosin: `§7Pressed from: §6Dried buds` / `§bWet buds`.
  `isDried()` just checks whether a lore line contains "Dried".
- Lore limits: max 20 lines, 50 characters per line. Always use `safeSetLore`.

**Strains** (`STRAINS` in cc_main.js; 18 total). Common (craftable from wheat seeds + a dye): og_kush, blue_dream,
sour_diesel, purple_haze, gorilla_glue, green_crack, tysgorilla, tender_lad, purple_nurple.
Breed-only (30% chance when crossing two *pure* parents, see `BREED_RECIPES`): white_widow = blue_dream × green_crack,
purple_punch = purple_haze × purple_nurple, skywalker_og = og_kush × sour_diesel.
Trade-only (no recipe; sold by the Funguy): george_droid, sleepy_joe_og, black_mamba.
Funguy exclusives (rarity `"funguy"`; user wanted effects no other strain has, obtainable only through them - they
can still be bred FROM, passing the effect into hybrids): phantom_cookies (invisibility), poseidon_og (conduit_power),
hero_haze (village_hero). Keep those effects off every other strain.
Hybrids merge both parents' effects, capped at 3 (`breedEffects`; shared effects kept first). **An effect both
parents have at the SAME level gets one level-up roll** (user rule: II + II can make III; I + II just gives II): 50% → II, 25% → III, 12.5% → IV, 6.25% → V
(halves each level, `upgradeChance`), max V (`MAX_EFFECT_AMP` = 4; the THC and live-resin bonuses also cap at V).
The breeding station announces level-ups. Joint/cart blending (`mergeEffects`) never levels effects. Levitation is always 3 seconds (`FIXED_DURATION`).
Effect **duration scales with THC** (`thcDurationMult`): 15% = 1x, 30% = 1.5x, 45% = 2x, 90% = 3.5x;
`FIXED_DURATION` effects ignore it. The amplifier bonus (+1 above 25% THC) is separate.
**Bedrock has no Luck effect** — Purple Nurple uses Regeneration I + Health Boost I instead.

**Plants.** Custom crop blocks `cc:cannabis_plant` (growth 0–4, **tint 0–5**) and `cc:tobacco_plant` (0–3) on farmland.
Textures + the tall model come from `cc_tools/gen_plants.py` (old ones backed up in Documents/WKG_backup_2026-09-27/
plant_textures_old). Young stages use `geometry.cc_plant` (2 planes, 16×16); cannabis 3–4 and tobacco 2–3 use
`geometry.cc_plant_tall` (4 planes, 16×24 textures, 1.5 blocks). The model may be taller than a block, but the
**selection box must stay within 16 px** (the game logs an error otherwise - verified in the content log). Flowering cannabis textures are per tint
(`cc_plant_<3|4>_<green|purple|frosty|dark|golden|red>`); `tintFor(g)` = `STRAIN_TINT` for named strains, name colour
(`COLOR_TINT`) for hybrids, hashed for rainbow. Set on planting and corrected in `growPlants` for older plants.
Each planted crop has an invisible `cc:genetics_marker` entity (family `cc_marker`) with dynamic properties
`cc:crop`, `cc:genetics`, `cc:nutrients`. A 100-tick `runInterval` grows plants (genetics growth multiplier,
+40% on hydrated farmland). Find a plant's marker with `findMarker` (distance ≤ 0.6, `closest: 1`) — a
wider search radius used to grab the neighboring plant's genetics. Crops use an empty loot table; the
script handles all drops. Breaking an immature cannabis plant returns its seed.
**Planting** (`plantedGenetics`): the farmland click records the seed's genetics by location (`plantIntent`) on EVERY
event, including `isFirstEvent === false` repeats (holding right-click plants a row with repeats only - skipping them
gave those plants a random common strain and cost the user bred strains, fixed 2026-09-28). Fallbacks: the seed still
in hand, then the player's last clicked seed (`lastSeedHeld`); random only if nothing is known. `spawnMarker` removes
leftover markers on that spot first (trampled plants leave theirs). `planting` test suite. A finished plant drops its buds plus ALWAYS 1-3 seeds (100%, was 85% - user: too low) with the plant's exact genetics (`HARVEST_SEED_CHANCE`/`_MAX`); grass drops a common seed 5% of the time (`GRASS_SEED_DROP_CHANCE`, user-tuned 2026-09-28).
Bone meal advances one stage. Nutrients (`cc:nutrient_thc|yield|growth`) work at any stage before mature,
max 3 of each per plant, and mark the genetics `boosted`.

**Smoking.** A raise-to-mouth hold (`use_modifiers`: 1s for joint/blunt, 2s for bong). The hit lands on
`itemCompleteUse` → `takeHit(player, heldStack)`. The hit count lives in the item dynamic property `cc:uses`
(the source of truth); `durability.damage` only mirrors it for the wear bar. Each hit swaps to the next
visual stage item (`SMOKE_FAMILIES`: joint 4 hits / 4 stages, blunt 8 / 4, bong 6 / 3), copying the name,
lore, and `cc:smoke` data. A finished joint or blunt disappears; a finished bong reverts to an empty `cc:bong`.
The player property `cc:smoke_stage` drives the continuous smoke particles while holding.
**Offhand smoking:** every smokable stage item has `minecraft:allow_off_hand`. Bedrock only "uses" the main-hand item
(no custom-item offhand use, and no script event for right-clicking air with an empty hand), so the user chose
**double-tap sneak and HOLD** (second press within 8 ticks, held for the family `dragMs`: joint/blunt 1s, bong 2s,
vape 3s; releasing early cancels; `onSneakSample`, fed by `playerButtonInput` Sneak events, with
`tickOffhandHolds` checking only players mid-hold each tick) -> `offhandHit` ->
`takeHit(player, stack, "offhand")` (`smokeSlot` abstracts main hand vs offhand). `cc:smoke_stage` is set during
the hold for the smoke trickle. The client can't see script state, so the attachable controller detects the SAME
input itself (states off_down -> off_up [stores `query.life_time`] -> off_raised within 0.4s) to play
`animation.cc.*.raised_off` (offhand mirror of each main-hand raised end frame, also from offhand_pose.py, solved
near the idle angles so the 0.3s blend doesn't spin). Keep both 0.4s windows in step.
Offhand in FIRST person needs its own pose (the left arm's first-person frame is nowhere near the right's - the item
was invisible). Controller `cc.smokable_pose` idle plays `offhand_fp` when `c.is_first_person && c.item_slot ==
'off_hand'` (animations `animation.cc.stick|vape|bong.offhand_fp`); only the main hand raises to the mouth. Values
come from `cc_tools/pose_study/offhand_pose.py`: vanilla shield main->offhand first-person mapping applied to our
main-hand idles (unverified first guess - tune in-game). Third-person offhand still uses the main-hand idle.

**Stations** (routed through `STATION_BLOCKS` → `openStation`):
- Breeding Station — pick two seeds from dropdowns, optionally name the result, and pick a **name color**
  (`NAME_COLOR_CHOICES`: keep parent / 16 bright colors / Random / Rainbow). Rare strains keep name and color.
  `g.color` is a § code or `"rainbow"`; ALWAYS print strain names via `strainName(g)` (per-letter rainbow, then §f),
  never `${g.color}${g.name}`.
- Rolling Table — the held item decides the product (`SMOKE_INPUTS`, each with an `accepts` list): rolling paper →
  joint (≤4 strains), tobacco leaf → blunt (≤8), empty bong → packed bong (≤6, buds and/or shatter/wax; all
  concentrates = named "Dab"), empty cartridge → filled cart (≤3, distillate/live resin). One item per chosen strain.
- Drying Rack — up to 16 buds, each batch with its own real-time start (`DRY_MS` = 2 min). Storage lives in the
  world property `cc:rack:<dimId>:<x>,<y>,<z>`, and `cc:racks` indexes all racks. Block state
  `cc:status` 0/1/2 = empty/drying/done. A 40-tick interval updates visuals and drops contents if the rack
  was destroyed some other way (explosions, etc.).
- Nug Press — block states `cc:plate` 0–4 (none/copper/iron/diamond/netherite) and `cc:pressing`.
  Shift + left-click (`entityHitBlock` while sneaking) installs, swaps, or removes the plate, and
  `beforeEvents.playerBreakBlock` cancels sneak-breaking so creative players don't destroy it. Rosin per bud:
  20/33/50/70%, rounded probabilistically; 4-32 buds per press (same strain + state, pulled from any slots); 2-second press animation
  (lowered geometry). Breaking the press drops its plate.
  Rosin THC is 65-75% (`rosinThc`): higher with stronger buds, better plates, and dried buds. It is deterministic
  so identical presses stack. `makeRosinItem(g, ...)` takes the *rosin* genetics (already at rosin THC).
- Distiller — one batch at a time: 1–16 rosin of one strain + 1 fuel item → a concentrate (`DISTILL_PROCESSES`):
  wax (coal/charcoal, 1 min, 100%, THC 70-80), shatter (blaze rod, 2 min, 90%, 75-85), live resin
  (magma cream, 3 min, 75%, 72-82, every effect +1 level), distillate (ender pearl, 5 min, 60%, 90-99.9).
  Product THC = the rosin's place in 65-75% scaled onto that range, to 1 decimal.
  Dried rosin yields ×1.25. Output is rolled at start. Storage `cc:still:<dim>:<x>,<y>,<z>`, index `cc:stills`,
  `cc:status` 0/1/2 = idle/working/done (working glows). Stop mid-batch or break it → rosin + fuel back;
  break when done → concentrate drops. Concentrates carry genetics via lore ID like buds.
- Tobacco products (`cc_tools/gen_cigarettes.py` draws icons + writes items/recipe/attachables/lang):
  the Drying Rack also takes tobacco leaves (batch id `TOBACCO_BATCH` = "tobacco") → `cc:dried_tobacco`.
  `cc:cigarette` = rolling paper + dried tobacco (x2), **stack 16**, family `cigarette` (1 hit; takeHit takes one off
  a stack). `cc:cigarette_pack` "Marlboro Reds (12)" (+ _s1.._s3 stages, 12 hits): crafting grids only hold 9, so it's
  packed at the Rolling Table - red dye in hand + 12 cigarettes + 1 paper in the inventory (`packCigarettes`).
  Both give ONLY Swiftness I via the family's `defaultSmoke` (they carry no strain data). Single cigarette held
  model = the joint's stick geometry/poses with texture `cc_cigarette`. The **pack** has its own animated model (`cc_tools/gen_pack_model.py`): the pack box STAYS in the hand; on a hit the cigarette inside (`cc_pack_cig`) slides fully out of the lid (0-0.3 s), is hidden, and a second cigarette (`cc_pack_held_cig`, the joint's stick geometry under root) appears and follows the JOINT's tuned idle -> raised poses to the mouth (0.3-0.65 s; offhand uses the joint's offhand poses). Poses are solved as child-of-root transforms so they land exactly where the joint does. Pack modelled upside down like the bong. **Lit packs:** after a hit the pack becomes its lit twin (`cc:cigarette_pack_lit[_sN]`, family `litStages`) whose attachable parks the cigarette at the mouth (`animation.cc.pack.lit|lit_off`, no take-out animation). `revertLitPacks` (hotbar-change event + 10-tick scan) turns any lit pack NOT in the selected slot or offhand back to normal, keeping `cc:uses` + wear. Packs hold 3 s (use_duration 3.0, dragMs 3000). Generator order: `gen_cigarettes.py` -> `gen_pack_model.py` -> `gen_third_person.py` (each rewrites parts of the attachables/controller the next one depends on).
  **Third person:** all first-person poses looked huge in third person. The controller now plays `third` / `third_off` / `third_raised` whenever `!c.is_first_person` (`cc_tools/gen_third_person.py`, one place for all numbers): items at 45% size in hand; during a hit (and always for a lit pack) sticks/vape/cigarette go to the mouth (hand->mouth offset now (+1.5, +11.5, -5.5): tuned from a screenshot (the model estimate +6/+10.5 was ~4.5 px left of the mouth), x mirrored for the left hand); the bong stays in hand tipped 25 degrees. UNCALIBRATED first guess - tune from screenshots. Positions in the HAND frame don't map to the body (the held arm is raised), so the pack's third-person cigarette is a separate bone `cc_mouth_cig` with `"binding": "'head'"` - it rides the head: `LIPS` [-1.5, 25.5, -4.5] (corner of the mouth, user-tuned; +24 like the hand binding's offset), drooping 20 degrees and angled 20 toward the viewer's left ([-20,200,0]; DROOP/YAW in gen_third_person.py), only shown in third person. If it works, use the same head-binding trick for joints/blunts/vape at the mouth..
- Vapes — filled carts (`cc:cart_filled`, stack 16) store their strain blend as a genetics record (lore ID) plus a
  `§7Contents:` lore line. Vape Pen = shapeless craft of Vape Battery + filled cart. Crafting can't carry data,
  so `watchCarts` (every 10 ticks) notices a filled cart leaving the inventory and a blank pen appearing and
  copies the cart into the pen (`cc:smoke`). No match (e.g. cart taken straight from a chest into the grid) →
  "Unknown" 90% pen. Pen = `SMOKE_FAMILIES.vape`: 16 hits (3-second drag each), then reverts to `cc:vape_battery`.
  Oil stages: `cc:vape_pen` -> `_s1` -> `_s2` -> `_s3` every 4 hits (items, attachables, icons + model textures;
  textures made by `cc_tools/gen_vape_stages.py` from the full-pen textures - rerun it if those change).

## Content conventions (learned the hard way)

- Items: `format_version` "1.21.90"; `"minecraft:icon": "cc:<name>"` as a **bare namespaced string** that
  matches a key in `item_texture.json`. The old `{ "texture": "short_name" }` form showed blank icons.
- Every cc item has `"minecraft:display_name": {"value": "item.cc:<name>.name"}`: without it the game (1.26.5x,
  min_engine 1.26.50) showed the raw key `item.cc:seed_sleepy_joe_og` instead of the lang name. Add it to new items.
- Same for blocks: every cc block has `"minecraft:display_name": "block.cc:<name>.name"` (a plain string).
- **Guide book:** every player gets a signed written book ("Cannabis Guide") on first spawn (player property
  `cc:guide_given`); a plain book used on a Breeding Station trades for a new copy. Pages: `scripts/cc_guide.js`
  (pure data, strain pages generated from STRAINS; limits 50 pages / **256 UTF-8 BYTES** per page (§ = 2 bytes, glyph = 3;
  a 240-char page was rejected in-game with BookPageContentError) / title 16 -
  the `guide` test suite enforces them). Icons are glyph characters U+F400+: `cc_tools/gen_guide_glyphs.py` writes
  RP `font/glyph_F4.png` AND `scripts/cc_glyphs.js` (never edit by hand). Book paper is cream: dark § colours and
  dark glyphs only. When mechanics change, update the guide text too.
- **Breeding Station** is a machine model from `cc_tools/gen_breeding_station.py` (64×64 per-face UV, control panel
  on the model's SOUTH face, placement_direction rotations like the distiller - facing unverified in-game).
- `cc_tools/render_geo.py <geo> <texture> <out>` previews any block model (north/south/side/top). The nug press
  lowered model stretches the screw to 12px: its texture strip (x28-29) must be ≥12 rows (was 8 - screw vanished).
- Seed names are coloured per effect (each word of the strain name = one effect's § colour, bright shades only -
  the tooltip is dark), written into all 7 lang files by `cc_tools/gen_seeds.py` (EFFECT_CODE / NAMES). Lang colour
  codes keep every copy identical, unlike nameTags.
- Never use string `saturation_modifier` ("normal"/"low") — it's invalid since 1.20 and blanks the item. Use numbers.
- Don't invent creative-menu group IDs. Items set `menu_category.group` to one of:
  `cc:itemGroup.name.seeds`, `.produce`, `.smoking`, `.growEquipment`. Blocks are listed in
  `crafting_item_catalog.json` instead.
- Lang keys: `item.cc:<name>.name=...` and `block.cc:<name>.name=...` (not `tile.`). Add new keys to **all 7** lang files.
- Block geometry uses **centered coordinates** (-8..8 on x/z, 0..16 on y). Corner-based coordinates shifted the
  plant half a block off-center.
- Never use `minecraft:transformation` **scale** on crops — it scales around the center and makes plants float.
  Rotation transforms are fine; facing = `minecraft:placement_direction` trait + rotation permutations.
- Custom-geometry blocks use 32×32 textures with per-face UV regions. Items are 16×16. Textures are generated with
  Python/PIL. There is no art pipeline, so draw them in code, then render a preview and look at it.
- Seed icons come from `cc_tools/gen_seeds.py`: green wheat-style kernels, a few tipped with each strain's effect
  colours (its own copy of the strain→effects list - update it when STRAINS changes). Hybrids share one mixed icon.
- After making block geometry, verify it by rendering a front and top view from the `.geo.json` + texture
  (crop each face's UV region, paste it at the cube's position) and viewing the image.
- Recipes: planks can use `{ "tag": "minecraft:planks" }`, logs `{ "tag": "minecraft:logs" }`. There's no reliable
  fence tag, so the drying rack has one recipe per wood type.
- Recipes with `format_version` 1.20+ **must** have `"unlock": [{ "item": "<ingredient>" }, ...]` (any one unlocks it),
  or the content log errors "1.20+ Recipes require unlock data". The older recipes use 1.19.0 and don't need it.
- Bedrock effect IDs used: speed, haste, strength, jump_boost, regeneration, resistance, fire_resistance,
  water_breathing, night_vision, absorption, saturation, levitation, slow_falling, blindness, mining_fatigue, health_boost.

## Testing

Requires Node.js on the PC. From `com.mojang`:

```
node cc_tests/run_tests.mjs        # add -v to see every PASS line
```

The runner copies `cc_main.js`, exports its internals, and runs every suite in `cc_tests/suites/` against fake
`@minecraft/server` / `server-ui` modules in `cc_tests/node_modules/@minecraft/`. Suites cover genetics and
stacking, breeding and rare rates, rolling and strain limits, smoking stages, the drying rack (with a faked clock),
the nug press (plates, pressing, per-tier yield rates), THC durations and rosin THC, and Phase 4 (distiller,
dabs, carts, vape-pen linking).

- Run the tests before telling the user something is done.
- When adding a feature, add a suite, and add any new functions to `exportsLine` in `run_tests.mjs`.
- If a test fails, check whether the test or the script is wrong before changing the script. Freed inventory
  slots get refilled by new items, which has fooled tests before.
- The fakes are simple: add stub methods as new APIs get used (e.g. `ActionFormData`, `dimension.playSound`).
- Also validate every JSON file, and check that every icon, texture, geometry, and lang reference resolves to a
  real file or key.
- Tests can't check rendering or real engine behavior. Say so, and ask the user to check in-game.

## Releasing

Before any release run `node cc_tools/audit.js` (deep cross-reference + Bedrock-limit + Realm check; must say
"No errors"; its WARNs are known-harmless: FD's lenient ui JSON, vanilla crop textures, other add-ons' loot tables) and
`node cc_tests/run_tests.mjs`.

`python cc_tools/build_release.py --bump 1.2.4` (released **1.2.3** on 2026-09-28 - planting fix + 100% harvest seeds → next 1.2.4 / 1.3.0). It bumps both manifests' header
versions and their cross-dependencies (Realms cache by version), then writes `releases/WKG_Realm_Pack_BP.mcpack`,
`_RP.mcpack` and `WKG_Realm_Pack_v<version>.mcaddon`, leaving out `typescripts/` and caches. Without `--bump` it
rebuilds at the current version. Bumping the dev packs' version is fine; ask before doing it (it's the Realm step).

Before releasing, test in a world with **no experiments** — the user's test world has Beta APIs + Upcoming Creator
Features switched on, a Realm usually doesn't, so experiment-only content would work locally and fail there.

## Roadmap (from the user's Drawing Board)

Done: Phase 1 (strains, stacking, tobacco, joints/blunts/bongs), smokable stage textures, detailed rolling table,
Phase 2 (drying rack), Phase 3 (nug press), Phase 4 (distiller, dabs, carts, vape pens; distiller recipe
GGG/IFI/ICI = glass/iron+furnace/iron+cauldron). The user's own additions: API 2.0 port, hold-to-smoke, smoke sound
and particles, attachables with a raise pose, the FD merge.

**Phase 5 — Funguy trader (built 2026-09-28, untested in-game).** Custom entity `cc:funguy` (BP `entities/funguy.json`,
RP `entity/funguy.entity.json`, own geometry/texture/animations from `cc_tools/gen_funguy.py`; arms folded via
`animation.cc.funguy.pose` [-45,0,0]; face is COPIED texel-by-texel from the user's screenshot of a vanilla villager (`FACE` grid in gen_funguy.py, colours sampled +10% for lighting; eyes on row 6, nose cube origin y23 right under them). Cap brim at y30 (user-tuned; 1 forehead row shows above the brow)). Spawns as a **resident** by default (spawn egg; `cc:resident` group: home
radius 24, persistent, table `trading/cc_funguy_resident.json`, 32 uses). Event `cc:as_wanderer` swaps
to `cc:wanderer` (despawn timer 30-40 min, table `cc_funguy_wanderer.json`, 8 uses). User rule: every Funguy rolls
his own random stock, **max 6 trades** = the shatter buy + 3 random seeds + 2 random gear (same picks both tables).
The seed pool holds EVERY strain (user asked): common 3, breed-only 10, trade-only 8, exclusive 16 emeralds.
Add new strains to `gen_funguy_trades.py` too. Both tables come
from `cc_tools/gen_funguy_trades.py` (edit prices there). Script (Funguy section of cc_main.js, 1-min interval):
a village (3+ villager_v2 within 48 of a player) rolls ONCE (30%; was 60% - user: too frequent) for a resident, recorded in world prop
`cc:funguy_villages` (96-block spacing); a dead resident frees his village. Wanderer: once per in-game day, 10% (was 35% - too frequent),
spawns 16-28 blocks from a random overworld player, one at a time. User chose: keep the nug press recipe (also sold).
Trades: shatter -> 2 emeralds; trade-only + exclusive seeds; drying rack, nug press, copper/iron plates, papers, carts
(user set: 2 rolling papers = 6 emeralds, 1 empty cart = 8). Hero of the Village discount WORKS (user-verified,
16 -> 12): it comes from the modern price formula acting on each trade's `price_multiplier` 0.05
(`hero_demand_discount` is legacy-formula-only and was removed). Like villagers, prices can creep up with demand.
In-game unknowns: whether trades accept shatter with custom name/lore, `move_towards_home_restriction` behaviour,
arm pose direction.

**Phase 6 — Custom animations** for the bong and joint. Part of this exists (the attachable raise pose). A
player-skeleton pose was removed because it broke Persona skins — keep any new pose Persona-safe.

**Unverified in-game:** whether `%%` renders as `%` in forms (the press and distiller use it; the rack, breeding
and rolling forms still use a single `%`), and the distiller's facing (firebox modelled on the south face).

**Third-party content in the RP** (credited in `CREDITS.txt`): Low Fire V1.0.9 (GPL-3.0, `LICENSE_LowFire.txt`) -
its "Default" height fire/soul-fire textures replace vanilla `textures/blocks/fire_0|1`, `soul_fire_0|1`. Its other
heights (0-15, subpacks) were not added. Don't merge paid Marketplace packs (e.g. Actions & Stuff) - the user
was told to run those as separate packs.

**Sun texture:** the user asked for a custom sun (a face photo, background removed with OpenCV GrabCut + a
hand-traced hairline) - RP `textures/environment/sun.png`, 128×128 with transparency, stored ROTATED 180° (the sky draws sun.png upside down - user-verified). How the sky renders it
(blending, Vibrant Visuals) is unverified in-game. Delete that file to get the vanilla sun back.

**Housekeeping done 2026-09-28** (the `BEDROCK_ADDONS.md` recommendations): script modules 2.10.0 / server-ui 2.2.0,
`min_engine_version` 1.26.50 on both packs (game is 1.26.52), offhand sneak via `playerButtonInput`, Funguy village
list capped at 800 (`FUNGUY_VILLAGE_MAX`), `textures/textures_list.json` from `cc_tools/gen_textures_list.py`
(rerun after adding textures), FD's orphan earthworm texture drawn, release builder, Vibrant Visuals texture sets
(`cc_tools/gen_pbr.py`: distiller, press, bong and vape models; RP has `"capabilities": ["pbr"]`). Not done: block
storage on the block itself (`block_entity` dynamic properties aren't in the stable script API yet).
FD's `ui/cooking_pot.json` has a JSON comment/trailing comma the game tolerates.
User verified all of it in-game on 1.26.52, including in a world with NO experiments (2026-09-28).
