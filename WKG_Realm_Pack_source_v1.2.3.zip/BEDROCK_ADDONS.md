# Minecraft Bedrock Add-On Development — Reference

Researched 2026-09-28 against the official Microsoft creator docs (learn.microsoft.com/minecraft/creator), the
community Bedrock Wiki (wiki.bedrock.dev), bedrock.dev, and the `@minecraft/server` npm package. Part 1 is a general
guide; Part 2 applies it to the WKG Realm Pack. Things marked **(verify)** are documented but untested by us.

Game at time of writing: stable **1.26.52** (Mojang now numbers releases 1.26.x / "26.x"). Latest stable script API:
**`@minecraft/server` 2.10.0** (2.11.0 in beta/RC).

---

# Part 1 — General guide

## 1. What an add-on is

| Piece | Folder | Does |
|---|---|---|
| **Behavior pack (BP)** | `development_behavior_packs/` | Logic: items, blocks, entities (server side), recipes, loot, trading, spawn rules, world gen features, functions, **scripts** |
| **Resource pack (RP)** | `development_resource_packs/` | Looks & sound: textures, models, animations, client entities, attachables, particles, sounds, UI, language files |

- An **add-on** = a BP + RP that depend on each other. Ship as `.mcpack` (one zipped pack, `manifest.json` at the zip
  root) or `.mcaddon` (a zip holding several `.mcpack`s).
- `development_*` folders reload their content when a world is reopened; `/reload all` reloads scripts and most
  content in-game without restarting.
- Windows (GDK build) path: `%APPDATA%\Minecraft Bedrock\Users\Shared\games\com.mojang`.
- Turn on **Settings > Creator > Content Log** (file + GUI) — it is the only place most JSON errors show up.

## 2. Versions — there are four different kinds

1. **Game version** (1.26.52). What players run. Realms always run the latest release.
2. **`min_engine_version`** in the manifest header. Also selects *behavior semantics*: Molang operator precedence
   (changed 1.18.20), `block_property`→`block_state` (1.20.10) etc. Changing it can change how old content behaves.
3. **`format_version`** in every JSON file. Unlocks the components/fields available for that file type.
   Use a recent one per file type; old ones silently lose fields (e.g. item icon syntax changed; recipes ≥1.20 need
   `unlock`).
4. **Script module versions** in manifest `dependencies` (semver, *not* game versions).

`@minecraft/server` → game (from Microsoft's table; 2.x continues one minor per release):

| module | game | module | game |
|---|---|---|---|
| 1.0.0 | 1.19.70 | 1.11.0 | 1.21.0 |
| 1.4.0 | 1.20.20 | 1.13.0 | 1.21.20 |
| 1.8.0 | 1.20.60 | 1.17.0 | 1.21.60 |
| 1.10.0 | 1.20.80 | 2.0.0 | 1.21.80 (V2 stable) |
| … | … | **2.10.0** | current stable (1.26.5x) |

Rules: stable minor bumps are backwards compatible (a pack asking for 2.0.0 runs on any 2.x game); a *major* bump
(1→2) can break code; `-beta` versions need the **Beta APIs** experiment, break every release, and should not be used
for a Realm pack. Microsoft recommends depending on the newest stable version available when you release.

## 3. Manifest essentials

```json
{ "format_version": 2,
  "header": { "name": "...", "description": "...", "uuid": "<unique>", "version": [1, 2, 0],
              "min_engine_version": [1, 21, 110] },
  "modules": [ { "type": "data", "uuid": "<unique>", "version": [1, 0, 0] },
               { "type": "script", "language": "javascript", "entry": "scripts/main.js", "uuid": "<unique>", "version": [1, 0, 0] } ],
  "dependencies": [ { "uuid": "<RP header uuid>", "version": [1, 2, 0] },
                    { "module_name": "@minecraft/server", "version": "2.0.0" } ] }
```
- Every UUID unique, never reused between packs. RP module type is `resources`.
- `capabilities: ["pbr"]` in the RP for Vibrant Visuals texture sets; `subpacks` for player-selectable variants
  (Low Fire uses them for fire height); `format_version: 3` is current but 2 still works.
- Both packs want `pack_icon.png`, `texts/languages.json`, and `texts/*.lang` (`pack.name`, `pack.description`).

## 4. Items (BP `items/`)

Key components (full list: wiki.bedrock.dev/items/item-components):

| Component | Shape / note |
|---|---|
| `minecraft:icon` | `"ns:key"` → key in RP `textures/item_texture.json` |
| `minecraft:max_stack_size` | int. **Item dynamic properties only work on stack size 1.** |
| `minecraft:use_modifiers` | `{use_duration, movement_modifier}` — hold-to-use time |
| `minecraft:use_animation` | `eat` / `drink` / `brush` / `spear` / `none` |
| `minecraft:durability` | `{max_durability, damage_chance}` |
| `minecraft:food` | `{nutrition, saturation_modifier: <number>}` (string values are invalid since 1.20) |
| `minecraft:allow_off_hand` | `true` or `{ "value": true }` — lets it sit in the offhand. **Custom items can't be "used" from the offhand.** |
| `minecraft:block_placer` / `entity_placer` | `{block/entity, use_on: [...]}` |
| `minecraft:cooldown`, `wearable`, `throwable`, `projectile`, `shooter`, `digger`, `enchantable`, `repairable`, `fuel`, `compostable`, `storage_item`, `record`, `rarity`, `glint`, `hover_text_color`, `swing_duration`, `tags` | as named |

- Creative menu: `description.menu_category` `{category, group}`; blocks go in `item_catalog/crafting_item_catalog.json`.
- Custom behavior: **custom components** registered from script in `system.beforeEvents.startup`
  (`itemComponentRegistry.registerCustomComponent`). V2 flattens them (`"ns:comp": {params}` directly in
  components, `minecraft:custom_components` deprecated) and passes JSON params to the script.
- Gotchas: custom food can always be eaten when full (MCPE-178647); storage items need stack size 1.

## 5. Blocks (BP `blocks/`)

- Main components: `geometry`, `material_instances`, `collision_box`, `selection_box`, `destructible_by_mining`,
  `destructible_by_explosion`, `loot`, `light_emission`, `light_dampening`, `map_color`, `placement_filter`,
  `transformation`, `tick`, `crafting_table` (custom crafting table with its own recipe tag), `redstone_*`,
  `liquid_detection`, `flammable`, `friction`, `display_name`, `tags`, `item_visual`, `movable`, `replaceable`,
  and **`block_entity` `{ "dynamic_properties": true }`** — lets a block store dynamic properties itself (new; **verify**
  format version).
- **Books:** 50 pages, 256 UTF-8 *bytes* per page (not characters - § is 2 bytes, private-use glyphs 3).
- **Limits:** geometry ≤ 30×30×30 px, within ±30 px of origin, at least 1 px inside the block; **selection box**
  origin + size must stay within (-8,0,-8)..(8,16,8) - one block, verified by a content-log error when a tall crop
  used 23 px; collision boxes may reach y 24 (per the wiki); ≤ 16 collision boxes; all material instances must share
  a render method; ≤ 100 queued ticks per chunk per tick.
- **States:** bool / int / string list, namespaced, ≤ 16 values each (int range max−min ≤ 15). Every combination is a
  *permutation*; `permutations: [{condition: "q.block_state('ns:s') == 1", components: {...}}]`. Script:
  `block.permutation.getState()`, `.withState()` + `block.setPermutation()`.
- **Traits** inject standard states: `placement_direction` (cardinal facing), `placement_position` (face / half),
  `connection`, `multi_block`.
- Geometry uses centered coords (x/z −8..8, y 0..16). Don't `transformation`-scale crops (scales about center).

## 6. Entities

**BP side** (`entities/*.json`): `description` (identifier, `is_spawnable` → auto spawn egg, `is_summonable`,
`properties`), `components` (always on), `component_groups` (bundles switched on/off by events), `events`
(`add`/`remove` groups, `sequence`, `randomize`, `filters`, `set_property`, `trigger`). You can't invent
components — only Mojang's.
- **Entity properties** (`description.properties`): bool/int/float/enum with `client_sync: true` to read them in
  RP Molang (`q.property('ns:p')`). The clean way to send server state to animations. Setting via events or
  `entity.setProperty()`. **Overriding `player.json` to add properties is strongly discouraged** (breaks other packs,
  Persona and updates).
- **Spawn rules** (`spawn_rules/`): `population_control`, conditions like `spawns_on_surface`, `biome_filter`,
  `brightness_filter`, `density_limit`, `weight`, `herd`, `height_filter`, `delay_filter`, `is_persistent`, and
  **`minecraft:player_in_village_filter`** (spawn only near a player in a village).
- **Trading:** `minecraft:economy_trade_table` (`table`, `display_name`, `new_screen`, `persist_trades`,
  `cured_discount`, `max_cured_discount`, `use_legacy_price_formula` (default false),
  `hero_demand_discount` (default −4, **legacy formula only**)). Trade file: `tiers[{total_exp_required, groups[
  {num_to_select, trades[{wants[{item, quantity, price_multiplier}], gives[...], max_uses, trader_exp,
  reward_exp}]}]}]`. `num_to_select` picks random trades per entity; picks persist on that entity.
  `minecraft:trade_resupply` restocks.
- Common behaviors: `behavior.random_stroll`, `look_at_player`, `panic`, `avoid_mob_type`, `trade_with_player`,
  `look_at_trading_player`, `float`, `home` + `behavior.move_towards_home_restriction`, `timer` (+ `instant_despawn`).

**RP side** (`entity/*.entity.json`): client entity = materials, textures, geometry, animations, animation
controllers, render controllers, `spawn_egg` colours/texture.

## 7. Models, animations, Molang, attachables (RP)

- **Geometry** (`models/entity/*.geo.json`, format 1.12+/1.16): bones (name, parent, pivot, rotation, cubes with
  origin/size/uv or per-face UV, inflate, mirror). Box UV layout per cube `(w,h,d)` at `(u,v)`: top `(u+d, v)`,
  bottom `(u+d+w, v)`, sides row at `v+d`: east `u`, north(front) `u+d`, west `u+d+w`, south(back) `u+2d+w`.
- **Animations**: per-bone `rotation`/`position`/`scale`, keyframed or Molang expressions; `loop`,
  `hold_on_last_frame`, `animation_length`, `override_previous_animation`.
- **Animation controllers**: state machines (`initial_state`, `states{animations, transitions, on_entry, on_exit}`).
  Animations inside a state can be conditional `{ "anim": "molang" }`.
- **Molang scopes:** `q.` read-only game queries, `v.` per-entity read/write variables, `t.` temporary, `c.` context
  (e.g. `c.is_first_person`, `c.item_slot`). Useful queries: `q.is_sneaking`, `q.is_using_item`, `q.life_time`,
  `q.anim_time`, `q.modified_move_speed`, `q.modified_distance_moved`, `q.target_x_rotation`/`target_y_rotation`,
  `q.is_item_name_any`, `q.get_equipped_item_name`, `q.property`, `q.block_state`. Trig is in degrees.
- **Attachables** (`attachables/*.json`): 3D held items. Root bone `"binding": "q.item_slot_to_bone_name(c.item_slot)"`
  ('main_hand' → rightitem, 'off_hand' → leftitem). Queries evaluate on the **owning entity**. First and third
  person need different poses, and **first-person off-hand needs its own pose** — the left arm's first-person frame is
  far from the right's (vanilla shield: main `pos[5.3,26,0.4] rot[91,65,-43]`, off `pos[-13.5,-5.8,5.1]
  rot[1,176,-2.5]`, pivot `[1,15.5,3]`, chosen with `c.item_slot == 'off_hand'`). Never name a bone after a player
  bone (`body`, `head`, …). Use `controller.render.item_default` for enchant glint.
- **Render controllers** pick geometry / materials / textures (can layer several textures, hide parts).

## 8. Textures, sounds, particles, text, UI

- `textures/item_texture.json` (items), `textures/terrain_texture.json` (blocks), `textures/flipbook_textures.json`
  (animated blocks — replacing a vanilla texture file keeps vanilla's flipbook), optional `textures/textures_list.json`
  (texture cache; missing entries can cause content-log warnings). PNG or TGA.
- **Vibrant Visuals / PBR:** `*.texture_set.json` beside a texture: `color`, `metalness_emissive_roughness` (R=metal,
  G=emissive, B=roughness; image or uniform `[r,g,b]`), optional `normal` or `heightmap`; RP manifest needs
  `"capabilities": ["pbr"]`. Without texture sets, content still renders, just flat.
- Sounds: `sounds/sound_definitions.json` (events → files), `sounds.json` (entity/block/interactive sounds),
  `blocks.json` (block sound types). Particles: `particles/*.json` (emitters, Molang-driven).
- Text: `texts/<lang>.lang`, `key=value`; items `item.ns:name.name`, blocks `block.ns:name.name` (or `tile.`),
  entities `entity.ns:name.name`, spawn eggs `item.spawn_egg.entity.ns:name.name`.
- **JSON UI** (`ui/*.json`, `_ui_defs.json`, `modifications` ops) can restyle HUD and script forms, but conflicts
  with other UI packs and is being replaced by Ore UI — use sparingly.

## 9. Recipes, loot, world generation

- **Recipes:** `recipe_shaped`, `recipe_shapeless`, `recipe_furnace`, `recipe_brewing_mix`/`_container`,
  `recipe_smithing_*`. Fields: `description.identifier`, `tags` (`crafting_table` or a custom table's tag),
  **`unlock` (required when format_version ≥ 1.20)**, `priority`, ingredients by `item` or `tag`. **Results can't
  carry lore/NBT/dynamic properties** — use script to "fix up" crafted items.
- **Loot tables:** `pools[{rolls, entries[{type:item, name, weight, functions}], conditions}]`; functions
  `set_count`, `set_name`, `set_lore`, `set_data`, `enchant_randomly`, `looting_enchant`; conditions
  `random_chance`, `killed_by_player`, `random_chance_with_looting`. Referenced by entities, blocks, chests, `/loot`.
- **World gen:** *features* (what: `single_block`, `ore`, `scatter`, `tree`, `structure_template` for
  `.mcstructure`, `aggregate`, `weighted_random`, `search`, `snap_to_surface`, `geode`, `vegetation_patch`,
  `growing_plant`, carvers) + *feature rules* (where: biome filters, placement pass). `multiface`/`sequence` are
  buggy; big structures must be sliced; structures don't auto-waterlog.

## 10. Scripting (`@minecraft/server`)

- **V2 (2.x) early execution:** your script's top level runs *before the world exists*. Only subscribing to events,
  `system.run*`, and custom-component registration are allowed there. World access goes in
  `world.afterEvents.worldLoad` or later ticks. `system.beforeEvents.startup` replaces
  `world.beforeEvents.worldInitialize`. Removed in V2: `itemUseOn` (use `playerInteractWithBlock`),
  `runCommandAsync` (use `runCommand` / `system.runJob`). `isValid` is a property; component getters throw on invalid
  entities; effect `typeId`s include `minecraft:`.
- **Events:** before-events are read-only and cancellable (defer changes with `system.run`); after-events report what
  happened. Useful: `playerInteractWithBlock/Entity`, `playerBreakBlock`, `playerPlaceBlock`, `entityHitBlock/Entity`,
  `entityDie`, `entityHurt`, `itemUse`, `itemStartUse`/`StopUse`/`ReleaseUse`/`CompleteUse`,
  `playerButtonInput` (Jump/Sneak button changes), `playerSwingStart` (arm swings, incl. air),
  `entityStart/StopSneaking`, `playerInventoryItemChange`, `playerHotbarSelectedSlotChange`, `worldLoad`,
  `scriptEventReceive` (`/scriptevent`). Check the version each arrived in before relying on it.
- **Scheduling:** `system.run`, `runInterval(fn, ticks)`, `runTimeout`, `runJob(generator)` (spread heavy work),
  `waitTicks`. 20 ticks = 1 s.
- **Dynamic properties** (world / entity / stack-size-1 items / block entities): string ≤ 32,767 chars, number,
  boolean, Vector3. First read returns `undefined`. Stored per pack in the world `db`.
- **Forms** (`@minecraft/server-ui`): `ActionFormData`, `ModalFormData` (2.0 uses option objects:
  `dropdown(label, items, {defaultValueIndex})`, `slider(label, min, max, {valueStep, defaultValue})`, …),
  `MessageFormData`. Forms can be rejected with "UserBusy" — retry. `%` in form text is a format code (write `%%`).
- **Modules:** `@minecraft/server`, `server-ui` (stable, work on Realms); `server-gametest` (testing);
  `server-net` and `server-admin` (**BDS only, not Realms**); `debug-utilities` (dev only).
- **Performance / watchdog:** long ticks trigger "slow script" warnings and can terminate scripts. Avoid per-tick
  heavy work, broad `getEntities` scans, and commands in loops; cache, use `runJob`, bigger intervals.
- Type definitions: `npm i @minecraft/server@<version>` for editor autocomplete matching your manifest version.

## 11. Realms & distribution

- Realms cache packs by **header version** — bump `header.version` (and dependency versions) every upload.
- Upload by applying packs to the world (or uploading a world that has them); `.mcaddon` for players.
- Stable APIs only; Beta APIs experiment is a per-world toggle and makes the world "experimental".
- `server-net`/`server-admin` unavailable on Realms. Realms run the newest game version, so players must update.

## 12. Tools & workflow

VS Code (Blockception "Minecraft Bedrock Development" extension; JSON schemas), **Blockbench** (models, animations,
Bedrock entity/attachable/block formats), **bridge.** (IDE with scaffolding, UUIDs), **Regolith** (build
pipeline/filters), npm type definitions, Content Log + `/reload all`, the Script debugger (VS Code attach).

## 13. Community rules & licensing

- Minecraft's Usage Guidelines allow making and sharing add-ons; you may not sell them outside the Marketplace or
  redistribute Mojang's or other creators' paid content. Marketplace packs are licensed per player — never merge
  them into a shared pack.
- Respect each third-party pack's license (MIT: keep notice; GPL-3.0: keep license, share source — packs are
  source, so shipping the files + license satisfies it).

---

# Part 2 — The WKG Realm Pack against this

Audit 2026-09-28. Tests: 9 suites pass. JSON: all ours valid (FD's `typescripts/tsconfig.json` and
`ui/cooking_pot.json` contain comments/trailing commas — the game tolerates them).

## Already right
- Manifests: unique UUIDs, BP↔RP dependency, stable modules only (`@minecraft/server` 2.10.0, `server-ui` 2.2.0) —
  Realm-safe. 7 language files in both packs; `languages.json` present.
- V2 rules followed: no world access at load, `playerInteractWithBlock` instead of `itemUseOn`, before-events defer
  work via `system.run`, forms retried on UserBusy.
- Recipes: all 1.21.0 recipes now have `unlock`; older ones are 1.19.0 (no unlock needed).
- No `player.json` override (Persona-safe); no `minecraft:custom_components` in Cannabis Craft content.
- Attachables: bone names avoid player bones; offhand first-person pose added; raise-to-mouth limited to main hand.
- Third-party content credited (`CREDITS.txt`, `LICENSE_LowFire.txt`); Actions & Stuff (Marketplace) not merged.

## Recommendations — status (all actioned 2026-09-28)

1. **Hero of the Village discount** — verified in-game (16 → 12 emeralds). It works through the modern price formula
   on each trade's `price_multiplier`; the legacy-only `hero_demand_discount` was removed.
2. **Script API upgraded** to `@minecraft/server` 2.10.0 / `server-ui` 2.2.0 (game 1.26.52). Offhand smoking now
   listens to `playerButtonInput` (Sneak) instead of polling every player every tick.
3. **Block storage → `block_entity` dynamic properties — NOT done.** The stable `Block` class has no dynamic-property
   methods yet (still experimental), and a Realm pack must stay stable-only. Racks/distillers keep world storage.
4. **World lists** — the Funguy village list is capped at 800 entries (Funguy-less villages forgotten first).
   Rack/distiller indexes already remove entries when a block is emptied or broken.
5. **Release hygiene** — `cc_tools/build_release.py [--bump X.Y.Z]` builds `.mcpack`s + `.mcaddon` into `releases/`,
   excluding `typescripts/`.
6. **`textures/textures_list.json`** — generated by `cc_tools/gen_textures_list.py` (rerun after adding textures).
7. **FD earthworm** — the texture entry had no item or script behind it; drew `textures/items/earthworm.png` so the
   reference resolves.
8. **Funguy spawn rule alternative** — kept the script approach (more control); `player_in_village_filter` noted.
9. **Vibrant Visuals** — RP has `"capabilities": ["pbr"]`; texture sets for the distiller, nug press, bong and vape
   models from `cc_tools/gen_pbr.py` (metal / glass / glow classified per pixel).
10. **`min_engine_version`** raised to 1.26.50 on both packs — needs a full in-game test pass.

**Testing note:** the user's test world has the Beta APIs and Upcoming Creator Features experiments on. Realms
usually don't — test releases in a world with no experiments.
