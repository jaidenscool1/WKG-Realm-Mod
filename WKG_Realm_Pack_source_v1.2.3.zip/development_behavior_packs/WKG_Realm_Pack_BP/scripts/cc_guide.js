// Cannabis Craft field guide: the pages of the written book every player gets on their first join.
// Pure data - no game APIs here, so the tests can check every page. Icons are glyph characters (cc_glyphs.js,
// generated with the icon sheet by cc_tools/gen_guide_glyphs.py). Book limits: 50 pages, 256 BYTES per page in UTF-8
// (verified in-game: § is 2 bytes, each glyph icon 3 - a 240-character page was rejected), title <= 16 characters. Books have a light page, so only dark § colours are readable.
import { G } from "./cc_glyphs.js";

export const GUIDE_TITLE = "Cannabis Guide";
export const GUIDE_AUTHOR = "WKG Realm";

// Light strain colours don't read on the book's paper - darker stand-ins.
const BOOK_COLOR = { "§a": "§2", "§b": "§3", "§e": "§6", "§f": "§8", "§d": "§5", "§u": "§5", "§7": "§8", "§9": "§1" };
const SHORT = {
  regeneration: "Regen", resistance: "Resist", absorption: "Absorb", slow_falling: "Slow Fall", jump_boost: "Jump",
  fire_resistance: "Fire Res", water_breathing: "Water Br", night_vision: "Night Vis", mining_fatigue: "Fatigue",
  health_boost: "Health+", conduit_power: "Conduit", village_hero: "Hero", invisibility: "Invis"
};
const ROMAN = ["", " II", " III", " IV", " V"];

function strainLine(s, EFFECT_NAMES) {
  const color = BOOK_COLOR[s.color] ?? s.color;
  const fx = s.effects.map(([id, amp]) => (SHORT[id] ?? EFFECT_NAMES[id] ?? id) + ROMAN[amp]).join(", ");
  return `${color}${s.name}§r\n §8${fx}§r`;
}

function strainPages(STRAINS, EFFECT_NAMES) {
  const groups = [
    ["Common §8(craftable)", "common"],
    ["Rare §8(bred / Funguy)", "breed", "trade"],
    ["Funguy exclusives", "funguy"]
  ];
  const pages = [];
  for (const [title, ...rarities] of groups) {
    const list = Object.values(STRAINS).filter((s) => rarities.includes(s.rarity));
    const per = Math.ceil(list.length / Math.ceil(list.length / 5)); // even pages of at most 5 (6 -> 3+3)
    for (let i = 0; i < list.length; i += per) {
      const chunk = list.slice(i, i + per).map((s) => strainLine(s, EFFECT_NAMES)).join("\n");
      pages.push(`§l${title}§r\n${chunk}`);
    }
  }
  return pages;
}

export function buildGuidePages(STRAINS, EFFECT_NAMES) {
  const pages = [
    // cover
    `§2§lCANNABIS CRAFT§r\n§8Field Guide§r\n\n  ${G.sprout} ${G.arrow} ${G.young_plant} ${G.arrow} ${G.flowering_plant}\n\n` +
      `Grow, breed, dry, press, distill and smoke your own strains.\n\n§8Next page: contents`,
    // contents
    "§lContents§r\n1 Getting seeds\n2 Growing\n3 Boosters\n4 Harvest & drying\n5 Strains\n6 Breeding\n" +
      "7 Rolling & smoking\n8 Nug press\n9 Distiller\n10 Vapes\n11 THC & effects\n12 The Funguy\n13 Tobacco\n14 Crafting",
    // the big picture
    `§lThe Big Picture§r\n${G.seed}${G.arrow}${G.sprout}${G.arrow}${G.flowering_plant} §8grow§r\n${G.down}\n` +
      `${G.bud}${G.arrow}${G.drying_rack}${G.arrow}${G.dried_bud} §8dry§r\n${G.down}\n` +
      `${G.rolling_table}${G.arrow}${G.joint}${G.blunt}${G.bong_packed} §8smoke§r\n` +
      `${G.nug_press}${G.arrow}${G.rosin}${G.arrow}${G.distiller} §8press§r\n${G.down}\n` +
      `${G.wax}${G.shatter}${G.live_resin}${G.distillate}${G.arrow}${G.cart}${G.arrow}${G.vape}`,
    // 1 getting seeds
    // each line takes its dye's colour (no §r resets - they cost 3 bytes each on a full page)
    `§l1 Getting Seeds§r\n${G.seed} Craft wheat seeds + a dye:\n§2green: OG Kush\n§1blue: Blue Dream\n` +
      "§6orange: Sour Diesel\n§5purple: Purple Haze\n§8gray: Gorilla Glue\n§2lime: Green Crack\n" +
      "§4red: Tysgorilla\n§5pink: Tender Lad\n§5magenta: Purple Nurple",
    `§lMore Seeds§r\n- Breaking grass: small chance of a common seed\n- ${G.funguy} The Funguy sells every strain\n` +
      `- ${G.breeding_station} Breed your own\n\n§5Every new seed is unique:§r THC ±20%, yield ±1, growth ±15%. ` +
      "Seeds from one harvested plant are identical and stack.",
    // 2 growing
    `§l2 Growing§r\nPlant on farmland.\n${G.sprout}${G.arrow}${G.young_plant}${G.arrow}${G.flowering_plant}\n\n` +
      `- ${G.water} Wet farmland: +40% speed\n- Bone meal: +1 stage\n- The seed's Growth stat speeds it up\n` +
      "- Flowering plants show their strain: green, purple, frosty, dark, golden or red",
    // 3 boosters
    `§l3 Boosters§r\nUse on a growing plant, max 3 of each:\n${G.nutrient_thc} THC: +20% +2 THC\n` +
      `${G.nutrient_yield} Yield: +1 bud\n${G.nutrient_growth} Growth: +25% speed\n\n§8Craft (makes 2):§r\n` +
      "THC: blaze powder + wheat seeds\nYield: bone meal + pumpkin seeds\nGrowth: redstone + wheat seeds",
    // 4 harvest & drying
    `§l4 Harvest§r\nBreak a fully grown ${G.flowering_plant}\n- buds = its Yield ${G.bud}\n- always 1-3 seeds\n` +
      "Break it early to get the seed back.\n\nBuds come off §3wet§r. Eat one for a short buzz, or dry them first.",
    `§lDrying Rack§r ${G.drying_rack}\nHolds up to 16 buds or tobacco leaves.\n\n${G.bud} ${G.arrow} ${G.clock} 2 min ${G.arrow} ${G.dried_bud}\n` +
      `${G.tobacco_leaf} ${G.arrow} ${G.clock} 2 min ${G.arrow} ${G.dried_tobacco}\n\nIt keeps drying while you're away.\n\n` +
      "§2Dried buds:§r effects last 30% longer and make better rosin.",
    // 5 strains (generated)
    ...strainPages(STRAINS, EFFECT_NAMES),
    // 6 breeding
    `§l6 Breeding§r ${G.breeding_station}\nUse the station with 2+ seeds. Pick two parents, a name and a name ` +
      `color (or Random / Rainbow).\n\n${G.seed}${G.plus}${G.seed}${G.arrow}${G.seed}\n\n` +
      "The child mixes both parents' stats and effects (max 3 effects).",
    `§lEffect Levels ${G.star}§r\nWhen both parents have an effect at the §lsame§r level it can go up:\n` +
      "I + I: 50% to II\nII + II: 25% to III\nIII + III: 12.5% to IV\nIV + IV: 6.25% to V\n\n" +
      "Different levels just keep the higher one.",
    "§lRare Strains§r\nCross two pure strain seeds (not hybrids) for a 30% chance of a rare one:\n\n" +
      "Blue Dream + Green Crack\n = §3White Widow§r\nPurple Haze + Purple Nurple\n = §5Purple Punch§r\n" +
      "OG Kush + Sour Diesel\n = §3Skywalker OG§r",
    // 7 rolling & smoking
    `§l7 Rolling Table§r ${G.rolling_table}\nHold a wrapper, use the table, tick strains (uses 1 of each):\n\n` +
      `${G.paper} Joint: up to 4\n${G.tobacco_leaf} Blunt: up to 8\n${G.bong} Bong: up to 6 (buds or dabs)\n` +
      `${G.cart_empty} Cart: up to 3 (distillate or live resin)`,
    `§lSmoking§r\nHold use to raise it and take a hit.\n\n${G.joint} Joint: 4 hits, 1s\n${G.blunt} Blunt: 8 hits, 1s\n` +
      `${G.bong_packed} Bong: 6 hits, 2s\n${G.vape} Vape: 16 hits, 3s\n\nThey burn down as you go. A bong goes back to empty.`,
    "§lOffhand§r\nSmokables fit in your offhand.\n\nTo smoke it: §ldouble-tap sneak§r and keep holding the second tap " +
      "for the drag time. Let go early to cancel.\n\nYour main hand stays free.",
    // 8 nug press
    `§l8 Nug Press§r ${G.nug_press}\nSneak + hit it to fit or swap a plate. Rosin per bud:\n${G.plate_copper} Copper 20%\n` +
      `${G.plate_iron} Iron 33%\n${G.plate_diamond} Diamond 50%\n${G.plate_netherite} Netherite 70%\n\n` +
      `Use it with 4-32 buds of one strain ${G.arrow} ${G.rosin}`,
    `§lRosin§r ${G.rosin}\nRosin is 65-75% THC: stronger buds, better plates and dried buds all raise it.\n\n` +
      "§8Plates:§r 3 copper ingots; 3 iron ingots; diamond + iron plate + diamond; diamond plate + netherite ingot",
    // 9 distiller
    `§l9 Distiller§r ${G.distiller}\n1-16 rosin of one strain + fuel:\n\n${G.wax} Wax: coal, 1 min\n` +
      `${G.shatter} Shatter: blaze rod, 2 min\n${G.live_resin} Live Resin: magma cream, 3 min\n` +
      `${G.distillate} Distillate: ender pearl, 5 min`,
    "§lConcentrates§r\nPer rosin: Wax 100%, Shatter 90%, Live Resin 75%, Distillate 60%. Dried rosin gives 25% more.\n\n" +
      "THC: Wax 70-80, Shatter 75-85, Resin 72-82, Distillate 90-99.9\n\nLive Resin: every effect +1 level.",
    // 10 vapes
    `§l10 Vapes§r\n${G.cart_empty} Cart: glass + quartz + iron\nFill it at the ${G.rolling_table} with distillate or live resin.\n` +
      `${G.battery} Battery: blaze rod + netherite scrap + copper\n\n${G.battery}${G.plus}${G.cart}${G.arrow}${G.vape}\n\n` +
      "16 hits - watch the oil drain.",
    // 11 THC
    "§l11 THC & Effects§r\nHigher THC, longer effects:\n15% THC: normal\n30%: 1.5x\n45%: 2x\n90%: 3.5x\n\n" +
      "Over 25% THC most effects are also one level stronger.",
    // 12 Funguy
    `§l12 The Funguy§r ${G.funguy}\nA mushroom trader. Lives in some villages and sometimes wanders near players.\n\n` +
      `Buys shatter: 2 ${G.emerald}\nSells seeds (every strain) and gear. Each Funguy has his own 6 trades.`,
    "§lFunguy Exclusives§r\nOnly he sells:\n§8Phantom Cookies§r\n Invisibility\n§3Poseidon OG§r\n Conduit Power\n" +
      "§6Hero Haze§r\n Hero of the Village\n\nTip: smoke Hero Haze before trading - it lowers his prices.",
    // 13 tobacco
    `§l13 Tobacco§r ${G.tobacco_leaf}\n${G.tobacco_seeds} Seeds: wheat seeds + cocoa beans (makes 2)\n\n` +
      "Plant on farmland; 4 stages. Harvest for 2-3 leaves and seeds.\n\nLeaves wrap blunts, or dry them on the rack for cigarettes.",
    `§lCigarettes§r ${G.cigarette}\n${G.paper}${G.plus}${G.dried_tobacco}${G.arrow}${G.cigarette}${G.cigarette}\n` +
      "Craft: rolling paper + dried tobacco (makes 2). One hit: Swiftness I.\n\n" +
      `§4Marlboro Reds§r ${G.cig_pack}\nHold red dye and use the ${G.rolling_table} with 12 cigarettes + 1 paper. 12 hits of Swiftness I.`,
    // 14 crafting
    `§l14 Crafting§r\n${G.breeding_station} 4 planks + poppy\n${G.rolling_table} 4 planks + paper\n` +
      `${G.drying_rack} 3 string / 3 fences / 2 logs\n${G.nug_press} iron lever iron / iron _ iron / 3 smooth stone\n` +
      `${G.distiller} 3 glass / iron furnace iron / iron cauldron iron`,
    `§lSupplies§r\n${G.paper} Papers (x2): paper + string\n${G.bong} Bong: 4 glass + glass bottle\n\n§lTips§r\n` +
      "- Compare seed stats in their lore\n- Seeds from one plant stack\n" +
      `- Lost this book? Use a plain book on a ${G.breeding_station}`
  ];
  return pages;
}
