import { world, system, ItemStack, EquipmentSlot, ButtonState, InputButton } from "@minecraft/server";
import { ModalFormData, ActionFormData } from "@minecraft/server-ui";
import { buildGuidePages, GUIDE_TITLE, GUIDE_AUTHOR } from "./cc_guide.js";

/* =========================================================================
   CANNABIS CRAFT - Phase 1
   - 15 strains, each with its own list of status effects
   - Rarity: common (craftable), breed-only, trade-only (trader comes in Phase 5)
   - Genetics stored in a world registry, referenced by a short ID in item lore,
     so seeds and buds with identical genetics STACK
   - Buds are tagged Wet (fresh) or Dried (Phase 2 drying rack)
   - Tobacco plant -> tobacco leaf -> blunts
   - Rolling table makes joints (4 strains / 4 hits), blunts (8 / 8),
     and packs bongs (6 / 6, the bong itself is reusable)
   - Phase 2 drying rack, Phase 3 nug press (rosin)
   - Phase 4 distiller (wax, shatter, live resin, distillate), dabs,
     vape cartridges and vape pens
   ========================================================================= */

/* ------------------------------- Tuning ---------------------------------- */

const CANNABIS_MAX = 4;
const TOBACCO_MAX = 3;
const GROWTH_TICK_INTERVAL = 100; // ~5 seconds
const CANNABIS_GROWTH_CHANCE = 0.12;
const TOBACCO_GROWTH_CHANCE = 0.15;
const GRASS_SEED_DROP_CHANCE = 0.05; // user: 2% was a touch too rare
const HARVEST_SEED_CHANCE = 1; // a finished plant always drops 1-HARVEST_SEED_MAX seeds (user: 85% was too low)
const HARVEST_SEED_MAX = 3;
const GRASS_BLOCK_IDS = ["minecraft:tallgrass", "minecraft:short_grass", "minecraft:tall_grass"];
const RARE_BREED_CHANCE = 0.3;
const MAX_BRED_EFFECTS = 3;
const DRIED_MULTIPLIER = 1.3;
const MAX_NUTRIENTS_PER_TYPE = 3;
const BUD_EFFECT_TICKS = 300;
const RACK_CAPACITY = 16;
const DRY_MS = 2 * 60 * 1000; // 2 real-time minutes
const RACK_INDEX_PROP = "cc:racks";

// Nug press: tier = the value stored in the block's "cc:plate" state (0 = no plate).
const PRESS_PLATES = {
  "cc:press_plate_copper": { tier: 1, name: "Copper", rate: 0.2 },
  "cc:press_plate_iron": { tier: 2, name: "Iron", rate: 0.33 },
  "cc:press_plate_diamond": { tier: 3, name: "Diamond", rate: 0.5 },
  "cc:press_plate_netherite": { tier: 4, name: "Netherite", rate: 0.7 }
};
const PLATE_BY_TIER = [null];
for (const [id, p] of Object.entries(PRESS_PLATES)) PLATE_BY_TIER[p.tier] = { id, ...p };
const PRESS_MIN_BUDS = 4;
const PRESS_MAX_BUDS = 32;
const PRESS_TICKS = 40; // 2 seconds with the plate down

// Distiller: rosin + 1 fuel item per batch -> a concentrate. The more refined the product,
// the longer it takes, the less you get per rosin, and the higher its THC.
// thc: [lo, hi] - the rosin THC range (65-75%) is scaled onto this range, so the
// weakest rosin gives `lo` and the strongest gives `hi`.
// Live resin keeps the terpenes instead: every effect is one level stronger.
const DISTILL_PROCESSES = {
  wax: { item: "cc:wax", name: "Wax", fuels: ["minecraft:coal", "minecraft:charcoal"], fuelName: "Coal", ms: 60 * 1000, yield: 1.0, thc: [70, 80] },
  shatter: { item: "cc:shatter", name: "Shatter", fuels: ["minecraft:blaze_rod"], fuelName: "Blaze Rod", ms: 2 * 60 * 1000, yield: 0.9, thc: [75, 85] },
  live_resin: { item: "cc:live_resin", name: "Live Resin", fuels: ["minecraft:magma_cream"], fuelName: "Magma Cream", ms: 3 * 60 * 1000, yield: 0.75, thc: [72, 82], effectBoost: 1 },
  distillate: { item: "cc:distillate", name: "Distillate", fuels: ["minecraft:ender_pearl"], fuelName: "Ender Pearl", ms: 5 * 60 * 1000, yield: 0.6, thc: [90, 99.9] }
};
const DISTILL_ORDER = ["wax", "shatter", "live_resin", "distillate"];
const DISTILL_MAX_ROSIN = 16;
const DRIED_ROSIN_YIELD = 1.25; // rosin pressed from dried buds gives 25% more
const STILL_INDEX_PROP = "cc:stills";

// Concentrates that fill vape cartridges, and ones you can dab from a bong.
const CART_FILLS = { "cc:distillate": "Distillate", "cc:live_resin": "Live Resin" };
const DAB_ITEMS = ["cc:shatter", "cc:wax"];
const CART_KIND_PREFIX = "§7Contents: §d";
// A crafted vape pen gets the strains of a filled cart that left the inventory within this window.
const VAPE_LINK_WINDOW_MS = 5 * 60 * 1000;

const EFFECT_NAMES = {
  speed: "Speed",
  haste: "Haste",
  strength: "Strength",
  jump_boost: "Jump Boost",
  regeneration: "Regeneration",
  resistance: "Resistance",
  fire_resistance: "Fire Resistance",
  water_breathing: "Water Breathing",
  night_vision: "Night Vision",
  absorption: "Absorption",
  saturation: "Saturation",
  levitation: "Levitation",
  slow_falling: "Slow Falling",
  blindness: "Blindness",
  mining_fatigue: "Mining Fatigue",
  health_boost: "Health Boost",
  invisibility: "Invisibility",
  conduit_power: "Conduit Power",
  village_hero: "Hero of the Village"
};
// Effects that always last a fixed time regardless of method (levitation = 3 sec).
const FIXED_DURATION = { levitation: 60, saturation: 40, blindness: 100 };
// Effects that never get the high-THC amplifier bonus.
// Effect duration scales with THC: 15% = normal length, 30% = 1.5x, 45% = 2x, 90% = 3.5x.
// Effects in FIXED_DURATION ignore this.
const THC_BASELINE = 15;
function thcDurationMult(thc) {
  return Math.max(0.5, 1 + ((thc ?? THC_BASELINE) - THC_BASELINE) / 30);
}
const NO_THC_BONUS = new Set(["levitation", "blindness", "mining_fatigue", "saturation", "invisibility", "conduit_power"]);
const ROMAN = ["I", "II", "III", "IV", "V"];

// effects: [effectId, amplifier]  (amplifier 0 = level I)
const STRAINS = {
  og_kush: { name: "OG Kush", color: "§2", thc: 22, yieldStat: 3, growth: 1.0, rarity: "common", effects: [["regeneration", 0], ["resistance", 0]] },
  blue_dream: { name: "Blue Dream", color: "§9", thc: 18, yieldStat: 4, growth: 1.15, rarity: "common", effects: [["speed", 1], ["absorption", 0]] },
  sour_diesel: { name: "Sour Diesel", color: "§6", thc: 25, yieldStat: 2, growth: 0.9, rarity: "common", effects: [["speed", 1], ["haste", 1]] },
  purple_haze: { name: "Purple Haze", color: "§5", thc: 20, yieldStat: 3, growth: 1.05, rarity: "common", effects: [["slow_falling", 0], ["jump_boost", 1]] },
  gorilla_glue: { name: "Gorilla Glue", color: "§8", thc: 28, yieldStat: 3, growth: 0.85, rarity: "common", effects: [["strength", 0], ["regeneration", 0]] },
  green_crack: { name: "Green Crack", color: "§a", thc: 19, yieldStat: 3, growth: 1.25, rarity: "common", effects: [["haste", 1], ["speed", 0]] },
  tysgorilla: { name: "Tysgorilla", color: "§4", thc: 24, yieldStat: 3, growth: 0.95, rarity: "common", effects: [["strength", 0]] },
  tender_lad: { name: "Tender Lad", color: "§d", thc: 16, yieldStat: 4, growth: 1.1, rarity: "common", effects: [["absorption", 0]] },
  purple_nurple: { name: "Purple Nurple", color: "§u", thc: 17, yieldStat: 3, growth: 1.1, rarity: "common", effects: [["regeneration", 0], ["health_boost", 0]] },
  white_widow: { name: "White Widow", color: "§f", thc: 23, yieldStat: 3, growth: 1.0, rarity: "breed", effects: [["jump_boost", 0], ["speed", 0]] },
  purple_punch: { name: "Purple Punch", color: "§5", thc: 21, yieldStat: 3, growth: 1.0, rarity: "breed", effects: [["night_vision", 0], ["saturation", 1]] },
  skywalker_og: { name: "Skywalker OG", color: "§b", thc: 26, yieldStat: 2, growth: 0.95, rarity: "breed", effects: [["levitation", 0], ["fire_resistance", 0]] },
  george_droid: { name: "George Droid", color: "§3", thc: 20, yieldStat: 3, growth: 1.0, rarity: "trade", effects: [["water_breathing", 0], ["resistance", 0]] },
  sleepy_joe_og: { name: "Sleepy Joe OG", color: "§7", thc: 15, yieldStat: 4, growth: 1.0, rarity: "trade", effects: [["blindness", 0], ["mining_fatigue", 0], ["slow_falling", 0]] },
  black_mamba: { name: "Black Mamba", color: "§8", thc: 27, yieldStat: 2, growth: 0.9, rarity: "trade", effects: [["speed", 1], ["haste", 0]] },
  // Funguy exclusives: sold only by the Funguy, never bred, and the only strains with these effects.
  phantom_cookies: { name: "Phantom Cookies", color: "§f", thc: 24, yieldStat: 3, growth: 1.0, rarity: "funguy", effects: [["invisibility", 0]] },
  poseidon_og: { name: "Poseidon OG", color: "§3", thc: 22, yieldStat: 3, growth: 1.0, rarity: "funguy", effects: [["conduit_power", 0]] },
  hero_haze: { name: "Hero Haze", color: "§e", thc: 20, yieldStat: 3, growth: 1.0, rarity: "funguy", effects: [["village_hero", 0]] }
};
const SEED_TO_KEY = {};
for (const key of Object.keys(STRAINS)) SEED_TO_KEY[`cc:seed_${key}`] = key;
const COMMON_KEYS = Object.keys(STRAINS).filter((k) => STRAINS[k].rarity === "common");

// Crossing two PURE base strains (not hybrids) has a chance to produce a breed-only strain.
const BREED_RECIPES = [
  ["blue_dream", "green_crack", "white_widow"],
  ["purple_haze", "purple_nurple", "purple_punch"],
  ["og_kush", "sour_diesel", "skywalker_og"]
];

// Old single-effect saves from earlier versions get mapped onto the new list format.
const LEGACY_EFFECTS = {
  relaxing: [["regeneration", 0], ["resistance", 0]],
  euphoric: [["speed", 1], ["absorption", 0]],
  energizing: [["speed", 1], ["haste", 1]],
  creative: [["slow_falling", 0], ["jump_boost", 1]],
  power: [["strength", 0], ["regeneration", 0]],
  focus: [["haste", 1], ["speed", 0]]
};

// What you hold at the rolling table decides what you make.
const SMOKE_INPUTS = {
  "cc:rolling_paper": { product: "cc:joint", label: "Joint", maxStrains: 4, accepts: ["cc:bud"] },
  "cc:tobacco_leaf": { product: "cc:blunt", label: "Blunt", maxStrains: 8, accepts: ["cc:bud"] },
  "cc:bong": { product: "cc:bong_packed", label: "Bong", maxStrains: 6, accepts: ["cc:bud", ...DAB_ITEMS], replaceInHand: true },
  "cc:cart_empty": { product: "cc:cart_filled", label: "Cartridge", maxStrains: 3, accepts: Object.keys(CART_FILLS), cart: true }
};
// Each smokable has visual stages; the item swaps to the next stage as hits are taken.
// poseStage feeds "cc:smoke_stage", a plain dynamic property (no entity-file
// declaration needed - the raise-to-mouth pose animation controller that used
// to read this client-side has been removed for Persona-skin compatibility,
// so this is now just internal state): 1 = one-handed (joint/blunt), 2 = two-handed (bong).
// dragMs matches each item's use_duration; offhand hits (double-tap sneak) use it as their cooldown.
const SMOKE_FAMILIES = {
  joint: { uses: 4, ticks: 300, dragMs: 1000, stages: ["cc:joint", "cc:joint_s1", "cc:joint_s2", "cc:joint_s3"], poseStage: 1 },
  blunt: { uses: 8, ticks: 360, dragMs: 1000, stages: ["cc:blunt", "cc:blunt_s1", "cc:blunt_s2", "cc:blunt_s3"], poseStage: 1 },
  bong: {
    uses: 6,
    ticks: 440,
    dragMs: 2000,
    stages: ["cc:bong_packed", "cc:bong_packed_s1", "cc:bong_packed_s2"],
    emptyInto: "cc:bong",
    emptyMessage: "§7Bowl cashed - pack it again at a Rolling Table.",
    poseStage: 2
  },
  // Cigarettes: crafted, so they carry no strain data - defaultSmoke is what they give (Swiftness I only).
  // Single cigarettes stack (16), one hit each; the 12-pack ("Marlboro Reds") is packed at the Rolling Table.
  cigarette: {
    uses: 1,
    ticks: 400,
    dragMs: 1000,
    stages: ["cc:cigarette"],
    poseStage: 1,
    defaultSmoke: { thc: 15, effects: [["speed", 0]], dryMult: 1 },
    emptyMessage: "§7Finished the cigarette."
  },
  // After the first hit the pack swaps to its "lit" twin (cigarette stays at the mouth, no take-out animation);
  // it swaps back when it leaves the hand/offhand (see revertLitPacks).
  cigarette_pack: {
    uses: 12,
    ticks: 600,
    dragMs: 3000,
    stages: ["cc:cigarette_pack", "cc:cigarette_pack_s1", "cc:cigarette_pack_s2", "cc:cigarette_pack_s3"],
    litStages: ["cc:cigarette_pack_lit", "cc:cigarette_pack_lit_s1", "cc:cigarette_pack_lit_s2", "cc:cigarette_pack_lit_s3"],
    poseStage: 1,
    defaultSmoke: { thc: 15, effects: [["speed", 0]], dryMult: 1 },
    emptyMessage: "§7That was the last one - the pack is empty."
  },
  vape: {
    uses: 16,
    ticks: 200,
    dragMs: 3000,
    stages: ["cc:vape_pen", "cc:vape_pen_s1", "cc:vape_pen_s2", "cc:vape_pen_s3"],
    emptyInto: "cc:vape_battery",
    emptyMessage: "§7Cartridge used up - craft a new one onto the battery.",
    poseStage: 1
  }
};
const SMOKABLES = {};
for (const fam of Object.values(SMOKE_FAMILIES)) for (const id of [...fam.stages, ...(fam.litStages ?? [])]) SMOKABLES[id] = fam;
// lit pack id -> its normal twin
const UNLIT = {};
for (const fam of Object.values(SMOKE_FAMILIES)) (fam.litStages ?? []).forEach((id, i) => (UNLIT[id] = fam.stages[i]));

const NUTRIENT_ITEMS = {
  "cc:nutrient_thc": "thc",
  "cc:nutrient_yield": "yield",
  "cc:nutrient_growth": "growth"
};

const ID_PREFIX = "§8#";

/* ------------------------------- Utilities ------------------------------- */

function clamp(v, lo, hi) {
  return Math.max(lo, Math.min(hi, v));
}
function round2(v) {
  return Math.round(v * 100) / 100;
}
// Form text treats a lone "%" as a format code and drops it; "%%" shows as "%".
function formPct(rate) {
  return `${Math.round(rate * 100)}%%`;
}
function safeParse(json) {
  if (typeof json !== "string") return null;
  try {
    return JSON.parse(json);
  } catch (e) {
    return null;
  }
}
function shuffle(arr) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}
function effectLabel(id, amp) {
  return `${EFFECT_NAMES[id] ?? id} ${ROMAN[amp] ?? amp + 1}`;
}

// A strain's `color` is a § code, or "rainbow" (each letter a different colour). Always print strain names
// through strainName() so rainbow strains stay rainbow on seeds, buds, rosin, carts, forms and messages.
// After a rainbow name the text colour resets to white so any suffix ("Bud", "Seeds") reads normally.
const RAINBOW = "rainbow";
const RAINBOW_CODES = ["§c", "§6", "§e", "§a", "§b", "§9", "§d"];
function strainName(g) {
  if (g.color !== RAINBOW) return (g.color ?? "") + g.name;
  let i = 0;
  return (
    [...g.name].map((ch) => (ch === " " ? ch : RAINBOW_CODES[i++ % RAINBOW_CODES.length] + ch)).join("") + "§f"
  );
}

// Name colours offered by the Breeding Station (bright shades only - item tooltips are dark).
const NAME_COLORS = [
  ["Red", "§c"], ["Gold", "§6"], ["Yellow", "§e"], ["Lime", "§a"], ["Green", "§2"], ["Emerald", "§q"],
  ["Aqua", "§b"], ["Teal", "§3"], ["Diamond", "§s"], ["Blue", "§9"], ["Purple", "§5"], ["Amethyst", "§u"],
  ["Pink", "§d"], ["Copper", "§n"], ["White", "§f"], ["Gray", "§7"]
];
// Dropdown entries: 0 = keep the colour inherited from a parent, then the palette, then Random, then Rainbow.
const NAME_COLOR_CHOICES = [
  "§7Keep parent color",
  ...NAME_COLORS.map(([label, code]) => `${code}${label}`),
  "§fRandom",
  strainName({ color: RAINBOW, name: "Rainbow" })
];
function pickNameColor(index, inherited) {
  if (!index) return inherited;
  if (index <= NAME_COLORS.length) return NAME_COLORS[index - 1][1];
  if (index === NAME_COLORS.length + 1) return NAME_COLORS[Math.floor(Math.random() * NAME_COLORS.length)][1];
  return RAINBOW;
}
function hashString(s) {
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  return h.toString(36);
}
function safeSetLore(item, lines) {
  try {
    item.setLore(lines.map((l) => (l.length > 50 ? l.slice(0, 50) : l)).slice(0, 20));
  } catch (e) {
    /* lore limits differ slightly across versions - never let it crash a flow */
  }
}
function readLore(item) {
  try {
    return item.getLore() ?? [];
  } catch (e) {
    return [];
  }
}
function wrapList(prefix, items, width = 44) {
  const lines = [];
  let cur = prefix;
  for (const it of items) {
    const sep = cur === prefix ? "" : ", ";
    if ((cur + sep + it).length > width && cur !== prefix) {
      lines.push(cur);
      cur = "§f" + it;
    } else {
      cur += sep + it;
    }
  }
  if (cur !== prefix) lines.push(cur);
  return lines;
}

/* -------------------------------- Genetics -------------------------------- */

function baseGenetics(key) {
  const s = STRAINS[key];
  return {
    key,
    name: s.name,
    color: s.color,
    thc: s.thc,
    yieldStat: s.yieldStat,
    growth: s.growth,
    effects: s.effects.map((e) => [...e]),
    gen: 0,
    boosted: false
  };
}

// Every newly obtained strain seed (crafted, traded, grass, rare discovery) is its own roll of the strain:
// same name/effects, but THC ±20% (0.1 steps), yield ±1, growth ±15%. Only harvesting copies exact values.
function rollStrain(key) {
  const g = baseGenetics(key);
  const vary = (v, pct) => v * (1 + (Math.random() * 2 - 1) * pct);
  g.thc = clamp(Math.round(vary(g.thc, 0.2) * 10) / 10, 1, 40);
  g.yieldStat = clamp(g.yieldStat + Math.floor(Math.random() * 3) - 1, 1, 6);
  g.growth = round2(clamp(vary(g.growth, 0.15), 0.5, 1.6));
  return g;
}

function normalizeGenetics(g) {
  if (!g) return null;
  const out = { ...g };
  if (!Array.isArray(out.effects)) {
    out.effects = (LEGACY_EFFECTS[out.effect] ?? [["regeneration", 0]]).map((e) => [...e]);
  }
  out.color = out.color ?? out.colorCode ?? "§2";
  delete out.effect;
  delete out.colorCode;
  out.name = out.name ?? "Cannabis";
  out.thc = out.thc ?? 15;
  out.yieldStat = out.yieldStat ?? 2;
  out.growth = round2(out.growth ?? 1);
  out.gen = out.gen ?? 0;
  out.boosted = !!out.boosted;
  return out;
}

function isPureBase(g) {
  return !!g && !!g.key && STRAINS[g.key] !== undefined && g.gen === 0 && !g.boosted;
}

function canonical(g) {
  return JSON.stringify({
    key: g.key ?? null,
    name: g.name,
    color: g.color,
    thc: g.thc,
    yieldStat: g.yieldStat,
    growth: round2(g.growth),
    effects: g.effects,
    gen: g.gen ?? 0,
    boosted: !!g.boosted
  });
}

/** Stores genetics in the world registry; identical genetics always get the same ID. */
function registerGenetics(g) {
  const c = canonical(g);
  const id = hashString(c);
  const prop = `cc:g:${id}`;
  try {
    if (world.getDynamicProperty(prop) === undefined) world.setDynamicProperty(prop, c);
  } catch (e) {
    /* registry write failed - item still works this session via fallback */
  }
  return id;
}

function lookupGenetics(id) {
  try {
    return normalizeGenetics(safeParse(world.getDynamicProperty(`cc:g:${id}`)));
  } catch (e) {
    return null;
  }
}

/** Reads genetics from any seed or bud: lore ID -> legacy data -> base seed type. */
function getGenetics(item) {
  if (!item) return null;
  const idLine = readLore(item).find((l) => l.startsWith(ID_PREFIX));
  if (idLine) {
    const g = lookupGenetics(idLine.slice(ID_PREFIX.length));
    if (g) return g;
  }
  try {
    const legacy = safeParse(item.getDynamicProperty("cc:genetics"));
    if (legacy) return normalizeGenetics(legacy);
  } catch (e) {
    /* stackable items may not support dynamic properties */
  }
  const key = SEED_TO_KEY[item.typeId];
  return key ? baseGenetics(key) : null;
}

function isDried(item) {
  return readLore(item).some((l) => l.includes("Dried"));
}

function mergeEffects(lists, cap) {
  const m = new Map();
  for (const list of lists) {
    for (const [id, amp] of list) {
      if (!m.has(id) || m.get(id) < amp) m.set(id, amp);
    }
  }
  let arr = [...m.entries()];
  if (cap && arr.length > cap) arr = shuffle(arr).slice(0, cap);
  return arr;
}

// Breeding: an effect BOTH parents have at the SAME level may grow a level, one roll:
// 50% to reach II, 25% to reach III, 12.5% to reach IV... (halves every level), capped at MAX_EFFECT_AMP (V).
// Shared effects are kept first when the child is over the effect cap.
const MAX_EFFECT_AMP = 4;
function upgradeChance(amp) {
  return amp >= MAX_EFFECT_AMP ? 0 : 0.5 ** (amp + 1);
}
function breedEffects(a, b, cap) {
  const ampsA = new Map(a.effects), ampsB = new Map(b.effects);
  const shared = [], rest = [], upgraded = [];
  for (const [id, amp] of mergeEffects([a.effects, b.effects], 0)) {
    if (ampsA.has(id) && ampsB.has(id)) {
      // only two parents with the effect at the SAME level can breed the next level (II + II -> III);
      // mismatched levels just pass on the stronger one
      if (ampsA.get(id) === ampsB.get(id) && Math.random() < upgradeChance(amp)) {
        shared.push([id, amp + 1]);
        upgraded.push([id, amp + 1]);
      } else {
        shared.push([id, amp]);
      }
    } else {
      rest.push([id, amp]);
    }
  }
  const effects = [...shared, ...shuffle(rest)].slice(0, cap);
  return { effects, upgraded: upgraded.filter(([id]) => effects.some(([e]) => e === id)) };
}

function combineNames(nameA, nameB) {
  const first = nameA.split(" ")[0];
  const b = nameB.split(" ");
  const last = b[b.length - 1];
  if (first.toLowerCase() === last.toLowerCase()) return `${first} Select`;
  return `${first} ${last}`;
}

/** Returns { child, rare, upgraded } - rare is the breed-only strain key if one was discovered;
 *  upgraded lists shared effects that grew a level ([id, newAmp]). */
function crossGenetics(a, b) {
  if (isPureBase(a) && isPureBase(b)) {
    const recipe = BREED_RECIPES.find(
      ([x, y]) => (a.key === x && b.key === y) || (a.key === y && b.key === x)
    );
    if (recipe && Math.random() < RARE_BREED_CHANCE) {
      return { child: rollStrain(recipe[2]), rare: recipe[2], upgraded: [] };
    }
  }
  const bred = breedEffects(a, b, MAX_BRED_EFFECTS);
  const mix = (x, y) => {
    const base = (x + y) / 2;
    return base + (Math.random() * 2 - 1) * base * 0.15;
  };
  const child = {
    key: null,
    name: combineNames(a.name, b.name),
    color: Math.random() < 0.5 ? a.color : b.color,
    thc: clamp(Math.round(mix(a.thc, b.thc) * 10) / 10, 1, 40),
    yieldStat: clamp(Math.round(mix(a.yieldStat, b.yieldStat)), 1, 6),
    growth: round2(clamp(mix(a.growth, b.growth), 0.5, 1.6)),
    effects: bred.effects,
    gen: Math.max(a.gen ?? 0, b.gen ?? 0) + 1,
    boosted: false
  };
  return { child, rare: null, upgraded: bred.upgraded };
}

/* ------------------------------ Item builders ----------------------------- */

function geneticsLore(g, stateLine) {
  const lines = [`§7THC: §f${g.thc}%`, `§7Yield: §f${g.yieldStat} §7Growth: §f${Math.round(g.growth * 100)}%`];
  for (const [id, amp] of g.effects) lines.push(`§b• ${effectLabel(id, amp)}`);
  if (stateLine) lines.push(stateLine);
  if (g.gen > 0) lines.push(`§8Generation ${g.gen} hybrid`);
  if (g.boosted) lines.push("§8Nutrient boosted");
  if (isPureBase(g) && RARITY_LINE[STRAINS[g.key].rarity]) lines.push(RARITY_LINE[STRAINS[g.key].rarity]);
  lines.push(ID_PREFIX + registerGenetics(g));
  return lines;
}

const RARITY_LINE = {
  common: "§8Common strain - craftable",
  breed: "§dRare strain - breed-only",
  trade: "§6Rare strain - sold by the Funguy",
  funguy: "§5Funguy exclusive"
};

/** Named-strain seeds keep their own item (icon + coloured name) and carry their rolled values as lore + ID.
 *  Identical genetics give an identical ID, so seeds harvested from one plant still stack together. */
function makeSeedItem(g, amount = 1) {
  if (isPureBase(g)) {
    const item = new ItemStack(`cc:seed_${g.key}`, amount);
    safeSetLore(item, geneticsLore(g));
    return item;
  }
  const item = new ItemStack("cc:seed_hybrid", amount);
  item.nameTag = `${strainName(g)} Seeds§r`;
  safeSetLore(item, geneticsLore(g));
  return item;
}

function makeBudItem(g, amount = 1, dried = false) {
  const item = new ItemStack("cc:bud", amount);
  item.nameTag = `${strainName(g)} Bud§r`;
  safeSetLore(item, geneticsLore(g, dried ? "§7State: §6Dried" : "§7State: §bWet"));
  return item;
}

function giveItem(player, stack) {
  try {
    const container = player.getComponent("minecraft:inventory").container;
    const leftover = container.addItem(stack);
    if (leftover) player.dimension.spawnItem(leftover, player.location);
  } catch (e) {
    player.dimension.spawnItem(stack, player.location);
  }
}

function consumeFromSlot(container, slot, count = 1) {
  const stack = container.getItem(slot);
  if (!stack) return;
  if (stack.amount > count) {
    stack.amount -= count;
    container.setItem(slot, stack);
  } else {
    container.setItem(slot, undefined);
  }
}

function consumeOneFromHand(player, typeId) {
  try {
    const container = player.getComponent("minecraft:inventory").container;
    const stack = container.getItem(player.selectedSlotIndex);
    if (stack && stack.typeId === typeId) {
      consumeFromSlot(container, player.selectedSlotIndex, 1);
      return true;
    }
  } catch (e) {
    /* non-critical */
  }
  return false;
}

/* ------------------------- Click handling helpers ------------------------- */

// Holding the use button re-fires interaction events every few ticks, and more
// than one event can fire for a single click - every click action goes through here.
const recentActions = new Map();
function debounced(player, purpose, cooldownMs, fn) {
  const key = `${player.id}:${purpose}`;
  const now = Date.now();
  const last = recentActions.get(key);
  if (last !== undefined && now - last < cooldownMs) return;
  recentActions.set(key, now);
  fn();
}

// Forms opened during a block interaction often get rejected as "UserBusy"
// (the game still thinks you're mid-click). Retry for about 5 seconds.
async function showForm(player, form) {
  for (let attempt = 0; attempt < 20; attempt++) {
    const res = await form.show(player);
    if (!(res.canceled && res.cancelationReason === "UserBusy")) return res;
    await new Promise((resolve) => system.runTimeout(resolve, 5));
  }
  return { canceled: true };
}

/* ---------------------------- Breeding Station ---------------------------- */

async function handleBreeding(player) {
  try {
    const container = player.getComponent("minecraft:inventory").container;

    const found = [];
    for (let i = 0; i < container.size; i++) {
      const stack = container.getItem(i);
      if (!stack || !stack.typeId.startsWith("cc:seed_")) continue;
      const g = getGenetics(stack);
      if (g) found.push({ slot: i, genetics: g, amount: stack.amount });
    }

    const totalSeeds = found.reduce((s, f) => s + f.amount, 0);
    if (found.length === 0 || totalSeeds < 2) {
      player.sendMessage("§cPut at least two cannabis seeds in your inventory, then use the Breeding Station.");
      return;
    }

    const options = found.map(
      (f) => `${strainName(f.genetics)}§r §7x${f.amount} (THC ${f.genetics.thc}%)`
    );
    const form = new ModalFormData()
      .title("Breeding Station")
      .dropdown("Parent A", options, { defaultValueIndex: 0 })
      .dropdown("Parent B", options, { defaultValueIndex: Math.min(1, options.length - 1) })
      .textField("Name the new strain (optional):", "e.g. Purple Thunder", { defaultValue: "" })
      .dropdown("Name color:", NAME_COLOR_CHOICES, { defaultValueIndex: 0 });

    const response = await showForm(player, form);
    if (!response || response.canceled) return;

    const [idxA, idxB, nameInput, colorIdx] = response.formValues;
    const parentA = found[idxA];
    const parentB = found[idxB];
    if (!parentA || !parentB) return;

    const stackA = container.getItem(parentA.slot);
    const stackB = container.getItem(parentB.slot);
    if (idxA === idxB && (!stackA || stackA.amount < 2)) {
      player.sendMessage("§cTo cross a strain with itself you need at least 2 of that seed.");
      return;
    }
    const geneticsA = getGenetics(stackA);
    const geneticsB = getGenetics(stackB);
    if (!geneticsA || !geneticsB) {
      player.sendMessage("§cOne of the selected seeds is no longer in your inventory.");
      return;
    }

    const { child, rare, upgraded } = crossGenetics(geneticsA, geneticsB);
    const customName = (nameInput ?? "").toString().trim();

    if (idxA === idxB) {
      consumeFromSlot(container, parentA.slot, 2);
    } else {
      consumeFromSlot(container, parentA.slot, 1);
      consumeFromSlot(container, parentB.slot, 1);
    }

    if (rare) {
      giveItem(player, makeSeedItem(child));
      player.sendMessage(`§6§lRare strain discovered!§r ${strainName(child)}§r`);
      if (customName || colorIdx) player.sendMessage("§7(Rare strains keep their original name and color.)");
      return;
    }

    if (customName) child.name = customName.slice(0, 32);
    child.color = pickNameColor(colorIdx, child.color);
    giveItem(player, makeSeedItem(child));
    player.sendMessage(
      `§2Bred ${strainName(child)}§r §7(THC ${child.thc}%, Yield ${child.yieldStat}, ${child.effects
        .map(([id, amp]) => effectLabel(id, amp))
        .join(", ")})`
    );
    for (const [id, amp] of upgraded) {
      player.sendMessage(`§d§l+ §r§dBoth parents shared ${EFFECT_NAMES[id] ?? id} - it grew to level ${ROMAN[amp] ?? amp + 1}!`);
    }
    if (upgraded.length) {
      try {
        player.playSound("random.levelup", { volume: 0.6, pitch: 1.4 });
      } catch (e) {
        /* cosmetic */
      }
    }
  } catch (e) {
    player.sendMessage(`§cBreeding station error: ${e}`);
  }
}

/* ------------------------------ Rolling Table ----------------------------- */

// Red dye in hand + 12 cigarettes + 1 paper anywhere in the inventory -> one 12-pack (crafting grids only hold 9).
const PACK_SIZE = 12;
function countItem(container, typeId) {
  let n = 0;
  for (let i = 0; i < container.size; i++) {
    const s = container.getItem(i);
    if (s?.typeId === typeId) n += s.amount;
  }
  return n;
}
function takeItems(container, typeId, amount) {
  for (let i = 0; i < container.size && amount > 0; i++) {
    const s = container.getItem(i);
    if (s?.typeId !== typeId) continue;
    const n = Math.min(amount, s.amount);
    consumeFromSlot(container, i, n);
    amount -= n;
  }
}
function packCigarettes(player) {
  const container = player.getComponent("minecraft:inventory").container;
  const cigs = countItem(container, "cc:cigarette");
  const paper = countItem(container, "minecraft:paper");
  if (cigs < PACK_SIZE || paper < 1) {
    player.sendMessage(`§cA pack needs ${PACK_SIZE} cigarettes and 1 paper (you have ${cigs} and ${paper}), plus the red dye in your hand.`);
    return false;
  }
  if (!consumeOneFromHand(player, "minecraft:red_dye")) return false;
  takeItems(container, "cc:cigarette", PACK_SIZE);
  takeItems(container, "minecraft:paper", 1);
  giveItem(player, new ItemStack("cc:cigarette_pack", 1));
  player.sendMessage("§cPacked a fresh §lMarlboro Reds§r§c (12).");
  return true;
}

async function handleRolling(player) {
  try {
    const container = player.getComponent("minecraft:inventory").container;
    const handSlot = player.selectedSlotIndex;
    const handItem = container.getItem(handSlot);
    if (handItem?.typeId === "minecraft:red_dye") {
      packCigarettes(player);
      return;
    }
    const recipe = handItem ? SMOKE_INPUTS[handItem.typeId] : undefined;

    if (!recipe) {
      player.sendMessage(
        "§eHold §fRolling Paper§e (joint), a §fTobacco Leaf§e (blunt), an empty §fBong§e (buds or a dab), an §fEmpty Cartridge§e, or §fRed Dye§e (pack 12 cigarettes), then use the Rolling Table."
      );
      return;
    }

    // One entry per item + strain + state (a wet and a dried bud of the same strain are separate choices).
    const accepts = new Set(recipe.accepts);
    const candidates = [];
    const seen = new Set();
    for (let i = 0; i < container.size; i++) {
      const stack = container.getItem(i);
      if (!stack || !accepts.has(stack.typeId)) continue;
      const g = getGenetics(stack);
      if (!g) continue;
      const id = registerGenetics(g);
      const dried = stack.typeId === "cc:bud" && isDried(stack);
      const key = `${stack.typeId}|${id}|${dried}`;
      if (seen.has(key)) continue;
      seen.add(key);
      candidates.push({ slot: i, typeId: stack.typeId, id, dried, genetics: g });
      if (candidates.length >= 16) break;
    }

    if (candidates.length === 0) {
      player.sendMessage(
        recipe.cart
          ? "§cYou need Distillate or Live Resin in your inventory to fill a cartridge."
          : recipe.accepts.length > 1
            ? "§cYou need buds, Shatter or Wax in your inventory to pack a bong."
            : "§cYou need harvested buds in your inventory to roll or pack."
      );
      return;
    }

    const form = new ModalFormData().title(`Make a ${recipe.label} (up to ${recipe.maxStrains} strains)`);
    for (const c of candidates) {
      form.toggle(`${strainName(c.genetics)}§r §7(${candidateKind(c)}, THC ${c.genetics.thc}%)`, {
        defaultValue: false
      });
    }

    const response = await showForm(player, form);
    if (!response || response.canceled) return;

    const chosen = candidates.filter((_, idx) => response.formValues[idx]);
    if (chosen.length === 0) {
      player.sendMessage("§cYou didn't pick any strains.");
      return;
    }
    if (chosen.length > recipe.maxStrains) {
      player.sendMessage(`§cA ${recipe.label} holds at most ${recipe.maxStrains} strains - you picked ${chosen.length}.`);
      return;
    }

    // Re-verify everything is still where it was when the form opened.
    const handNow = container.getItem(handSlot);
    if (!handNow || handNow.typeId !== handItem.typeId) {
      player.sendMessage("§cKeep holding the same item while the menu is open.");
      return;
    }
    for (const c of chosen) {
      const s = container.getItem(c.slot);
      const g = s && s.typeId === c.typeId ? getGenetics(s) : null;
      const dried = !!s && s.typeId === "cc:bud" && isDried(s);
      if (!g || registerGenetics(g) !== c.id || dried !== c.dried) {
        player.sendMessage("§cYour inventory changed while the menu was open - try again.");
        return;
      }
    }

    for (const c of chosen) consumeFromSlot(container, c.slot, 1);

    if (recipe.cart) {
      const cart = makeCartItem(chosen);
      consumeFromSlot(container, handSlot, 1);
      giveItem(player, cart);
      player.sendMessage(`§2Filled: §f${cart.nameTag}`);
      return;
    }

    const data = {
      thc: Math.round(chosen.reduce((s, c) => s + c.genetics.thc, 0) / chosen.length),
      effects: mergeEffects(chosen.map((c) => c.genetics.effects), 0),
      strains: chosen.map((c) => (c.typeId === "cc:bud" ? c.genetics.name : `${c.genetics.name} ${candidateKind(c)}`)),
      dryMult: chosen.reduce((s, c) => s + (c.dried ? DRIED_MULTIPLIER : 1), 0) / chosen.length
    };
    const label = chosen.every((c) => c.typeId !== "cc:bud") ? "Dab" : recipe.label;

    const product = new ItemStack(recipe.product, 1);
    product.setDynamicProperty("cc:smoke", JSON.stringify(data));
    product.nameTag =
      chosen.length === 1 ? `${strainName(chosen[0].genetics)} ${label}§r` : `§fMixed ${label}§r`;
    safeSetLore(product, [
      `§7THC: §f${data.thc}%`,
      "§7Strains:",
      ...data.strains.map((n) => `§7- §f${n}`),
      ...wrapList("§bEffects: §f", data.effects.map(([id, amp]) => effectLabel(id, amp)))
    ]);

    if (recipe.replaceInHand) {
      container.setItem(handSlot, product);
    } else {
      consumeFromSlot(container, handSlot, 1);
      giveItem(player, product);
    }
    player.sendMessage(`§2Made: §f${product.nameTag}`);
  } catch (e) {
    player.sendMessage(`§cRolling table error: ${e}`);
  }
}

function candidateKind(c) {
  if (c.typeId === "cc:bud") return c.dried ? "Dried" : "Wet";
  const procKey = DISTILL_ORDER.find((k) => DISTILL_PROCESSES[k].item === c.typeId);
  return procKey ? DISTILL_PROCESSES[procKey].name : c.typeId;
}

/* ------------------------------ Vape cartridges ---------------------------- */
/* Filled carts stack to 16: their strain blend lives in the genetics registry
   (lore ID), exactly like buds. A vape pen is crafted from a Vape Battery + a
   filled cart in a crafting table. Crafting can't carry item data, so a watcher
   notices a filled cart leaving the inventory and a blank pen appearing, and
   copies that cart's contents into the pen. */

function makeCartItem(chosen) {
  const list = chosen.map((c) => c.genetics);
  const blend =
    list.length === 1
      ? list[0]
      : {
          key: null,
          name: list.map((g) => g.name).join(" / "),
          color: list[0].color,
          thc: Math.round(list.reduce((s, g) => s + g.thc, 0) / list.length),
          yieldStat: 0,
          growth: 1,
          effects: mergeEffects(list.map((g) => g.effects), 0),
          gen: 0,
          boosted: false
        };
  const kinds = new Set(chosen.map((c) => CART_FILLS[c.typeId]));
  const kind = kinds.size === 1 ? [...kinds][0] : "Mixed";
  const item = new ItemStack("cc:cart_filled", 1);
  item.nameTag =
    list.length === 1 ? `${strainName(blend)} ${kind} Cart§r` : `§fMixed ${kind === "Mixed" ? "" : kind + " "}Cart§r`;
  safeSetLore(item, [
    `§7THC: §f${blend.thc}%`,
    CART_KIND_PREFIX + kind,
    "§7Strains:",
    ...list.map((g) => `§7- §f${g.name}`),
    ...wrapList("§bEffects: §f", blend.effects.map(([id, amp]) => effectLabel(id, amp))),
    ID_PREFIX + registerGenetics(blend)
  ]);
  return item;
}

function readCart(stack) {
  const g = getGenetics(stack);
  if (!g) return null;
  const lore = readLore(stack);
  const kindLine = lore.find((l) => l.startsWith(CART_KIND_PREFIX));
  const strains = lore.filter((l) => l.startsWith("§7- §f")).map((l) => l.slice(6));
  return {
    thc: g.thc,
    effects: g.effects,
    strains: strains.length ? strains : [g.name],
    kind: kindLine ? kindLine.slice(CART_KIND_PREFIX.length) : "Distillate",
    name: g.name,
    color: g.color
  };
}

// Used if a pen shows up with no cart to match (e.g. crafted with a cart taken straight from a chest).
const UNKNOWN_CART = { thc: 90, effects: [["regeneration", 0]], strains: ["Unknown"], kind: "Distillate", name: "Unknown", color: "§7" };

function loadPen(container, slot, cart) {
  const pen = container.getItem(slot);
  if (!pen || pen.typeId !== "cc:vape_pen") return;
  const c = cart ?? UNKNOWN_CART;
  pen.setDynamicProperty("cc:smoke", JSON.stringify({ thc: c.thc, effects: c.effects, strains: c.strains, dryMult: 1 }));
  pen.nameTag = c.strains.length === 1 ? `${strainName(c)} Vape§r` : "§fMixed Vape§r";
  safeSetLore(pen, [
    `§7THC: §f${c.thc}%`,
    CART_KIND_PREFIX + c.kind,
    "§7Strains:",
    ...c.strains.map((n) => `§7- §f${n}`),
    ...wrapList("§bEffects: §f", c.effects.map(([id, amp]) => effectLabel(id, amp)))
  ]);
  container.setItem(slot, pen);
}

// player id -> { counts: Map(signature -> { count, cart }), pending: [{ sig, cart, t }] }
const cartWatch = new Map();
function cartSignature(stack) {
  return `${stack.nameTag ?? ""}|${readLore(stack).join("~")}`;
}

function watchCarts(player) {
  const container = player.getComponent("minecraft:inventory").container;
  const counts = new Map();
  const blankPens = [];
  for (let i = 0; i < container.size; i++) {
    const stack = container.getItem(i);
    if (!stack) continue;
    if (stack.typeId === "cc:cart_filled") {
      const sig = cartSignature(stack);
      const prev = counts.get(sig);
      if (prev) prev.count += stack.amount;
      else counts.set(sig, { count: stack.amount, cart: readCart(stack) });
    } else if (stack.typeId === "cc:vape_pen" && stack.getDynamicProperty("cc:smoke") === undefined) {
      blankPens.push(i);
    }
  }

  const now = Date.now();
  let w = cartWatch.get(player.id);
  if (!w) {
    w = { counts, pending: [] };
    cartWatch.set(player.id, w);
  } else {
    // Carts that left the inventory might be sitting in a crafting grid.
    for (const [sig, prev] of w.counts) {
      const gone = prev.count - (counts.get(sig)?.count ?? 0);
      for (let k = 0; k < gone; k++) w.pending.push({ sig, cart: prev.cart, t: now });
    }
    // Carts that came back (moved around, crafting cancelled) are no longer candidates.
    for (const [sig, cur] of counts) {
      let back = cur.count - (w.counts.get(sig)?.count ?? 0);
      for (let k = w.pending.length - 1; k >= 0 && back > 0; k--) {
        if (w.pending[k].sig === sig) {
          w.pending.splice(k, 1);
          back--;
        }
      }
    }
    w.pending = w.pending.filter((p) => now - p.t < VAPE_LINK_WINDOW_MS).slice(-64);
    w.counts = counts;
  }

  for (const slot of blankPens) {
    const match = w.pending.pop();
    loadPen(container, slot, match ? match.cart : null);
  }
}

system.runInterval(() => {
  for (const player of world.getAllPlayers()) {
    try {
      watchCarts(player);
    } catch (e) {
      /* player mid-load - try next time */
    }
  }
}, 10);

world.afterEvents.playerLeave.subscribe((evt) => cartWatch.delete(evt.playerId));

/* --------------------------------- Effects -------------------------------- */

function applyEffects(player, effects, thc, baseTicks) {
  const bonus = thc > 25 ? 1 : 0;
  for (const [id, amp] of effects) {
    const duration = FIXED_DURATION[id] ?? Math.round(baseTicks * thcDurationMult(thc));
    const amplifier = NO_THC_BONUS.has(id) ? amp : clamp(amp + bonus, 0, MAX_EFFECT_AMP);
    try {
      player.addEffect(id, duration, { amplifier, showParticles: false });
    } catch (e) {
      /* unknown effect id on this game version - skip */
    }
  }
}

function puffSmoke(player) {
  try {
    const head = player.getHeadLocation();
    const dir = player.getViewDirection();
    for (let i = 0; i < 4; i++) {
      player.dimension.spawnParticle("minecraft:basic_smoke_particle", {
        x: head.x + dir.x * 0.6 + (Math.random() - 0.5) * 0.2,
        y: head.y + dir.y * 0.6 + Math.random() * 0.2,
        z: head.z + dir.z * 0.6 + (Math.random() - 0.5) * 0.2
      });
    }
  } catch (e) {
    /* cosmetic only */
  }
}

// `heldStack` is the snapshot handed to us by the itemCompleteUse event, taken
// at the moment the raise-to-mouth hold finished. We use that (rather than
// re-reading the slot) so this works no matter what happens to the stack in
// the meantime - we always finish by writing the correct next-stage item back
// ourselves.
// The slot a hit is taken from: the selected hotbar slot, or the offhand.
function smokeSlot(player, hand) {
  if (hand === "offhand") {
    const equip = player.getComponent("minecraft:equippable");
    return {
      getItem: () => equip.getEquipment(EquipmentSlot.Offhand),
      setItem: (stack) => equip.setEquipment(EquipmentSlot.Offhand, stack)
    };
  }
  const container = player.getComponent("minecraft:inventory").container;
  const slot = player.selectedSlotIndex;
  return { getItem: () => container.getItem(slot), setItem: (stack) => container.setItem(slot, stack) };
}

function takeHit(player, heldStack, hand = "main") {
  try {
    const target = smokeSlot(player, hand);
    const stack = heldStack ?? target.getItem();
    const info = stack ? SMOKABLES[stack.typeId] : undefined;
    if (!info) return;

    let stored;
    try {
      stored = stack.getDynamicProperty("cc:smoke");
    } catch (e) {
      /* stackable smokables (cigarettes) can't hold dynamic properties */
    }
    const data = safeParse(stored) ?? info.defaultSmoke ?? { thc: 15, effects: [["regeneration", 0]], dryMult: 1 };
    applyEffects(player, data.effects, data.thc, Math.round(info.ticks * (data.dryMult ?? 1)));
    puffSmoke(player);

    // Hit count is tracked entirely by us (not by the item's built-in durability),
    // so it can never be thrown off by whatever the vanilla "food" consumption
    // mechanic does to the stack/durability once the raise-to-mouth hold completes.
    const durability = stack.getComponent("minecraft:durability");
    let usedBefore = 0;
    try {
      usedBefore = stack.getDynamicProperty("cc:uses") ?? 0;
    } catch (e) {
      /* stackable - always a single hit */
    }
    const used = usedBefore + 1;
    const max = durability ? durability.maxDurability : info.uses;

    if (used >= max) {
      if (info.emptyInto) {
        target.setItem(new ItemStack(info.emptyInto, 1));
        player.onScreenDisplay.setActionBar(info.emptyMessage ?? "§7Finished.");
      } else if ((target.getItem()?.typeId === stack.typeId ? target.getItem().amount : 1) > 1) {
        const rest = target.getItem(); // a stack of cigarettes: only one is smoked
        rest.amount -= 1;
        target.setItem(rest);
        player.onScreenDisplay.setActionBar(`${info.emptyMessage ?? "§7Finished."} §8(${rest.amount} left)`);
      } else {
        target.setItem(undefined);
        player.onScreenDisplay.setActionBar(info.emptyMessage ?? "§7Finished.");
      }
      return;
    }

    const stageIdx = Math.min(info.stages.length - 1, Math.floor((used * info.stages.length) / max));
    const stageId = (info.litStages ?? info.stages)[stageIdx]; // packs come out lit: cigarette stays at the mouth
    let out = stack;
    if (stageId !== stack.typeId) {
      // Swap to the next visual stage, carrying over everything that matters.
      out = new ItemStack(stageId, 1);
      out.nameTag = stack.nameTag;
      safeSetLore(out, readLore(stack));
      const smoke = stack.getDynamicProperty("cc:smoke");
      if (smoke !== undefined) out.setDynamicProperty("cc:smoke", smoke);
    }
    // "cc:uses" is the source of truth; durability.damage is set purely so the
    // item's built-in wear bar matches it visually - it's never read back.
    out.setDynamicProperty("cc:uses", used);
    const outDurability = out.getComponent("minecraft:durability");
    if (outDurability) outDurability.damage = used;
    target.setItem(out);
    player.onScreenDisplay.setActionBar(`§7Hits left: §f${max - used}`);
  } catch (e) {
    player.sendMessage(`§cSmoking error: ${e}`);
  }
}

// Smokeables now raise to the mouth and hold there for their use_duration
// (see "minecraft:use_animation" + "minecraft:use_modifiers" on each item
// stage) - the hit itself only lands once that hold completes, not the instant
// the button is pressed. Letting go early cancels it.
//
// The pose stage itself is tracked via "cc:smoke_stage" (0 = none, 1 = one-handed,
// 2 = two-handed) - set the moment the hold starts, cleared the moment it ends
// for any reason. No longer read client-side (see note above) - kept as internal
// state in case the pose animation is reimplemented via a Persona-safe method later.
function clearSmokePose(source) {
  try {
    if (source.getDynamicProperty("cc:smoke_stage") !== 0) source.setDynamicProperty("cc:smoke_stage", 0);
  } catch (e) {
    /* non-critical */
  }
}

// Continuous smoke puffs while actually holding down use on a smokable -
// piggybacks on the same "cc:smoke_stage" dynamic property (>0 while in use,
// 0 otherwise), so no extra tracking is needed. Runs every 4 ticks (~0.2s) for
// a steady trickle rather than the bigger 4-particle burst puffSmoke() does
// once, on hit completion.
system.runInterval(() => {
  for (const player of world.getAllPlayers()) {
    let stage;
    try {
      stage = player.getDynamicProperty("cc:smoke_stage");
    } catch (e) {
      continue;
    }
    if (!stage) continue;
    try {
      const head = player.getHeadLocation();
      const dir = player.getViewDirection();
      player.dimension.spawnParticle("minecraft:basic_smoke_particle", {
        x: head.x + dir.x * 0.6 + (Math.random() - 0.5) * 0.15,
        y: head.y + dir.y * 0.6 + Math.random() * 0.15,
        z: head.z + dir.z * 0.6 + (Math.random() - 0.5) * 0.15
      });
    } catch (e) {
      /* cosmetic only */
    }
  }
}, 4);

world.afterEvents.itemUse.subscribe((evt) => {
  const { itemStack, source } = evt;
  if (!itemStack || !source) return;
  if (itemStack.typeId === "cc:bong") {
    debounced(source, "bong_empty", 1500, () =>
      source.sendMessage("§7This bong is empty - pack it with buds at a Rolling Table.")
    );
  }
});

world.afterEvents.itemStartUse.subscribe((evt) => {
  const { itemStack, source } = evt;
  if (!itemStack || !source) return;
  const fam = SMOKABLES[itemStack.typeId];
  if (!fam) return;
  try {
    source.setDynamicProperty("cc:smoke_stage", fam.poseStage);
  } catch (e) {
    /* non-critical */
  }
});

world.afterEvents.itemReleaseUse.subscribe((evt) => {
  if (evt.source) clearSmokePose(evt.source);
});

world.afterEvents.itemStopUse.subscribe((evt) => {
  if (evt.source) clearSmokePose(evt.source);
});

world.afterEvents.itemCompleteUse.subscribe((evt) => {
  const { itemStack, source } = evt;
  if (!itemStack || !source) return;
  if (SMOKABLES[itemStack.typeId]) {
    clearSmokePose(source);
    try {
      source.playSound("cc.smoke_hit", { volume: 1, pitch: 0.95 + Math.random() * 0.1 });
    } catch (e) {
      /* cosmetic only */
    }
    system.run(() => takeHit(source, itemStack));
    return;
  }
  if (itemStack.typeId === "cc:bud") {
    const g = getGenetics(itemStack) ?? baseGenetics("og_kush");
    const mult = isDried(itemStack) ? DRIED_MULTIPLIER : 1;
    applyEffects(source, g.effects, g.thc, Math.round(BUD_EFFECT_TICKS * mult));
  }
});

// Lit cigarette packs (cigarette at the mouth) only stay lit in the selected hotbar slot or the offhand.
// Anywhere else - switched away, moved into the inventory - they go back to the normal pack, keeping their hits.
function unlitPack(stack) {
  const out = new ItemStack(UNLIT[stack.typeId], 1);
  if (stack.nameTag) out.nameTag = stack.nameTag;
  safeSetLore(out, readLore(stack));
  try {
    for (const key of ["cc:uses", "cc:smoke"]) {
      const v = stack.getDynamicProperty(key);
      if (v !== undefined) out.setDynamicProperty(key, v);
    }
    const from = stack.getComponent("minecraft:durability"), to = out.getComponent("minecraft:durability");
    if (from && to) to.damage = from.damage;
  } catch (e) {
    /* keep going - the swap matters more than the wear bar */
  }
  return out;
}

function revertLitPacks(player) {
  const container = player.getComponent("minecraft:inventory").container;
  let n = 0;
  for (let i = 0; i < container.size; i++) {
    if (i === player.selectedSlotIndex) continue;
    const stack = container.getItem(i);
    if (stack && UNLIT[stack.typeId]) {
      container.setItem(i, unlitPack(stack));
      n++;
    }
  }
  return n;
}

world.afterEvents.playerHotbarSelectedSlotChange.subscribe((evt) => {
  system.run(() => {
    try {
      revertLitPacks(evt.player);
    } catch (e) {
      /* player left */
    }
  });
});

system.runInterval(() => {
  for (const player of world.getAllPlayers()) {
    try {
      revertLitPacks(player);
    } catch (e) {
      /* player leaving */
    }
  }
}, 10);

// Offhand smoking: Bedrock only "uses" the main-hand item, so a hit from the offhand is
// double-tap sneak and HOLD the second press for the item's drag time (letting go early cancels).
// The attachable controller (cc_smokable_pose) watches for the same input to play the raise pose,
// so keep DOUBLE_TAP_TICKS in step with its 0.4-second window.
const DOUBLE_TAP_TICKS = 8; // 0.4 seconds
const sneakTaps = new Map(); // player id -> { down, lastPress, hold: { start, dragTicks } | null }

function offhandSmokable(player) {
  try {
    const stack = player.getComponent("minecraft:equippable").getEquipment(EquipmentSlot.Offhand);
    const fam = stack ? SMOKABLES[stack.typeId] : undefined;
    return fam ? { stack, fam } : undefined;
  } catch (e) {
    return undefined;
  }
}

function offhandHit(player) {
  const held = offhandSmokable(player);
  if (!held) return;
  try {
    player.playSound("cc.smoke_hit", { volume: 1, pitch: 0.95 + Math.random() * 0.1 });
  } catch (e) {
    /* cosmetic only */
  }
  takeHit(player, held.stack, "offhand");
}

function onSneakSample(player, sneaking, tick) {
  const state = sneakTaps.get(player.id) ?? { down: false, lastPress: -1000, hold: null };
  state.player = player;
  if (sneaking && !state.down) {
    if (tick - state.lastPress <= DOUBLE_TAP_TICKS) {
      state.lastPress = -1000; // a third tap starts a new pair
      const held = offhandSmokable(player);
      if (held) {
        state.hold = { start: tick, dragTicks: Math.round(held.fam.dragMs / 50) };
        try {
          player.setDynamicProperty("cc:smoke_stage", held.fam.poseStage); // smoke trickle while holding
        } catch (e) {
          /* non-critical */
        }
      }
    } else {
      state.lastPress = tick;
    }
  }
  if (sneaking && state.hold && tick - state.hold.start >= state.hold.dragTicks) {
    state.hold = null;
    clearSmokePose(player);
    offhandHit(player);
  }
  if (!sneaking && state.hold) {
    state.hold = null; // let go early - no hit
    clearSmokePose(player);
  }
  state.down = sneaking;
  sneakTaps.set(player.id, state);
}

// Sneak presses/releases arrive as button events; only players mid-hold are checked every tick.
world.afterEvents.playerButtonInput.subscribe((evt) => {
  if (evt.button !== InputButton.Sneak) return;
  try {
    onSneakSample(evt.player, evt.newButtonState === ButtonState.Pressed, system.currentTick);
  } catch (e) {
    /* player leaving */
  }
});

function tickOffhandHolds(tick) {
  for (const [id, state] of sneakTaps) {
    if (!state.hold) continue;
    try {
      if (!state.player.isValid) {
        sneakTaps.delete(id);
        continue;
      }
      onSneakSample(state.player, state.down, tick);
    } catch (e) {
      sneakTaps.delete(id);
    }
  }
}

system.runInterval(() => tickOffhandHolds(system.currentTick), 1);

world.afterEvents.playerLeave.subscribe((evt) => sneakTaps.delete(evt.playerId));


/* ------------------------------ Drying Rack -------------------------------- */
/* Contents are saved in world storage keyed by the rack's position. Each batch
   has its own real-time start stamp, so drying continues even if you leave the
   area or close the world, and batches added later finish later. */

function rackKey(dimId, loc) {
  return `cc:rack:${dimId}:${loc.x},${loc.y},${loc.z}`;
}
function parseRackKey(key) {
  const m = key.match(/^cc:rack:(.+):(-?\d+),(-?\d+),(-?\d+)$/);
  return m ? { dimId: m[1], loc: { x: +m[2], y: +m[3], z: +m[4] } } : null;
}
function readRackIndex() {
  return safeParse(world.getDynamicProperty(RACK_INDEX_PROP)) ?? [];
}
function writeRackIndex(list) {
  world.setDynamicProperty(RACK_INDEX_PROP, JSON.stringify(list));
}
function loadRack(key) {
  return safeParse(world.getDynamicProperty(key)) ?? { entries: [] };
}
function saveRack(key, rack) {
  const index = readRackIndex();
  if (rack.entries.length === 0) {
    world.setDynamicProperty(key, undefined);
    if (index.includes(key)) writeRackIndex(index.filter((k) => k !== key));
  } else {
    world.setDynamicProperty(key, JSON.stringify(rack));
    if (!index.includes(key)) writeRackIndex([...index, key]);
  }
}
function isBatchDone(entry, now) {
  return now - entry.start >= DRY_MS;
}
function rackStatus(rack, now) {
  if (rack.entries.length === 0) return 0;
  return rack.entries.every((e) => isBatchDone(e, now)) ? 2 : 1;
}
function updateRackVisual(dimId, loc, rack) {
  try {
    const block = world.getDimension(dimId).getBlock(loc);
    if (!block || block.typeId !== "cc:drying_rack") return;
    const status = rackStatus(rack, Date.now());
    if (block.permutation.getState("cc:status") !== status) {
      block.setPermutation(block.permutation.withState("cc:status", status));
    }
  } catch (e) {
    /* chunk unloaded - visual catches up next check */
  }
}
function progressBar(fraction) {
  const filled = Math.round(fraction * 20);
  return `§a${"|".repeat(filled)}§8${"|".repeat(20 - filled)}`;
}
function formatTime(ms) {
  const total = Math.max(0, Math.ceil(ms / 1000));
  return `${Math.floor(total / 60)}:${String(total % 60).padStart(2, "0")}`;
}
// Tobacco leaves dry on the rack too: their batches use this id instead of a genetics id.
const TOBACCO_BATCH = "tobacco";
const TOBACCO_LABEL = { name: "Tobacco Leaf", color: "§6" };
function batchToItem(entry, dried) {
  if (entry.id === TOBACCO_BATCH) return new ItemStack(dried ? "cc:dried_tobacco" : "cc:tobacco_leaf", entry.amount);
  const g = lookupGenetics(entry.id) ?? baseGenetics("og_kush");
  return makeBudItem(g, entry.amount, dried);
}

async function openRack(player, dimId, loc) {
  try {
    const key = rackKey(dimId, loc);
    const rack = loadRack(key);
    const now = Date.now();
    const used = rack.entries.reduce((s, e) => s + e.amount, 0);
    const doneCount = rack.entries.filter((e) => isBatchDone(e, now)).reduce((s, e) => s + e.amount, 0);

    const lines = [`§7Capacity: §f${used}/${RACK_CAPACITY}`, ""];
    if (rack.entries.length === 0) lines.push("§7Empty. Add wet buds or tobacco leaves to start drying (2 minutes).");
    for (const e of rack.entries) {
      const g = e.id === TOBACCO_BATCH ? TOBACCO_LABEL : lookupGenetics(e.id);
      const frac = clamp((now - e.start) / DRY_MS, 0, 1);
      lines.push(`${g?.color ?? "§f"}${g?.name ?? "Unknown"} §7x${e.amount}`);
      lines.push(
        frac >= 1
          ? `${progressBar(1)} §2Done!`
          : `${progressBar(frac)} §f${Math.floor(frac * 100)}% §7(${formatTime(DRY_MS - (now - e.start))} left)`
      );
    }

    const actions = [];
    const form = new ActionFormData().title("Drying Rack").body(lines.join("\n"));
    if (used < RACK_CAPACITY) {
      form.button("Add buds or tobacco");
      actions.push("add");
    }
    if (doneCount > 0) {
      form.button(`Collect dried items (${doneCount})`);
      actions.push("collect");
    }
    if (rack.entries.length > 0) {
      form.button("Refresh progress");
      actions.push("refresh");
      form.button("§4Take everything out");
      actions.push("remove");
    }
    form.button("Close");
    actions.push("close");

    const res = await showForm(player, form);
    if (!res || res.canceled) return;
    const action = actions[res.selection];

    if (action === "add") {
      await addToRack(player, dimId, loc);
    } else if (action === "collect") {
      const fresh = loadRack(key);
      const t = Date.now();
      const done = fresh.entries.filter((e) => isBatchDone(e, t));
      fresh.entries = fresh.entries.filter((e) => !isBatchDone(e, t));
      for (const e of done) giveItem(player, batchToItem(e, true));
      saveRack(key, fresh);
      updateRackVisual(dimId, loc, fresh);
      player.onScreenDisplay.setActionBar(`§6Collected ${done.reduce((s, e) => s + e.amount, 0)} dried items`);
      if (fresh.entries.length > 0) await openRack(player, dimId, loc);
    } else if (action === "refresh") {
      await openRack(player, dimId, loc);
    } else if (action === "remove") {
      const fresh = loadRack(key);
      const t = Date.now();
      for (const e of fresh.entries) giveItem(player, batchToItem(e, isBatchDone(e, t)));
      fresh.entries = [];
      saveRack(key, fresh);
      updateRackVisual(dimId, loc, fresh);
    }
  } catch (e) {
    player.sendMessage(`§cDrying rack error: ${e}`);
  }
}

async function addToRack(player, dimId, loc) {
  const container = player.getComponent("minecraft:inventory").container;
  const key = rackKey(dimId, loc);

  const candidates = [];
  for (let i = 0; i < container.size; i++) {
    const stack = container.getItem(i);
    if (stack?.typeId === "cc:tobacco_leaf") {
      candidates.push({ slot: i, id: TOBACCO_BATCH, genetics: TOBACCO_LABEL, amount: stack.amount });
      continue;
    }
    if (!stack || stack.typeId !== "cc:bud" || isDried(stack)) continue;
    const g = getGenetics(stack);
    if (g) candidates.push({ slot: i, id: registerGenetics(g), genetics: g, amount: stack.amount });
  }
  if (candidates.length === 0) {
    player.sendMessage("§cYou don't have any wet buds or tobacco leaves. Freshly harvested buds are wet.");
    return;
  }

  const used = loadRack(key).entries.reduce((s, e) => s + e.amount, 0);
  const space = RACK_CAPACITY - used;
  const form = new ModalFormData()
    .title("Add to the Rack")
    .dropdown(
      `§7Space left: §f${space}`,
      candidates.map((c) => `${strainName(c.genetics)}§r §7x${c.amount}`),
      { defaultValueIndex: 0 }
    )
    .slider("How many?", 1, Math.max(1, space), { valueStep: 1, defaultValue: Math.min(space, candidates[0].amount) });

  const res = await showForm(player, form);
  if (!res || res.canceled) return;
  const [idx, requested] = res.formValues;
  const c = candidates[idx];
  if (!c) return;

  const stack = container.getItem(c.slot);
  const stillThere =
    c.id === TOBACCO_BATCH
      ? stack?.typeId === "cc:tobacco_leaf"
      : !!stack && stack.typeId === "cc:bud" && !isDried(stack) && registerGenetics(getGenetics(stack)) === c.id;
  if (!stillThere) {
    player.sendMessage("§cYour inventory changed while the menu was open - try again.");
    return;
  }

  const fresh = loadRack(key);
  const freeNow = RACK_CAPACITY - fresh.entries.reduce((s, e) => s + e.amount, 0);
  const amount = Math.min(Math.round(requested), stack.amount, freeNow);
  if (amount <= 0) {
    player.sendMessage("§cThe rack is full.");
    return;
  }

  consumeFromSlot(container, c.slot, amount);
  fresh.entries.push({ id: c.id, amount, start: Date.now() });
  saveRack(key, fresh);
  updateRackVisual(dimId, loc, fresh);
  player.onScreenDisplay.setActionBar(`§2Hung ${amount} ${c.id === TOBACCO_BATCH ? "tobacco leaves" : "buds"} to dry - ready in 2:00`);
  await openRack(player, dimId, loc);
}

function dropRackContents(dimension, loc, key) {
  const rack = loadRack(key);
  const now = Date.now();
  const at = { x: loc.x + 0.5, y: loc.y + 0.5, z: loc.z + 0.5 };
  for (const e of rack.entries) {
    try {
      dimension.spawnItem(batchToItem(e, isBatchDone(e, now)), at);
    } catch (err) {
      /* spawn failed - skip */
    }
  }
  saveRack(key, { entries: [] });
}

// Every 2 seconds: flip rack visuals to "done", and clean up racks destroyed by explosions etc.
system.runInterval(() => {
  let index;
  try {
    index = readRackIndex();
  } catch (e) {
    return;
  }
  for (const key of index) {
    const parsed = parseRackKey(key);
    if (!parsed) continue;
    try {
      const dimension = world.getDimension(parsed.dimId);
      const block = dimension.getBlock(parsed.loc);
      if (!block) continue; // not loaded
      if (block.typeId !== "cc:drying_rack") {
        dropRackContents(dimension, parsed.loc, key);
        continue;
      }
      updateRackVisual(parsed.dimId, parsed.loc, loadRack(key));
    } catch (e) {
      /* unloaded chunk or dimension - try next time */
    }
  }
}, 40);


/* -------------------------------- Nug Press -------------------------------- */
/* Two-part block: the base press + a swappable pressing plate stored in the block
   state (so the plate survives unloads with no extra storage). Shift + left-click
   swaps plates; right-click opens the pressing menu. Rosin keeps the strain's
   genetics and whether it came from wet or dried buds (the distiller uses that). */

// Rosin is a concentrate: 65-75% THC. Stronger buds, better plates and dried buds push it higher.
// No randomness, so identical presses give identical (stackable) rosin.
const ROSIN_THC_MIN = 65;
const ROSIN_THC_MAX = 75;
function rosinThc(budThc, plateTier, fromDried) {
  const raw = ROSIN_THC_MIN + (budThc - THC_BASELINE) * 0.25 + (plateTier - 1) + (fromDried ? 1 : 0);
  return clamp(Math.round(raw), ROSIN_THC_MIN, ROSIN_THC_MAX);
}

function makeRosinItem(g, amount, fromDried) {
  const item = new ItemStack("cc:rosin", amount);
  item.nameTag = `${strainName(g)} Rosin§r`;
  safeSetLore(item, geneticsLore(g, fromDried ? "§7Pressed from: §6Dried buds" : "§7Pressed from: §bWet buds"));
  return item;
}

function getPressBlock(dimId, loc) {
  try {
    const block = world.getDimension(dimId).getBlock(loc);
    return block && block.typeId === "cc:nug_press" ? block : undefined;
  } catch (e) {
    return undefined;
  }
}

function setPressState(block, state, value) {
  try {
    block.setPermutation(block.permutation.withState(state, value));
  } catch (e) {
    /* block changed underneath us - ignore */
  }
}

function swapPressPlate(player, dimId, loc) {
  const block = getPressBlock(dimId, loc);
  if (!block) return;
  if (block.permutation.getState("cc:pressing")) {
    player.onScreenDisplay.setActionBar("§cWait for the press to finish.");
    return;
  }
  const container = player.getComponent("minecraft:inventory").container;
  const slot = player.selectedSlotIndex;
  const hand = container.getItem(slot);
  const current = block.permutation.getState("cc:plate") ?? 0;
  const incoming = hand ? PRESS_PLATES[hand.typeId] : undefined;

  if (incoming) {
    if (incoming.tier === current) {
      player.onScreenDisplay.setActionBar(`§7A ${incoming.name} plate is already installed.`);
      return;
    }
    consumeFromSlot(container, slot, 1);
    if (current > 0) giveItem(player, new ItemStack(PLATE_BY_TIER[current].id, 1));
    setPressState(block, "cc:plate", incoming.tier);
    try {
      player.dimension.playSound("random.anvil_use", block.location, { volume: 0.4, pitch: 1.6 });
    } catch (e) {
      /* cosmetic */
    }
    player.onScreenDisplay.setActionBar(
      `§aInstalled ${incoming.name} plate §7(${Math.round(incoming.rate * 100)}% rosin per bud)`
    );
  } else if (current > 0) {
    giveItem(player, new ItemStack(PLATE_BY_TIER[current].id, 1));
    setPressState(block, "cc:plate", 0);
    player.onScreenDisplay.setActionBar(`§7Removed the ${PLATE_BY_TIER[current].name} plate.`);
  } else {
    player.onScreenDisplay.setActionBar("§eShift + left-click with a pressing plate to install it.");
  }
}

async function openPress(player, dimId, loc) {
  try {
    const block = getPressBlock(dimId, loc);
    if (!block) return;
    if (block.permutation.getState("cc:pressing")) {
      player.onScreenDisplay.setActionBar("§7The press is already working...");
      return;
    }
    const tier = block.permutation.getState("cc:plate") ?? 0;
    const plate = PLATE_BY_TIER[tier];

    const body = plate
      ? [
          `§7Plate: §f${plate.name}`,
          `§7Yield: §f${formPct(plate.rate)} §7rosin per bud`,
          `§7Buds per press: §f${PRESS_MIN_BUDS}-${PRESS_MAX_BUDS}`,
          "",
          `§8Plates: ${Object.values(PRESS_PLATES).map((p) => `${p.name} ${formPct(p.rate)}`).join(" < ")}`,
          "§8Shift + left-click the press with a plate to swap it."
        ]
      : ["§cNo pressing plate installed.", "", "§7Shift + left-click the press while holding a", "§7pressing plate to install one."];

    const form = new ActionFormData().title("Nug Press").body(body.join("\n"));
    const actions = [];
    if (plate) {
      form.button("Press buds");
      actions.push("press");
    }
    form.button("Close");
    actions.push("close");

    const res = await showForm(player, form);
    if (!res || res.canceled || actions[res.selection] !== "press") return;
    await pressBuds(player, dimId, loc);
  } catch (e) {
    player.sendMessage(`§cNug press error: ${e}`);
  }
}

async function pressBuds(player, dimId, loc) {
  const container = player.getComponent("minecraft:inventory").container;

  // One entry per strain + state, totalled across every slot holding it.
  const groups = new Map();
  for (let i = 0; i < container.size; i++) {
    const stack = container.getItem(i);
    if (!stack || stack.typeId !== "cc:bud") continue;
    const g = getGenetics(stack);
    if (!g) continue;
    const id = registerGenetics(g);
    const dried = isDried(stack);
    const key = `${id}|${dried}`;
    if (!groups.has(key)) groups.set(key, { id, dried, genetics: g, amount: 0 });
    groups.get(key).amount += stack.amount;
  }
  if (groups.size === 0) {
    player.sendMessage("§cYou need buds in your inventory to press.");
    return;
  }
  const candidates = [...groups.values()].filter((c) => c.amount >= PRESS_MIN_BUDS);
  if (candidates.length === 0) {
    player.sendMessage(`§cYou need at least ${PRESS_MIN_BUDS} buds of the same strain to press.`);
    return;
  }

  const form = new ModalFormData()
    .title("Press Buds")
    .dropdown(
      "Buds to press",
      candidates.map((c) => `${strainName(c.genetics)}§r §7x${c.amount} (${c.dried ? "Dried" : "Wet"})`),
      { defaultValueIndex: 0 }
    )
    .slider("How many?", PRESS_MIN_BUDS, PRESS_MAX_BUDS, {
      valueStep: 1,
      defaultValue: Math.min(PRESS_MAX_BUDS, candidates[0].amount)
    });

  const res = await showForm(player, form);
  if (!res || res.canceled) return;
  const [idx, requested] = res.formValues;
  const c = candidates[idx];
  if (!c) return;

  const block = getPressBlock(dimId, loc);
  if (!block || block.permutation.getState("cc:pressing")) return;
  const plate = PLATE_BY_TIER[block.permutation.getState("cc:plate") ?? 0];
  if (!plate) {
    player.sendMessage("§cThe plate was removed - install one first.");
    return;
  }

  // Re-count after the form closes - the player may have moved or dropped buds.
  const slots = [];
  let have = 0;
  for (let i = 0; i < container.size; i++) {
    const stack = container.getItem(i);
    if (!stack || stack.typeId !== "cc:bud" || isDried(stack) !== c.dried) continue;
    const sg = getGenetics(stack);
    if (!sg || registerGenetics(sg) !== c.id) continue;
    slots.push(i);
    have += stack.amount;
  }
  const amount = Math.min(Math.round(requested), PRESS_MAX_BUDS, have);
  if (amount < PRESS_MIN_BUDS) {
    player.sendMessage("§cYour inventory changed while the menu was open - try again.");
    return;
  }
  const g = c.genetics;
  let left = amount;
  for (const i of slots) {
    if (left <= 0) break;
    const take = Math.min(left, container.getItem(i).amount);
    consumeFromSlot(container, i, take);
    left -= take;
  }

  // Probabilistic rounding: 6 buds on a copper plate = 1.2 rosin -> 1, with a 20% chance of 2.
  const expected = amount * plate.rate;
  const rosin = Math.floor(expected) + (Math.random() < expected - Math.floor(expected) ? 1 : 0);

  setPressState(block, "cc:pressing", true);
  try {
    player.dimension.playSound("tile.piston.out", block.location, { volume: 0.6, pitch: 0.8 });
  } catch (e) {
    /* cosmetic */
  }
  player.onScreenDisplay.setActionBar(`§7Pressing ${amount} buds...`);

  system.runTimeout(() => finishPress(player, dimId, loc, g, rosin, c.dried, amount, plate.tier), PRESS_TICKS);
}

function finishPress(player, dimId, loc, g, rosin, fromDried, buds, plateTier) {
  const block = getPressBlock(dimId, loc);
  if (block) {
    setPressState(block, "cc:pressing", false);
    try {
      block.dimension.playSound("tile.piston.in", block.location, { volume: 0.6, pitch: 0.8 });
    } catch (e) {
      /* cosmetic */
    }
  }
  const message =
    rosin > 0
      ? `§6Pressed ${buds} buds into ${rosin} rosin`
      : `§7${buds} buds weren't enough to get any rosin with this plate.`;
  try {
    if (rosin > 0) {
      const item = makeRosinItem({ ...g, thc: rosinThc(g.thc, plateTier, fromDried) }, rosin, fromDried);
      if (block && player.isValid) {
        block.dimension.spawnItem(item, { x: loc.x + 0.5, y: loc.y + 1.1, z: loc.z + 0.5 });
      } else if (player.isValid) {
        giveItem(player, item); // press was broken mid-press - don't lose the rosin
      }
    }
    if (player.isValid) player.onScreenDisplay.setActionBar(message);
  } catch (e) {
    /* player left - nothing more to do */
  }
}

// Shift + left-click (punch) the press to install/swap/remove its plate.
world.afterEvents.entityHitBlock.subscribe((evt) => {
  const player = evt.damagingEntity;
  const block = evt.hitBlock;
  if (!player || player.typeId !== "minecraft:player" || !block || block.typeId !== "cc:nug_press") return;
  if (!player.isSneaking) return;
  const dimId = block.dimension.id;
  const loc = { x: block.location.x, y: block.location.y, z: block.location.z };
  debounced(player, "press_plate", 400, () => system.run(() => swapPressPlate(player, dimId, loc)));
});

// Sneak-punching is for plates - never let it break the press (matters in creative, where one hit breaks blocks).
world.beforeEvents.playerBreakBlock.subscribe((evt) => {
  if (evt.block.typeId === "cc:nug_press" && evt.player.isSneaking) evt.cancel = true;
});

/* ------------------------- Plant markers & helpers ------------------------ */

function findMarker(dimension, loc) {
  try {
    const found = dimension.getEntities({
      families: ["cc_marker"],
      location: { x: loc.x + 0.5, y: loc.y, z: loc.z + 0.5 },
      maxDistance: 0.6,
      closest: 1
    });
    return found[0];
  } catch (e) {
    return undefined;
  }
}

// Flowering cannabis is tinted by strain (block state cc:tint -> textures cc_plant_3|4_<tint>, see
// cc_tools/gen_plants.py). 0 green, 1 purple, 2 frosty, 3 dark, 4 golden, 5 red.
const STRAIN_TINT = {
  og_kush: 0, green_crack: 0, george_droid: 0,
  purple_haze: 1, purple_nurple: 1, purple_punch: 1,
  blue_dream: 2, white_widow: 2, skywalker_og: 2, phantom_cookies: 2, poseidon_og: 2,
  gorilla_glue: 3, black_mamba: 3, sleepy_joe_og: 3,
  sour_diesel: 4, hero_haze: 4,
  tysgorilla: 5, tender_lad: 5
};
const COLOR_TINT = {
  "§5": 1, "§d": 1, "§u": 1,
  "§b": 2, "§3": 2, "§9": 2, "§s": 2, "§f": 2, "§7": 2, "§i": 2,
  "§8": 3, "§0": 3, "§j": 3,
  "§6": 4, "§e": 4, "§g": 4, "§p": 4, "§n": 4,
  "§c": 5, "§4": 5, "§m": 5
};
function tintFor(g) {
  if (!g) return 0;
  if (g.key && STRAIN_TINT[g.key] !== undefined && !(g.gen > 0)) return STRAIN_TINT[g.key];
  if (g.color === RAINBOW) return parseInt(hashString(g.name ?? ""), 36) % 6;
  return COLOR_TINT[g.color] ?? 0;
}

function setPlantTint(block, g) {
  try {
    const tint = tintFor(g);
    if (block.permutation.getState("cc:tint") !== tint) block.setPermutation(block.permutation.withState("cc:tint", tint));
  } catch (e) {
    /* cosmetic */
  }
}

function spawnMarker(dimension, loc, crop, genetics) {
  // A plant destroyed without a player breaking it (trampled farmland, water, explosion) leaves its
  // marker behind. Clear it so the new plant can't pick up the old plant's genetics.
  try {
    for (const old of dimension.getEntities({ families: ["cc_marker"], location: { x: loc.x + 0.5, y: loc.y, z: loc.z + 0.5 }, maxDistance: 0.6 })) old.remove();
  } catch (e) {
    /* nothing to clear */
  }
  const marker = dimension.spawnEntity("cc:genetics_marker", { x: loc.x + 0.5, y: loc.y, z: loc.z + 0.5 });
  marker.setDynamicProperty("cc:crop", crop);
  if (genetics) marker.setDynamicProperty("cc:genetics", JSON.stringify(genetics));
  return marker;
}

/* --------------------------- Bone meal & nutrients ------------------------ */

function boneMealGrowth(player, block) {
  try {
    const max = block.typeId === "cc:tobacco_plant" ? TOBACCO_MAX : CANNABIS_MAX;
    const growth = block.permutation.getState("cc:growth");
    if (growth === undefined || growth >= max) return;
    block.setPermutation(block.permutation.withState("cc:growth", growth + 1));
    try {
      block.dimension.spawnParticle("minecraft:crop_growth_emitter", {
        x: block.location.x + 0.5,
        y: block.location.y + 0.5,
        z: block.location.z + 0.5
      });
    } catch (e) {
      /* cosmetic */
    }
    consumeOneFromHand(player, "minecraft:bone_meal");
  } catch (e) {
    /* non-critical */
  }
}

function applyNutrient(player, block, type) {
  try {
    const growth = block.permutation.getState("cc:growth");
    if (growth === undefined) return;
    if (growth >= CANNABIS_MAX) {
      player.sendMessage("§cThis plant is fully grown - nutrients only help before then.");
      return;
    }
    const marker = findMarker(block.dimension, block.location);
    if (!marker) return;
    const g = normalizeGenetics(safeParse(marker.getDynamicProperty("cc:genetics")));
    if (!g) return;

    const counts = safeParse(marker.getDynamicProperty("cc:nutrients")) ?? {};
    if ((counts[type] ?? 0) >= MAX_NUTRIENTS_PER_TYPE) {
      player.sendMessage(`§cThis plant can't take any more of that booster (max ${MAX_NUTRIENTS_PER_TYPE}).`);
      return;
    }

    if (type === "thc") g.thc = clamp(g.thc + Math.round(g.thc * 0.2) + 2, 1, 45);
    else if (type === "yield") g.yieldStat = clamp(g.yieldStat + 1, 1, 8);
    else if (type === "growth") g.growth = round2(clamp(g.growth + 0.25, 0.5, 2.0));
    g.boosted = true;
    counts[type] = (counts[type] ?? 0) + 1;

    marker.setDynamicProperty("cc:genetics", JSON.stringify(g));
    marker.setDynamicProperty("cc:nutrients", JSON.stringify(counts));
    consumeOneFromHand(player, `cc:nutrient_${type}`);
    player.onScreenDisplay.setActionBar(
      `§2Boosted! §fTHC ${g.thc}% | Yield ${g.yieldStat} | Growth ${Math.round(g.growth * 100)}%`
    );
  } catch (e) {
    /* non-critical */
  }
}

/* -------------------------------- Distiller -------------------------------- */
/* One batch at a time: rosin + 1 fuel item in, a concentrate out after a real-time
   wait (like the drying rack, it keeps going while you're away). The batch is saved
   in world storage keyed by position; "cc:status" 0/1/2 = idle/working/done. The
   output is rolled when the batch starts, so collecting is always the same result. */

function stillKey(dimId, loc) {
  return `cc:still:${dimId}:${loc.x},${loc.y},${loc.z}`;
}
function parseStillKey(key) {
  const m = key.match(/^cc:still:(.+):(-?\d+),(-?\d+),(-?\d+)$/);
  return m ? { dimId: m[1], loc: { x: +m[2], y: +m[3], z: +m[4] } } : null;
}
function readStillIndex() {
  return safeParse(world.getDynamicProperty(STILL_INDEX_PROP)) ?? [];
}
function loadStill(key) {
  return safeParse(world.getDynamicProperty(key));
}
function saveStill(key, still) {
  const index = readStillIndex();
  if (!still) {
    world.setDynamicProperty(key, undefined);
    if (index.includes(key)) world.setDynamicProperty(STILL_INDEX_PROP, JSON.stringify(index.filter((k) => k !== key)));
  } else {
    world.setDynamicProperty(key, JSON.stringify(still));
    if (!index.includes(key)) world.setDynamicProperty(STILL_INDEX_PROP, JSON.stringify([...index, key]));
  }
}
function isStillDone(still, now) {
  return now - still.start >= DISTILL_PROCESSES[still.proc].ms;
}
function stillStatus(still, now) {
  if (!still) return 0;
  return isStillDone(still, now) ? 2 : 1;
}
function getStillBlock(dimId, loc) {
  try {
    const block = world.getDimension(dimId).getBlock(loc);
    return block && block.typeId === "cc:distiller" ? block : undefined;
  } catch (e) {
    return undefined;
  }
}
function updateStillVisual(dimId, loc, still) {
  try {
    const block = getStillBlock(dimId, loc);
    if (!block) return;
    const status = stillStatus(still, Date.now());
    if (block.permutation.getState("cc:status") !== status) {
      block.setPermutation(block.permutation.withState("cc:status", status));
    }
  } catch (e) {
    /* chunk unloaded - visual catches up next check */
  }
}

function concentrateGenetics(rosinG, proc) {
  const effects = rosinG.effects.map(([id, amp]) => [
    id,
    proc.effectBoost && !NO_THC_BONUS.has(id) ? clamp(amp + proc.effectBoost, 0, MAX_EFFECT_AMP) : amp
  ]);
  const [lo, hi] = proc.thc;
  const t = clamp((rosinG.thc - ROSIN_THC_MIN) / (ROSIN_THC_MAX - ROSIN_THC_MIN), 0, 1);
  return { ...rosinG, thc: Math.round((lo + t * (hi - lo)) * 10) / 10, effects };
}

function makeConcentrateItem(g, amount, procKey) {
  const proc = DISTILL_PROCESSES[procKey];
  const item = new ItemStack(proc.item, amount);
  item.nameTag = `${strainName(g)} ${proc.name}§r`;
  safeSetLore(item, geneticsLore(g, `§7Type: §d${proc.name}`));
  return item;
}

// Probabilistic rounding, like the press. A batch always gives at least 1.
function distillOutput(rosin, procKey, fromDried) {
  const expected = rosin * DISTILL_PROCESSES[procKey].yield * (fromDried ? DRIED_ROSIN_YIELD : 1);
  const whole = Math.floor(expected);
  return Math.max(1, whole + (Math.random() < expected - whole ? 1 : 0));
}

// What the distiller holds right now: the finished concentrate, or the rosin + fuel still cooking.
function stillItems(still, now) {
  if (isStillDone(still, now)) {
    return [makeConcentrateItem(lookupGenetics(still.outId) ?? baseGenetics("og_kush"), still.out, still.proc)];
  }
  return [
    makeRosinItem(lookupGenetics(still.rosinId) ?? baseGenetics("og_kush"), still.rosin, still.fromDried),
    new ItemStack(still.fuel, 1)
  ];
}

async function openDistiller(player, dimId, loc) {
  try {
    const key = stillKey(dimId, loc);
    const still = loadStill(key);
    const now = Date.now();
    const lines = [];
    const actions = [];
    const form = new ActionFormData().title("Distiller");

    if (!still) {
      lines.push("§7Idle. Turn rosin into concentrates:", "");
      for (const k of DISTILL_ORDER) {
        const p = DISTILL_PROCESSES[k];
        lines.push(`§f${p.name} §7- ${p.fuelName}, ${formatTime(p.ms)}, ${formPct(p.yield)} yield`);
      }
      lines.push("", "§8One fuel item per batch, up to 16 rosin.", "§8Rosin from dried buds yields 25%% more.");
      form.button("Start distilling");
      actions.push("start");
    } else {
      const proc = DISTILL_PROCESSES[still.proc];
      const rosinG = lookupGenetics(still.rosinId);
      const frac = clamp((now - still.start) / proc.ms, 0, 1);
      lines.push(`§7Making: §f${proc.name}`, `§7From: ${rosinG?.color ?? "§f"}${rosinG?.name ?? "Unknown"} Rosin §7x${still.rosin}`, "");
      if (frac >= 1) {
        lines.push(`${progressBar(1)} §2Done!`, `§7Ready: §f${still.out} ${proc.name}`);
        form.button(`Collect ${proc.name} (${still.out})`);
        actions.push("collect");
      } else {
        lines.push(`${progressBar(frac)} §f${Math.floor(frac * 100)}%% §7(${formatTime(proc.ms - (now - still.start))} left)`);
        form.button("Refresh progress");
        actions.push("refresh");
        form.button("§4Stop and take the rosin back");
        actions.push("stop");
      }
    }
    form.button("Close");
    actions.push("close");
    form.body(lines.join("\n"));

    const res = await showForm(player, form);
    if (!res || res.canceled) return;
    const action = actions[res.selection];

    if (action === "start") {
      await startDistill(player, dimId, loc);
    } else if (action === "refresh") {
      await openDistiller(player, dimId, loc);
    } else if (action === "collect" || action === "stop") {
      const fresh = loadStill(key);
      if (!fresh) return;
      const t = Date.now();
      // Re-check: the batch may have finished while the menu was open.
      if (action === "stop" && isStillDone(fresh, t)) {
        player.sendMessage("§eIt finished while the menu was open - collect it instead.");
        await openDistiller(player, dimId, loc);
        return;
      }
      if (action === "collect" && !isStillDone(fresh, t)) return;
      for (const item of stillItems(fresh, t)) giveItem(player, item);
      saveStill(key, null);
      updateStillVisual(dimId, loc, null);
      player.onScreenDisplay.setActionBar(
        action === "collect"
          ? `§6Collected ${fresh.out} ${DISTILL_PROCESSES[fresh.proc].name}`
          : "§7Stopped - rosin and fuel returned."
      );
    }
  } catch (e) {
    player.sendMessage(`§cDistiller error: ${e}`);
  }
}

async function startDistill(player, dimId, loc) {
  const container = player.getComponent("minecraft:inventory").container;
  const key = stillKey(dimId, loc);

  // One entry per rosin strain + wet/dried, totalled across every slot holding it.
  const groups = new Map();
  for (let i = 0; i < container.size; i++) {
    const stack = container.getItem(i);
    if (!stack || stack.typeId !== "cc:rosin") continue;
    const g = getGenetics(stack);
    if (!g) continue;
    const id = registerGenetics(g);
    const dried = isDried(stack);
    const gk = `${id}|${dried}`;
    if (!groups.has(gk)) groups.set(gk, { id, dried, genetics: g, amount: 0 });
    groups.get(gk).amount += stack.amount;
  }
  if (groups.size === 0) {
    player.sendMessage("§cYou need rosin in your inventory. Press buds in a Nug Press to make some.");
    return;
  }
  const candidates = [...groups.values()];

  const form = new ModalFormData()
    .title("Start Distilling")
    .dropdown(
      "Rosin",
      candidates.map((c) => `${strainName(c.genetics)}§r §7x${c.amount} (${c.dried ? "Dried" : "Wet"})`),
      { defaultValueIndex: 0 }
    )
    .dropdown(
      "Make",
      DISTILL_ORDER.map((k) => {
        const p = DISTILL_PROCESSES[k];
        return `${p.name} - needs ${p.fuelName} - ${formatTime(p.ms)}`;
      }),
      { defaultValueIndex: 0 }
    )
    .slider("How much rosin?", 1, DISTILL_MAX_ROSIN, {
      valueStep: 1,
      defaultValue: Math.min(DISTILL_MAX_ROSIN, candidates[0].amount)
    });

  const res = await showForm(player, form);
  if (!res || res.canceled) return;
  const [idx, procIdx, requested] = res.formValues;
  const c = candidates[idx];
  const procKey = DISTILL_ORDER[procIdx];
  const proc = DISTILL_PROCESSES[procKey];
  if (!c || !proc) return;

  if (!getStillBlock(dimId, loc)) return;
  if (loadStill(key)) {
    player.sendMessage("§cThe distiller is already running.");
    return;
  }

  // Re-count after the form closes - the player may have moved or dropped things.
  const rosinSlots = [];
  let have = 0;
  let fuelSlot = -1;
  for (let i = 0; i < container.size; i++) {
    const stack = container.getItem(i);
    if (!stack) continue;
    if (fuelSlot < 0 && proc.fuels.includes(stack.typeId)) fuelSlot = i;
    if (stack.typeId !== "cc:rosin" || isDried(stack) !== c.dried) continue;
    const sg = getGenetics(stack);
    if (!sg || registerGenetics(sg) !== c.id) continue;
    rosinSlots.push(i);
    have += stack.amount;
  }
  const amount = Math.min(Math.round(requested), DISTILL_MAX_ROSIN, have);
  if (amount < 1) {
    player.sendMessage("§cYour inventory changed while the menu was open - try again.");
    return;
  }
  if (fuelSlot < 0) {
    player.sendMessage(`§cMaking ${proc.name} needs 1 ${proc.fuelName} as fuel.`);
    return;
  }

  const fuel = container.getItem(fuelSlot).typeId;
  consumeFromSlot(container, fuelSlot, 1);
  let left = amount;
  for (const i of rosinSlots) {
    if (left <= 0) break;
    const stack = container.getItem(i);
    if (!stack) continue;
    const take = Math.min(left, stack.amount);
    consumeFromSlot(container, i, take);
    left -= take;
  }

  const still = {
    proc: procKey,
    start: Date.now(),
    rosinId: c.id,
    fromDried: c.dried,
    rosin: amount,
    fuel,
    outId: registerGenetics(concentrateGenetics(c.genetics, proc)),
    out: distillOutput(amount, procKey, c.dried)
  };
  saveStill(key, still);
  updateStillVisual(dimId, loc, still);
  try {
    player.dimension.playSound("fire.ignite", loc, { volume: 0.8, pitch: 0.9 });
  } catch (e) {
    /* cosmetic */
  }
  player.onScreenDisplay.setActionBar(`§6Distilling ${amount} rosin into ${proc.name} - ready in ${formatTime(proc.ms)}`);
}

function dropStillContents(dimension, loc, key) {
  const still = loadStill(key);
  if (!still) return;
  const at = { x: loc.x + 0.5, y: loc.y + 0.5, z: loc.z + 0.5 };
  for (const item of stillItems(still, Date.now())) {
    try {
      dimension.spawnItem(item, at);
    } catch (err) {
      /* spawn failed - skip */
    }
  }
  saveStill(key, null);
}

// Every 2 seconds: flip distiller visuals to "done", and clean up distillers destroyed by explosions etc.
system.runInterval(() => {
  let index;
  try {
    index = readStillIndex();
  } catch (e) {
    return;
  }
  for (const key of index) {
    const parsed = parseStillKey(key);
    if (!parsed) continue;
    try {
      const dimension = world.getDimension(parsed.dimId);
      const block = dimension.getBlock(parsed.loc);
      if (!block) continue; // not loaded
      if (block.typeId !== "cc:distiller") {
        dropStillContents(dimension, parsed.loc, key);
        continue;
      }
      updateStillVisual(parsed.dimId, parsed.loc, loadStill(key));
    } catch (e) {
      /* unloaded chunk or dimension - try next time */
    }
  }
}, 40);

/* -------------------------- Interaction routing --------------------------- */

const plantIntent = new Map(); // "dim,x,y,z" -> genetics, set just before a seed is placed
const lastSeedHeld = new Map(); // player id -> genetics of the last seed they clicked farmland with

function recordPlantIntent(player, block, itemStack) {
  if (!itemStack || !itemStack.typeId.startsWith("cc:seed_")) return;
  const g = getGenetics(itemStack);
  if (!g) return;
  const loc = block.location;
  plantIntent.set(`${player.dimension.id},${loc.x},${loc.y + 1},${loc.z}`, g);
  lastSeedHeld.set(player.id, g);
}

// Which genetics a just-placed cannabis plant gets. NEVER a random strain when we can know the seed:
// a random fallback here once replaced players' bred strains (holding right-click to plant a row
// skipped the intent record, see the isFirstEvent note below).
function plantedGenetics(player, dimension, loc) {
  const key = `${dimension.id},${loc.x},${loc.y},${loc.z}`;
  const intent = plantIntent.get(key);
  plantIntent.delete(key);
  if (intent) return intent;
  try {
    const held = player?.getComponent("minecraft:inventory")?.container?.getItem(player.selectedSlotIndex);
    if (held?.typeId.startsWith("cc:seed_")) {
      const g = getGenetics(held); // after placing, the rest of the same stack is still in hand
      if (g) return g;
    }
  } catch (e) {
    /* fall through */
  }
  if (player && lastSeedHeld.has(player.id)) return lastSeedHeld.get(player.id); // planted their last seed
  return baseGenetics(COMMON_KEYS[Math.floor(Math.random() * COMMON_KEYS.length)]);
}

function routePlantInteraction(player, block, itemStack) {
  if (!itemStack) return;
  if (itemStack.typeId === "minecraft:bone_meal") {
    debounced(player, "bonemeal", 500, () => system.run(() => boneMealGrowth(player, block)));
  } else if (block.typeId === "cc:cannabis_plant" && NUTRIENT_ITEMS[itemStack.typeId]) {
    const type = NUTRIENT_ITEMS[itemStack.typeId];
    debounced(player, `nutrient_${type}`, 500, () => system.run(() => applyNutrient(player, block, type)));
  }
}

const STATION_BLOCKS = new Set(["cc:breeding_station", "cc:rolling_table", "cc:drying_rack", "cc:nug_press", "cc:distiller"]);

function openStation(player, blockId, block) {
  if (blockId === "cc:nug_press") {
    const dimId = block.dimension.id;
    const loc = { x: block.location.x, y: block.location.y, z: block.location.z };
    debounced(player, "press_open", 800, () => system.run(() => openPress(player, dimId, loc)));
  } else if (blockId === "cc:distiller") {
    const dimId = block.dimension.id;
    const loc = { x: block.location.x, y: block.location.y, z: block.location.z };
    debounced(player, "still_open", 800, () => system.run(() => openDistiller(player, dimId, loc)));
  } else if (blockId === "cc:drying_rack") {
    const dimId = block.dimension.id;
    const loc = { x: block.location.x, y: block.location.y, z: block.location.z };
    debounced(player, "rack_open", 800, () => system.run(() => openRack(player, dimId, loc)));
  } else if (blockId === "cc:breeding_station") {
    debounced(player, "breeding_open", 800, () => system.run(() => handleBreeding(player)));
  } else {
    debounced(player, "rolling_open", 800, () => system.run(() => handleRolling(player)));
  }
}

// Main path: fires before ANY block interaction, whatever the player is holding.
world.beforeEvents.playerInteractWithBlock.subscribe((evt) => {
  const { block, player, itemStack } = evt;
  const id = block.typeId;
  // Record EVERY seed click on farmland, including repeats: holding right-click and sweeping plants a
  // row with repeat events only. Skipping those gave the extra plants a random strain.
  if (id === "minecraft:farmland") {
    recordPlantIntent(player, block, itemStack);
    return;
  }
  if (evt.isFirstEvent === false) return;

  if (id === "cc:breeding_station" && itemStack?.typeId === "minecraft:book") {
    evt.cancel = true; // a plain book on the Breeding Station becomes a new copy of the guide
    debounced(player, "guide_copy", 1000, () => system.run(() => tradeBookForGuide(player)));
    return;
  }
  if (STATION_BLOCKS.has(id)) {
    evt.cancel = true; // don't also place/use whatever is in hand
    openStation(player, id, block);
    return;
  }
  if (id === "cc:cannabis_plant" || id === "cc:tobacco_plant") {
    routePlantInteraction(player, block, itemStack);
    return;
  }
});

// Fallbacks - the debounce guarantees each click still only acts once.
world.afterEvents.playerInteractWithBlock.subscribe((evt) => {
  const id = evt.block.typeId;
  const held = evt.beforeItemStack ?? evt.itemStack;
  if (id === "cc:breeding_station" && held?.typeId === "minecraft:book") return; // handled as a guide copy
  if (STATION_BLOCKS.has(id)) openStation(evt.player, id, evt.block);
});

// NOTE: the old world.beforeEvents.itemUseOn listener that used to live here was
// removed - it's a legacy/deprecated event (fully removed in @minecraft/server 2.0.0,
// replaced by playerInteractWithBlock) and did the exact same routing as the
// beforeEvents.playerInteractWithBlock handler above, so nothing is lost.

/* ------------------------------- Planting --------------------------------- */

world.afterEvents.playerPlaceBlock.subscribe((evt) => {
  const { block, dimension } = evt;
  const loc = block.location;

  if (block.typeId === "cc:tobacco_plant") {
    spawnMarker(dimension, loc, "tobacco", null);
    return;
  }
  if (block.typeId !== "cc:cannabis_plant") return;

  const g = plantedGenetics(evt.player, dimension, loc);
  spawnMarker(dimension, loc, "cannabis", g);
  setPlantTint(block, g);
});

/* -------------------------------- Growth ---------------------------------- */

function growPlants() {
  for (const dimId of ["overworld", "nether", "the_end"]) {
    let dimension;
    let markers;
    try {
      dimension = world.getDimension(dimId);
      markers = dimension.getEntities({ families: ["cc_marker"] });
    } catch (e) {
      continue;
    }

    for (const marker of markers) {
      try {
        if (!marker.isValid) continue; // a property in script API 2.x (calling it threw, so nothing grew)
        const crop = marker.getDynamicProperty("cc:crop") ?? "cannabis";
        const expected = crop === "tobacco" ? "cc:tobacco_plant" : "cc:cannabis_plant";
        const max = crop === "tobacco" ? TOBACCO_MAX : CANNABIS_MAX;
        const l = marker.location;
        const blockLoc = { x: Math.floor(l.x), y: Math.floor(l.y), z: Math.floor(l.z) };
        const block = dimension.getBlock(blockLoc);
        if (!block) continue; // chunk not loaded
        if (block.typeId !== expected) {
          marker.remove();
          continue;
        }

        const growth = block.permutation.getState("cc:growth");
        if (growth === undefined || growth >= max) continue;

        let chance = crop === "tobacco" ? TOBACCO_GROWTH_CHANCE : CANNABIS_GROWTH_CHANCE;
        if (crop === "cannabis") {
          const g = safeParse(marker.getDynamicProperty("cc:genetics"));
          chance *= g?.growth ?? 1;
          setPlantTint(block, g); // plants from before tints existed get theirs here
        }
        const below = dimension.getBlock({ x: blockLoc.x, y: blockLoc.y - 1, z: blockLoc.z });
        const moisture = below?.permutation.getState("moisturized_amount");
        if (typeof moisture === "number" && moisture > 0) chance *= 1.4;

        if (Math.random() < chance) {
          block.setPermutation(block.permutation.withState("cc:growth", growth + 1));
        }
      } catch (e) {
        /* one bad marker shouldn't stop the rest */
      }
    }
  }
}
system.runInterval(growPlants, GROWTH_TICK_INTERVAL);

/* ------------------------------ Breaking blocks ---------------------------- */

world.afterEvents.playerBreakBlock.subscribe((evt) => {
  const { block, brokenBlockPermutation, dimension } = evt;
  const brokenId = brokenBlockPermutation.type.id;
  const loc = block.location;
  const dropAt = { x: loc.x + 0.5, y: loc.y + 0.5, z: loc.z + 0.5 };

  if (GRASS_BLOCK_IDS.includes(brokenId)) {
    if (Math.random() < GRASS_SEED_DROP_CHANCE) {
      const key = COMMON_KEYS[Math.floor(Math.random() * COMMON_KEYS.length)];
      dimension.spawnItem(makeSeedItem(rollStrain(key), 1), dropAt);
    }
    return;
  }

  if (brokenId === "cc:nug_press") {
    const tier = brokenBlockPermutation.getState("cc:plate") ?? 0;
    if (PLATE_BY_TIER[tier]) dimension.spawnItem(new ItemStack(PLATE_BY_TIER[tier].id, 1), dropAt);
    return;
  }

  if (brokenId === "cc:distiller") {
    dropStillContents(dimension, loc, stillKey(dimension.id, loc));
    return;
  }

  if (brokenId === "cc:drying_rack") {
    dropRackContents(dimension, loc, rackKey(dimension.id, loc));
    return;
  }

  if (brokenId === "cc:tobacco_plant") {
    findMarker(dimension, loc)?.remove();
    const growth = brokenBlockPermutation.getState("cc:growth");
    if (growth < TOBACCO_MAX) {
      dimension.spawnItem(new ItemStack("cc:tobacco_seeds", 1), dropAt);
    } else {
      dimension.spawnItem(new ItemStack("cc:tobacco_leaf", 2 + Math.floor(Math.random() * 2)), dropAt);
      dimension.spawnItem(new ItemStack("cc:tobacco_seeds", 1 + Math.floor(Math.random() * 2)), dropAt);
    }
    return;
  }

  if (brokenId !== "cc:cannabis_plant") return;

  const marker = findMarker(dimension, loc);
  const g = marker ? normalizeGenetics(safeParse(marker.getDynamicProperty("cc:genetics"))) : null;
  marker?.remove();
  if (!g) return;

  const growth = brokenBlockPermutation.getState("cc:growth");
  if (growth < CANNABIS_MAX) {
    dimension.spawnItem(makeSeedItem(g, 1), dropAt); // broke it early - get the seed back
    return;
  }

  const buds = Math.max(1, Math.round(g.yieldStat));
  dimension.spawnItem(makeBudItem(g, buds, false), dropAt);
  if (Math.random() < HARVEST_SEED_CHANCE) {
    // same genetics as the plant, so they stack
    dimension.spawnItem(makeSeedItem(g, 1 + Math.floor(Math.random() * HARVEST_SEED_MAX)), dropAt);
  }
  evt.player.onScreenDisplay.setActionBar(`§2Harvested ${buds}x ${strainName(g)}§r §2(Wet)`);
});

/* ------------------------------ Funguy trader ------------------------------ */
// cc:funguy spawns as a village resident by default (spawn egg too). The script spawns two ways:
//  - residents: the first time a player is near a village (3+ villagers), that village rolls once
//    for its own Funguy. Villages are remembered in the world property FUNGUY_VILLAGE_PROP.
//  - wanderers: every in-game day, a chance to walk in near a random player; the entity's own timer
//    despawns him later (event cc:as_wanderer switches his component group and trade table).

const FUNGUY_ID = "cc:funguy";
const FUNGUY_CHECK_TICKS = 1200; // 1 minute
const FUNGUY_VILLAGE_PROP = "cc:funguy_villages";
const FUNGUY_NEXT_WANDER_PROP = "cc:funguy_next_wander";
const FUNGUY_VILLAGE_MIN_VILLAGERS = 3;
const FUNGUY_VILLAGE_SCAN = 48; // blocks around a player to count villagers
const FUNGUY_VILLAGE_SPACING = 96; // two villages closer than this count as the same one
const FUNGUY_VILLAGE_CHANCE = 0.3; // user: he spawned too often (was 0.6)
const FUNGUY_WANDER_EVERY = 24000; // one in-game day (20 real minutes)
const FUNGUY_WANDER_CHANCE = 0.1; // per in-game day (was 0.35 - too often)
const FUNGUY_BAD_GROUND = ["water", "lava", "leaves", "ice", "magma", "cactus", "fire"];

function readFunguyVillages() {
  return safeParse(world.getDynamicProperty(FUNGUY_VILLAGE_PROP)) ?? [];
}

// The list is one JSON string (32,767-char limit, ~25 chars a village), so it's capped: over the cap,
// the oldest villages without a Funguy are forgotten first (they may roll again if visited).
const FUNGUY_VILLAGE_MAX = 800;
function writeFunguyVillages(list) {
  let kept = list;
  if (kept.length > FUNGUY_VILLAGE_MAX) {
    let excess = kept.length - FUNGUY_VILLAGE_MAX;
    kept = kept.filter((v) => (!v.has && excess > 0 ? (excess--, false) : true));
    if (kept.length > FUNGUY_VILLAGE_MAX) kept = kept.slice(kept.length - FUNGUY_VILLAGE_MAX);
  }
  world.setDynamicProperty(FUNGUY_VILLAGE_PROP, JSON.stringify(kept));
}

function knownVillageNear(list, x, z) {
  return list.find((v) => Math.hypot(v.x - x, v.z - z) < FUNGUY_VILLAGE_SPACING);
}

// A standable surface spot minR..maxR blocks from center (horizontal), or undefined.
function findFunguySpot(dimension, center, minR, maxR) {
  for (let attempt = 0; attempt < 10; attempt++) {
    const angle = Math.random() * Math.PI * 2;
    const dist = minR + Math.random() * (maxR - minR);
    const x = Math.floor(center.x + Math.cos(angle) * dist);
    const z = Math.floor(center.z + Math.sin(angle) * dist);
    let top;
    try {
      top = dimension.getTopmostBlock({ x, z });
    } catch (e) {
      continue; // chunk not loaded
    }
    if (!top || FUNGUY_BAD_GROUND.some((bad) => top.typeId.includes(bad))) continue;
    return { x: x + 0.5, y: top.location.y + 1, z: z + 0.5 };
  }
  return undefined;
}

function spawnFunguy(dimension, spot, wanderer) {
  const funguy = dimension.spawnEntity(FUNGUY_ID, spot);
  if (wanderer) {
    funguy.triggerEvent("cc:as_wanderer");
    funguy.addTag("cc_wanderer");
  } else {
    funguy.addTag("cc_resident");
  }
  try {
    dimension.spawnParticle("minecraft:villager_happy", { x: spot.x, y: spot.y + 1, z: spot.z });
  } catch (e) {
    /* cosmetic */
  }
  return funguy;
}

function checkFunguyVillages(players) {
  const villages = readFunguyVillages();
  let changed = false;
  for (const player of players) {
    try {
      const dimension = player.dimension;
      if (dimension.id !== "minecraft:overworld") continue;
      const villagers = dimension.getEntities({
        type: "minecraft:villager_v2",
        location: player.location,
        maxDistance: FUNGUY_VILLAGE_SCAN
      });
      if (villagers.length < FUNGUY_VILLAGE_MIN_VILLAGERS) continue;
      const cx = villagers.reduce((s, v) => s + v.location.x, 0) / villagers.length;
      const cz = villagers.reduce((s, v) => s + v.location.z, 0) / villagers.length;
      if (knownVillageNear(villages, cx, cz)) continue;

      const village = { x: Math.round(cx), z: Math.round(cz), has: Math.random() < FUNGUY_VILLAGE_CHANCE };
      if (village.has) {
        const center = { x: cx, y: player.location.y, z: cz };
        const spot = findFunguySpot(dimension, center, 0, 10);
        if (!spot) continue; // try this village again next check
        const funguy = spawnFunguy(dimension, spot, false);
        funguy.setDynamicProperty("cc:village", `${village.x},${village.z}`);
      }
      villages.push(village);
      changed = true;
    } catch (e) {
      /* one player's check failing shouldn't stop the rest */
    }
  }
  if (changed) writeFunguyVillages(villages);
}

function checkFunguyWander(players) {
  const now = world.getAbsoluteTime();
  const next = world.getDynamicProperty(FUNGUY_NEXT_WANDER_PROP);
  if (typeof next !== "number") {
    world.setDynamicProperty(FUNGUY_NEXT_WANDER_PROP, now + FUNGUY_WANDER_EVERY);
    return;
  }
  if (now < next) return;
  world.setDynamicProperty(FUNGUY_NEXT_WANDER_PROP, now + FUNGUY_WANDER_EVERY);
  if (Math.random() >= FUNGUY_WANDER_CHANCE) return;

  const candidates = players.filter((p) => p.dimension.id === "minecraft:overworld");
  if (candidates.length === 0) return;
  const overworld = candidates[0].dimension;
  if (overworld.getEntities({ type: FUNGUY_ID, tags: ["cc_wanderer"] }).length > 0) return; // one at a time

  const player = candidates[Math.floor(Math.random() * candidates.length)];
  const spot = findFunguySpot(overworld, player.location, 16, 28);
  if (!spot) return;
  spawnFunguy(overworld, spot, true);
  player.sendMessage("§dSomething smells funky... §5a Funguy§d has wandered nearby.");
}

system.runInterval(() => {
  let players;
  try {
    players = world.getAllPlayers();
  } catch (e) {
    return;
  }
  if (players.length === 0) return;
  checkFunguyVillages(players);
  try {
    checkFunguyWander(players);
  } catch (e) {
    /* try again next check */
  }
}, FUNGUY_CHECK_TICKS);

// A resident who dies frees his village to roll for a new Funguy later.
world.afterEvents.entityDie.subscribe(
  (evt) => {
    try {
      const home = evt.deadEntity.getDynamicProperty("cc:village");
      if (typeof home !== "string") return;
      const [x, z] = home.split(",").map(Number);
      writeFunguyVillages(readFunguyVillages().filter((v) => v.x !== x || v.z !== z));
    } catch (e) {
      /* entity already gone */
    }
  },
  { entityTypes: [FUNGUY_ID] }
);

/* ------------------------------ Seed rolling ------------------------------- */
// Crafting, trading and the creative menu hand out plain strain seeds with no genetics. The moment one lands
// in a player's inventory (or on join, for seeds already there) it becomes its own random roll of the strain.
// A plain stack (e.g. from the creative menu) is rolled once as a whole.

// Unrolled = a strain seed without a genetics ID line (plain, or described by an earlier version of the pack).
function isUnrolledSeed(stack) {
  return !!stack && !!SEED_TO_KEY[stack.typeId] && !readLore(stack).some((l) => l.startsWith(ID_PREFIX));
}

function describedSeed(stack) {
  if (!isUnrolledSeed(stack)) return undefined;
  const key = SEED_TO_KEY[stack.typeId];
  const out = makeSeedItem(rollStrain(key), stack.amount);
  if (stack.nameTag) out.nameTag = stack.nameTag;
  return out;
}

function describePlayerSeeds(player) {
  const container = player.getComponent("minecraft:inventory").container;
  let changed = 0;
  for (let i = 0; i < container.size; i++) {
    const out = describedSeed(container.getItem(i));
    if (out) {
      container.setItem(i, out);
      changed++;
    }
  }
  return changed;
}

const seedScanPending = new Set();
function queueSeedScan(player) {
  if (seedScanPending.has(player.id)) return;
  seedScanPending.add(player.id);
  system.run(() => {
    seedScanPending.delete(player.id);
    try {
      describePlayerSeeds(player);
    } catch (e) {
      /* player left */
    }
  });
}

world.afterEvents.playerInventoryItemChange.subscribe((evt) => {
  if (isUnrolledSeed(evt.itemStack)) queueSeedScan(evt.player);
});

world.afterEvents.playerSpawn.subscribe((evt) => {
  if (evt.initialSpawn) queueSeedScan(evt.player);
});

/* ------------------------------- Guide book -------------------------------- */
// Every player gets the signed field guide the first time they spawn in a world with the pack
// (player property cc:guide_given). A plain book used on a Breeding Station trades for a new copy.

function makeGuideBook() {
  const book = new ItemStack("minecraft:writable_book", 1);
  const pages = book.getComponent("minecraft:book");
  pages.setContents(buildGuidePages(STRAINS, EFFECT_NAMES));
  pages.signBook(GUIDE_TITLE, GUIDE_AUTHOR);
  return book;
}

function giveGuide(player) {
  giveItem(player, makeGuideBook());
}

function tradeBookForGuide(player) {
  try {
    if (!consumeOneFromHand(player, "minecraft:book")) return;
    giveGuide(player);
    player.sendMessage("§2Here's a fresh copy of the §lCannabis Guide§r§2.");
  } catch (e) {
    player.sendMessage(`§cCouldn't make the guide: ${e}`);
  }
}

world.afterEvents.playerSpawn.subscribe((evt) => {
  if (!evt.initialSpawn) return;
  const player = evt.player;
  system.run(() => {
    try {
      if (player.getDynamicProperty("cc:guide_given")) return;
      giveGuide(player);
      player.setDynamicProperty("cc:guide_given", true);
      player.sendMessage("§2Welcome! Check your inventory for the §lCannabis Guide§r§2.");
    } catch (e) {
      /* try again next join */
    }
  });
});

/* --------------------------------- Boot ------------------------------------ */

system.run(() => {
  try {
    world.sendMessage("§2[Cannabis Craft] Phase 5 loaded.");
  } catch (e) {
    /* world not ready on first tick - harmless */
  }
});
