var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { StartupEvent, system } from "@minecraft/server";
import { methodEventSub } from "../../lib/eventHelper";
class CookableComonent {
    constructor() {
        this.onUseOn = this.onUseOn.bind(this);
    }
    onUseOn(args, param) {
        param.params;
    }
}
export class CookableComonentRegister {
    register(args) {
        args.itemComponentRegistry.registerCustomComponent('farmersdelight:cookable', new CookableComonent());
    }
}
__decorate([
    methodEventSub(system.beforeEvents.startup),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [StartupEvent]),
    __metadata("design:returntype", void 0)
], CookableComonentRegister.prototype, "register", null);
//# sourceMappingURL=CookableComponent.js.map