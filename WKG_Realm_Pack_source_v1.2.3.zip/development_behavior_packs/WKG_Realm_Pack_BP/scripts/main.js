// Combined entry point for WKG Realm Pack.
// Each original addon's logic is untouched - just re-homed and imported here.
import "./fd_main.js";
import "./cc_main.js";
