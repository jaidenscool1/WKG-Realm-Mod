import { __test as T } from "../main.mjs";
import srv from "@minecraft/server"; import ui from "@minecraft/server-ui";
function player() {
  const slots = new Array(36).fill(undefined);
  const container = { size: 36, getItem: i => slots[i], setItem: (i, s) => { slots[i] = s; },
    addItem: s => { slots[slots.findIndex(x => x === undefined)] = s; } };
  return { id: "p", slots, selectedSlotIndex: 0, getComponent: () => ({ container }), sendMessage() {},
    onScreenDisplay: { setActionBar() {} }, addEffect() {}, getHeadLocation: () => ({x:0,y:0,z:0}),
    getViewDirection: () => ({x:0,y:0,z:1}), dimension: { spawnItem() {}, spawnParticle() {} }, location: {} };
}
let fails = 0;
for (const [input, uses] of [["cc:rolling_paper", 4], ["cc:tobacco_leaf", 8], ["cc:bong", 6]]) {
  const p = player();
  p.slots[0] = new srv.ItemStack(input, 1);
  p.slots[1] = T.makeBudItem(T.baseGenetics("purple_punch"), 1);
  ui.__setResponse({ canceled: false, formValues: [true] });
  await T.handleRolling(p);
  const slot = p.slots.findIndex(s => s && /joint|blunt|bong_packed/.test(s.typeId));
  p.selectedSlotIndex = slot;
  const seq = [p.slots[slot].typeId.replace("cc:", "")];
  for (let i = 0; i < uses; i++) {
    T.takeHit(p);
    const s = p.slots[slot];
    seq.push(s ? `${s.typeId.replace("cc:", "")}(${s.getComponent("minecraft:durability")?.damage ?? "-"})` : "gone");
    if (s && s.typeId !== "cc:bong" && (!s.getDynamicProperty("cc:smoke") || !s.nameTag || s.getLore().length === 0)) {
      console.log("FAIL data lost at hit", i + 1); fails++;
    }
  }
  console.log(seq.join(" -> "));
}
console.log(fails ? "FAILURES" : "stage data preserved on every hit");
