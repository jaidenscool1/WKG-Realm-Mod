// Guide book: fits Bedrock's book limits, every icon resolves, given once on first join, book -> copy trade.
import { __test as T } from "../main.mjs";
import srv from "@minecraft/server";
import { G } from "../cc_glyphs.mjs";

let fails = 0;
const ok = (c, m) => { console.log((c ? "PASS " : "FAIL ") + m); if (!c) fails++; };

const pages = T.buildGuidePages(T.STRAINS, T.EFFECT_NAMES);
ok(pages.length > 20 && pages.length <= 50, `guide has ${pages.length} pages (max 50)`);
// the game limits pages to 256 BYTES of UTF-8 (§ = 2 bytes, glyph icons = 3) - verified in-game
const bytes = (p) => Buffer.byteLength(p, "utf8");
const long = pages.map((p, i) => [i + 1, bytes(p)]).filter(([, n]) => n > 256);
ok(long.length === 0, `every page fits 256 bytes${long.length ? " - too long: " + JSON.stringify(long) : ""}`);
ok(!pages.some((p) => p.includes("undefined")), "no missing icons or values (no 'undefined' in the text)");
const glyphs = new Set(Object.values(G));
const used = new Set(pages.join("").match(/[-]/g));
ok([...used].every((c) => glyphs.has(c)), `all ${used.size} icons used exist on the glyph sheet`);
const text = pages.join("\n");
ok(Object.values(T.STRAINS).every((s) => text.includes(s.name)), "all 18 strains are listed");
for (const topic of ["Drying Rack", "Nug Press", "Distiller", "Vapes", "Funguy", "Offhand", "Effect Levels", "Tobacco", "Rare Strains"]) {
  ok(text.includes(topic), `covers ${topic}`);
}
console.log("largest page:", Math.max(...pages.map(bytes)), "bytes of 256");

const book = T.makeGuideBook();
const bc = book.getComponent("minecraft:book");
ok(book.typeId === "minecraft:written_book" && bc.isSigned && bc.title === "Cannabis Guide", "the guide is a signed written book titled 'Cannabis Guide'");
ok(bc.pageCount === pages.length, "all pages are in the book");

// first join: once only
function makePlayer() {
  const slots = new Array(36).fill(undefined);
  const props = {}, msgs = [];
  return { id: "p" + Math.random(), slots, props, msgs, selectedSlotIndex: 0, sendMessage: (m) => msgs.push(m),
    getDynamicProperty: (k) => props[k], setDynamicProperty: (k, v) => { props[k] = v; }, dimension: { spawnItem() {} }, location: {},
    getComponent: () => ({ container: { size: 36, getItem: (i) => slots[i], setItem: (i, s) => { slots[i] = s; },
      addItem: (s) => { slots[slots.findIndex((x) => x === undefined)] = s; } } }) };
}
const spawnHandlers = srv.__handlers["after:playerSpawn"] ?? [];
const books = (p) => p.slots.filter((s) => s && s.typeId === "minecraft:written_book").length;
const p = makePlayer();
for (const h of spawnHandlers) h({ player: p, initialSpawn: true });
ok(books(p) === 1 && p.props["cc:guide_given"] === true, "a new player gets the guide on first join");
for (const h of spawnHandlers) h({ player: p, initialSpawn: true });
for (const h of spawnHandlers) h({ player: p, initialSpawn: false });
ok(books(p) === 1, "rejoining or respawning doesn't give another");

// a plain book on the breeding station -> new copy
const q = makePlayer();
q.slots[0] = new srv.ItemStack("minecraft:book", 2);
T.tradeBookForGuide(q);
ok(q.slots[0].amount === 1 && books(q) === 1, "a plain book trades for a new guide (one book used)");
const r = makePlayer();
r.slots[0] = new srv.ItemStack("minecraft:dirt", 1);
T.tradeBookForGuide(r);
ok(books(r) === 0, "no book in hand, no guide");

console.log(fails ? `\n${fails} FAILURES` : "\nALL GUIDE TESTS PASSED");
