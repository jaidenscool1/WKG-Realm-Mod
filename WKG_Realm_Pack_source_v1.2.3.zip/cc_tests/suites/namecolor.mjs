// Breeding Station name colour: keep parent / pick a colour / random / rainbow.
import { __test as T } from "../main.mjs";
import srv from "@minecraft/server";
import ui from "@minecraft/server-ui";

let fails = 0;
const ok = (c, m) => { console.log((c ? "PASS " : "FAIL ") + m); if (!c) fails++; };

function makePlayer() {
  const slots = new Array(36).fill(undefined);
  const container = { size: 36, getItem: (i) => slots[i], setItem: (i, s) => { slots[i] = s; },
    addItem: (s) => { slots[slots.findIndex((x) => x === undefined)] = s; } };
  const msgs = [];
  return { id: "p", slots, msgs, getComponent: () => ({ container }), sendMessage: (m) => msgs.push(m),
    dimension: { spawnItem() {} }, location: {} };
}
const C = T.NAME_COLOR_CHOICES;
const idx = (label) => C.findIndex((c) => c.replace(/§./g, "") === label);

async function breed(colorLabel, a = "og_kush", b = "tysgorilla", name = "Iron Kush") {
  const p = makePlayer();
  p.slots[0] = T.makeSeedItem(T.baseGenetics(a), 2);
  p.slots[1] = T.makeSeedItem(T.baseGenetics(b), 2);
  ui.__setResponse({ canceled: false, formValues: [0, 1, name, colorLabel === undefined ? undefined : idx(colorLabel)] });
  await T.handleBreeding(p);
  return { p, seed: p.slots.find((s) => s && s.typeId === "cc:seed_hybrid") };
}

ok(C.length === 1 + T.NAME_COLORS.length + 2, `dropdown offers keep + ${T.NAME_COLORS.length} colours + Random + Rainbow`);
ok(C.every((c) => c.replace(/§./g, "").length > 0), "every dropdown entry has a readable label");

let r = await breed(undefined);
ok(r.seed && /^§[24]Iron Kush Seeds/.test(r.seed.nameTag), "no choice (older clients) keeps a parent's colour");
r = await breed("Keep parent color");
ok(/^§[24]Iron Kush/.test(r.seed.nameTag), "'Keep parent colour' keeps a parent's colour");

r = await breed("Blue");
ok(r.seed.nameTag.startsWith("§9Iron Kush Seeds"), "picking Blue colours the seed name blue");
ok(T.getGenetics(r.seed).color === "§9", "the colour is part of the strain's genetics");
const bud = T.makeBudItem(T.getGenetics(r.seed), 1);
ok(bud.nameTag.startsWith("§9Iron Kush Bud"), "buds grown from it keep the colour");

r = await breed("Random");
const code = r.seed.nameTag.slice(0, 2);
ok(T.NAME_COLORS.some(([, c]) => c === code), `Random picks a colour from the palette (${code})`);

r = await breed("Rainbow");
const g = T.getGenetics(r.seed);
ok(g.color === T.RAINBOW, "Rainbow is stored on the strain");
const codes = r.seed.nameTag.match(/§./g) ?? [];
ok(new Set(codes).size >= 5 && r.seed.nameTag.replace(/§./g, "") === "Iron Kush Seeds", "rainbow name: each letter its own colour, text intact");
ok(T.makeBudItem(g, 1).nameTag.replace(/§./g, "") === "Iron Kush Bud", "rainbow buds read correctly");
ok(r.seed.nameTag.length <= 255, "rainbow name fits the name-tag limit");
const long = await breed("Rainbow", "og_kush", "tysgorilla", "A".repeat(40));
ok(long.seed.nameTag.length <= 255, "even a 32-letter rainbow name fits");

// rainbow parents pass the look on sometimes, and hybrids of hybrids still print fine
const kid = T.crossGenetics(g, T.baseGenetics("blue_dream")).child;
ok(T.strainName(kid).replace(/§./g, "") === kid.name, "a hybrid of a rainbow strain prints its name cleanly");

// rare discoveries keep the base strain's name and colour
{
  const p = makePlayer();
  p.slots[0] = T.makeSeedItem(T.baseGenetics("blue_dream"), 2);
  p.slots[1] = T.makeSeedItem(T.baseGenetics("green_crack"), 2);
  ui.__setResponse({ canceled: false, formValues: [0, 1, "", idx("Rainbow")] });
  const real = Math.random; Math.random = () => 0.0;
  await T.handleBreeding(p);
  Math.random = real;
  const rare = p.slots.find((s) => s && s.typeId === "cc:seed_white_widow");
  ok(rare && p.msgs.some((m) => /keep their original name and color/.test(m)), "a rare discovery ignores the colour choice and says so");
}

console.log(fails ? `\n${fails} FAILURES` : "\nALL NAME COLOUR TESTS PASSED");
