// Breeding: an effect both parents share may grow a level - 50% to II, 25% to III, 12.5% to IV... (max V).
import { __test as T } from "../main.mjs";
import ui from "@minecraft/server-ui";

let fails = 0;
const ok = (c, m) => { console.log((c ? "PASS " : "FAIL ") + m); if (!c) fails++; };
const hybrid = (name, effects) => ({ key: null, name, color: "§2", thc: 20, yieldStat: 3, growth: 1, effects, gen: 1, boosted: false });
const ampOf = (child, id) => (child.effects.find(([e]) => e === id) ?? [])[1];

function rate(a, b, id, fromAmp, n = 6000) {
  let up = 0;
  for (let i = 0; i < n; i++) if (ampOf(T.crossGenetics(a, b).child, id) === fromAmp + 1) up++;
  return up / n;
}

// the chance halves every level
for (const [amp, expected] of [[0, 0.5], [1, 0.25], [2, 0.125], [3, 0.0625]]) {
  const p = hybrid("A", [["speed", amp]]), q = hybrid("B", [["speed", amp]]);
  const r = rate(p, q, "speed", amp);
  ok(Math.abs(r - expected) < expected * 0.2 + 0.01, `level ${amp + 1} -> ${amp + 2}: ~${expected * 100}% (got ${(r * 100).toFixed(1)}%)`);
}
{
  const p = hybrid("A", [["speed", 4]]), q = hybrid("B", [["speed", 4]]);
  let over = 0;
  for (let i = 0; i < 2000; i++) if (ampOf(T.crossGenetics(p, q).child, "speed") > 4) over++;
  ok(over === 0, "level V is the cap");
}

// mismatched levels never level up - it takes two level IIs to breed a level III
{
  for (const [x, y] of [[0, 1], [1, 0], [0, 2], [1, 3]]) {
    const p = hybrid("A", [["haste", x]]), q = hybrid("B", [["haste", y]]);
    const seen = new Set();
    for (let i = 0; i < 2000; i++) seen.add(ampOf(T.crossGenetics(p, q).child, "haste"));
    ok(seen.size === 1 && seen.has(Math.max(x, y)), `level ${x + 1} x level ${y + 1} always gives level ${Math.max(x, y) + 1} (no level-up)`);
  }
  const p = hybrid("A", [["haste", 1]]), q = hybrid("B", [["haste", 1]]);
  const seen = new Set();
  for (let i = 0; i < 3000; i++) seen.add(ampOf(T.crossGenetics(p, q).child, "haste"));
  ok(seen.has(1) && seen.has(2) && !seen.has(3), "level II x level II gives II or III, never higher");
}

// effects only one parent has never grow
{
  const p = hybrid("A", [["speed", 0]]), q = hybrid("B", [["strength", 0]]);
  let grew = 0;
  for (let i = 0; i < 2000; i++) {
    const c = T.crossGenetics(p, q).child;
    if (c.effects.some(([, amp]) => amp > 0)) grew++;
  }
  ok(grew === 0, "an effect only one parent has never levels up");
}

// shared effects survive the 3-effect cap
{
  const p = hybrid("A", [["speed", 0], ["haste", 0], ["strength", 0]]);
  const q = hybrid("B", [["speed", 0], ["jump_boost", 0], ["regeneration", 0]]);
  let kept = 0;
  for (let i = 0; i < 500; i++) if (T.crossGenetics(p, q).child.effects.some(([e]) => e === "speed")) kept++;
  ok(kept === 500, "the shared effect is always kept when the child is over the effect cap");
}

// upgrades are reported (for the chat message) and real pure-strain crosses work too
{
  const real = Math.random;
  const a = T.rollStrain("og_kush"), b = T.rollStrain("og_kush");
  Math.random = () => 0; // every roll succeeds (og x og has no rare recipe)
  const r = T.crossGenetics(a, b);
  Math.random = real;
  ok(r.upgraded.length === 2 && ampOf(r.child, "regeneration") === 1 && ampOf(r.child, "resistance") === 1,
    "OG Kush x OG Kush can raise both shared effects (Regeneration II, Resistance II)");
}

// the breeding station tells the player
{
  const slots = new Array(36).fill(undefined);
  slots[0] = T.makeSeedItem(T.rollStrain("green_crack"), 2);
  slots[1] = T.makeSeedItem(T.rollStrain("green_crack"), 2);
  const msgs = [];
  const p = { id: "p", slots, sendMessage: (m) => msgs.push(m), playSound() {}, dimension: { spawnItem() {} }, location: {},
    getComponent: () => ({ container: { size: 36, getItem: (i) => slots[i], setItem: (i, s) => { slots[i] = s; },
      addItem: (s) => { slots[slots.findIndex((x) => x === undefined)] = s; } } }) };
  ui.__setResponse({ canceled: false, formValues: [0, 1, "", 0] });
  const real = Math.random; Math.random = () => 0;
  await T.handleBreeding(p);
  Math.random = real;
  ok(msgs.some((m) => /grew to level II/.test(m)), "the player is told when an effect levels up");
}

// joints / carts still just combine effects - no level-ups there
{
  const merged = T.mergeEffects([[["speed", 0]], [["speed", 0]]], 0);
  ok(merged.length === 1 && merged[0][1] === 0, "rolling/cart blends never level effects up");
}

console.log(fails ? `\n${fails} FAILURES` : "\nALL EFFECT LEVEL TESTS PASSED");
