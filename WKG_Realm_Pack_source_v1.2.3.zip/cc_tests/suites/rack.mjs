import { __test as T } from "../main.mjs";
import srv from "@minecraft/server"; import ui from "@minecraft/server-ui";
let fails = 0; const ok = (c, m) => { console.log((c ? "PASS " : "FAIL ") + m); if (!c) fails++; };
let fakeNow = 1_000_000; Date.now = () => fakeNow;

let rackState = 0; const spawned = [];
const block = { typeId: "cc:drying_rack",
  permutation: { getState: () => rackState, withState: (_, v) => ({ __v: v }) },
  setPermutation: (p) => { rackState = p.__v; } };
globalThis.__dim = { id: "minecraft:overworld", getBlock: () => block, spawnItem: (s) => spawned.push(s) };
const loc = { x: 5, y: 64, z: 5 };

const slots = new Array(36).fill(undefined);
const container = { size: 36, getItem: i => slots[i], setItem: (i, s) => { slots[i] = s; },
  addItem: s => { slots[slots.findIndex(x => x === undefined)] = s; } };
const msgs = [];
const p = { id: "p", selectedSlotIndex: 0, getComponent: () => ({ container }), sendMessage: m => msgs.push(m),
  onScreenDisplay: { setActionBar: m => msgs.push(m) }, dimension: globalThis.__dim, location: {} };

slots[0] = T.makeBudItem(T.baseGenetics("og_kush"), 10);
slots[1] = T.makeBudItem(T.baseGenetics("white_widow"), 10);
slots[2] = T.makeBudItem(T.baseGenetics("blue_dream"), 3, true); // already dried - must be ignored

// Add 10 OG Kush: main menu "add" -> add form (candidate 0, amount 10) -> reopened menu: close
ui.__queue({ canceled: false, selection: 0 }, { canceled: false, formValues: [0, 10] }, { canceled: true });
await T.openRack(p, "minecraft:overworld", loc);
ok(slots[0] === undefined, "10 OG Kush removed from inventory");
ok(rackState === 1, "rack shows drying buds");

// 1 minute later add White Widow: rack only has 6 space left even though 10 requested
fakeNow += 60_000;
ui.__queue({ canceled: false, selection: 0 }, { canceled: false, formValues: [0, 10] }, { canceled: true });
await T.openRack(p, "minecraft:overworld", loc);
const ww = slots.find(s => s && s.nameTag?.includes("White Widow"));
ok(ww && ww.amount === 4, "capacity capped at 16 (6 White Widow added, 4 stay in inventory)");
ok(slots[2] && slots[2].amount === 3, "dried buds were not offered or taken");
ok(/50%/.test(globalThis.__lastBody) && /1:00 left/.test(globalThis.__lastBody), "progress bar shows 50% / 1:00 left for first batch");

// at 2:00 total: first batch done, second not
fakeNow += 60_000;
ui.__queue({ canceled: true });
await T.openRack(p, "minecraft:overworld", loc);
ok(globalThis.__lastButtons.some(b => b.includes("Collect dried items (10)")), "collect button offers the 10 finished buds only");
ui.__queue({ canceled: false, selection: 0 /* no add: rack full -> first button is collect */ }, { canceled: true });
await T.openRack(p, "minecraft:overworld", loc);
const driedOG = slots.find(s => s && s.nameTag?.includes("OG Kush"));
ok(driedOG && driedOG.amount === 10 && T.isDried(driedOG), "collected 10 DRIED OG Kush");
ok(T.getGenetics(driedOG).name === "OG Kush", "dried buds keep their genetics");
ok(rackState === 1, "rack still drying (White Widow batch)");

// breaking the rack at 2:30: White Widow batch is 1:30 in -> drops WET
fakeNow += 30_000; spawned.length = 0;
T.dropRackContents(globalThis.__dim, loc, T.rackKey("minecraft:overworld", loc));
ok(spawned.length === 1 && spawned[0].amount === 6 && !T.isDried(spawned[0]), "breaking early drops unfinished batch as wet");
ok(T.loadRack(T.rackKey("minecraft:overworld", loc)).entries.length === 0, "rack storage cleared");
console.log(fails ? `\n${fails} FAILURES` : "\nALL RACK TESTS PASSED");
