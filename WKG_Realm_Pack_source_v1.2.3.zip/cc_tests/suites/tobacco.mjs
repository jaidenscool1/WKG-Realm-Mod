// Tobacco products: drying leaves, cigarettes (stackable, 1 hit), the 12-pack (12 hits, Swiftness I only).
import { __test as T } from "../main.mjs";
import srv from "@minecraft/server";
import ui from "@minecraft/server-ui";

let fails = 0;
const ok = (c, m) => { console.log((c ? "PASS " : "FAIL ") + m); if (!c) fails++; };
let fakeNow = 5_000_000; Date.now = () => fakeNow;

function makePlayer() {
  const slots = new Array(36).fill(undefined);
  const effects = [], msgs = [];
  const container = { size: 36, getItem: (i) => slots[i], setItem: (i, s) => { slots[i] = s; },
    addItem: (s) => { slots[slots.findIndex((x) => x === undefined)] = s; } };
  return { id: "p" + Math.random(), slots, effects, msgs, selectedSlotIndex: 0, getComponent: () => ({ container }),
    addEffect: (id, dur, o) => effects.push([id, o?.amplifier ?? 0, dur]), sendMessage: (m) => msgs.push(m), playSound() {},
    onScreenDisplay: { setActionBar: (m) => msgs.push(m) }, getHeadLocation: () => ({ x: 0, y: 0, z: 0 }),
    getViewDirection: () => ({ x: 0, y: 0, z: 1 }), dimension: { spawnParticle() {}, spawnItem() {} }, location: {} };
}

// ---- drying rack: tobacco leaves -> dried tobacco ----
{
  let state = 0;
  const block = { typeId: "cc:drying_rack", permutation: { getState: () => state, withState: (_, v) => ({ v }) }, setPermutation: (p) => { state = p.v; } };
  globalThis.__dim = { id: "minecraft:overworld", getBlock: () => block, spawnItem() {} };
  const loc = { x: 9, y: 64, z: 9 };
  const p = makePlayer();
  p.slots[0] = new srv.ItemStack("cc:tobacco_leaf", 6);
  p.slots[1] = T.makeBudItem(T.baseGenetics("og_kush"), 2);
  // add form: candidates are [tobacco (slot 0), og kush (slot 1)] -> pick tobacco, 6
  ui.__queue({ canceled: false, formValues: [0, 6] }, { canceled: true });
  await T.addToRack(p, "minecraft:overworld", loc);
  ok(p.slots[0] === undefined, "6 tobacco leaves hung on the rack");
  fakeNow += 2 * 60 * 1000 + 1;
  ui.__queue({ canceled: false, selection: 1 }, { canceled: true }); // [add, collect, ...] -> collect
  await T.openRack(p, "minecraft:overworld", loc);
  const dried = p.slots.find((s) => s && s.typeId === "cc:dried_tobacco");
  ok(dried && dried.amount === 6, "after 2 minutes they come off as 6 Dried Tobacco");
  ok(p.slots.some((s) => s && s.typeId === "cc:bud"), "buds weren't touched");
}

// ---- a single cigarette: stackable, one hit, Swiftness I ----
{
  const p = makePlayer();
  p.slots[0] = new srv.ItemStack("cc:cigarette", 5);
  T.takeHit(p, p.slots[0]);
  ok(p.slots[0]?.typeId === "cc:cigarette" && p.slots[0].amount === 4, "smoking one cigarette from a stack of 5 leaves 4");
  ok(p.effects.length === 1 && p.effects[0][0] === "speed" && p.effects[0][1] === 0, "a cigarette gives Swiftness I and nothing else");
  p.slots[0] = new srv.ItemStack("cc:cigarette", 1);
  T.takeHit(p, p.slots[0]);
  ok(p.slots[0] === undefined, "the last cigarette is used up");
}

// ---- packing: red dye in hand + 12 cigarettes + 1 paper ----
{
  const p = makePlayer();
  p.slots[0] = new srv.ItemStack("minecraft:red_dye", 2);
  p.slots[1] = new srv.ItemStack("cc:cigarette", 10);
  p.slots[2] = new srv.ItemStack("minecraft:paper", 3);
  ok(T.packCigarettes(p) === false && p.slots[1].amount === 10 && p.slots[0].amount === 2, "10 cigarettes aren't enough - nothing is used");
  p.slots[3] = new srv.ItemStack("cc:cigarette", 16);
  ok(T.packCigarettes(p) === true, "with 26 cigarettes a pack is made");
  const cigsLeft = p.slots.filter((s) => s && s.typeId === "cc:cigarette").reduce((n, s) => n + s.amount, 0);
  ok(cigsLeft === 14 && p.slots[2].amount === 2 && p.slots[0].amount === 1, "it used exactly 12 cigarettes, 1 paper and 1 red dye");
  const pack = p.slots.find((s) => s && s.typeId === "cc:cigarette_pack");
  ok(!!pack, "the player got a Marlboro Reds pack");
}

// ---- the pack: 12 hits, stages every 3, Swiftness I only; it comes out "lit" after the first hit ----
{
  const p = makePlayer();
  p.slots[0] = new srv.ItemStack("cc:cigarette_pack", 1);
  const seq = [];
  for (let i = 0; i < 12; i++) {
    T.takeHit(p, p.slots[0]);
    seq.push(p.slots[0]?.typeId ?? "gone");
  }
  // seq[i] = the item after hit i+1: 3 smoked -> 9 left (s1), 6 -> s2, 9 -> s3
  ok(seq[0] === "cc:cigarette_pack_lit", "after the first hit the pack is lit (cigarette stays at the mouth)");
  ok(seq[1] === "cc:cigarette_pack_lit" && seq[2] === "cc:cigarette_pack_lit_s1" && seq[5] === "cc:cigarette_pack_lit_s2" &&
     seq[8] === "cc:cigarette_pack_lit_s3" && seq[10] === "cc:cigarette_pack_lit_s3", "a lit pack still empties in stages (12 -> 9 -> 6 -> 3 left)");
  ok(seq[11] === "gone", "after 12 hits the pack is gone");
  ok(p.effects.length === 12 && p.effects.every(([id, amp]) => id === "speed" && amp === 0), "every hit gives only Swiftness I");
}

// ---- a lit pack goes back to normal when it leaves the hand, keeping its hits ----
{
  const p = makePlayer();
  p.slots[0] = new srv.ItemStack("cc:cigarette_pack", 1);
  for (let i = 0; i < 4; i++) T.takeHit(p, p.slots[0]);
  ok(p.slots[0].typeId === "cc:cigarette_pack_lit_s1", "4 hits in: a lit pack with 8 left");
  ok(T.revertLitPacks(p) === 0 && p.slots[0].typeId === "cc:cigarette_pack_lit_s1", "still in the selected slot: stays lit");
  p.selectedSlotIndex = 3; // switched hotbar slot
  ok(T.revertLitPacks(p) === 1 && p.slots[0].typeId === "cc:cigarette_pack_s1", "switched away: back to the normal pack");
  ok(p.slots[0].getDynamicProperty("cc:uses") === 4 && p.slots[0].getComponent("minecraft:durability").damage === 4,
    "it keeps its 4 used hits and its wear bar");
  p.selectedSlotIndex = 0;
  T.takeHit(p, p.slots[0]);
  ok(p.slots[0].typeId === "cc:cigarette_pack_lit_s1" && p.slots[0].getDynamicProperty("cc:uses") === 5, "the next hit lights it again and counts on");
}

console.log(fails ? `\n${fails} FAILURES` : "\nALL TOBACCO TESTS PASSED");
