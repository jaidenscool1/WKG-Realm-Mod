// Offhand smoking: double-tap sneak and HOLD for the drag time takes a hit from the offhand item.
import { __test as T } from "../main.mjs";
import srv from "@minecraft/server";

let fails = 0;
const ok = (c, m) => { console.log((c ? "PASS " : "FAIL ") + m); if (!c) fails++; };

let nextId = 0;
function makePlayer(offhand, mainhand) {
  const slots = new Array(36).fill(undefined);
  slots[0] = mainhand;
  const equip = { off: offhand,
    getEquipment(slot) { return slot === "Offhand" ? this.off : undefined; },
    setEquipment(slot, s) { if (slot === "Offhand") this.off = s; return true; } };
  const container = { size: 36, getItem: (i) => slots[i], setItem: (i, s) => { slots[i] = s; } };
  const effects = [];
  const props = {};
  return { id: "p" + nextId++, slots, equip, effects, props, selectedSlotIndex: 0, sounds: 0,
    getComponent: (id) => (id === "minecraft:equippable" ? equip : { container }),
    getDynamicProperty: (k) => props[k], setDynamicProperty: (k, v) => { props[k] = v; },
    addEffect: (id) => effects.push(id), playSound() { this.sounds++; }, sendMessage() {},
    onScreenDisplay: { setActionBar() {} }, getHeadLocation: () => ({ x: 0, y: 0, z: 0 }),
    getViewDirection: () => ({ x: 0, y: 0, z: 1 }), dimension: { spawnParticle() {} } };
}
function smokable(id, name = "Test Joint") {
  const s = new srv.ItemStack(id, 1);
  s.nameTag = name;
  s.setLore(["§7THC: 20%"]);
  s.setDynamicProperty("cc:smoke", JSON.stringify({ thc: 20, effects: [["speed", 0]], dryMult: 1 }));
  return s;
}
const uses = (s) => s?.getDynamicProperty("cc:uses") ?? 0;
// press sneak at `first` (1 tick), then press again at `second` and hold for `holdTicks`
let clockTick = 0;
function doubleTapHold(p, holdTicks, gap = 4) {
  const first = clockTick + 5, second = first + gap, end = second + holdTicks + 3;
  for (let t = clockTick; t <= end; t++) {
    const down = t === first || (t >= second && t < second + holdTicks);
    T.onSneakSample(p, down, t);
  }
  clockTick = end + 20;
}
const JOINT = 20, BONG = 40, VAPE = 60; // drag times in ticks

// double-tap + hold the full drag time -> one hit
const pick = new srv.ItemStack("minecraft:diamond_pickaxe", 1);
let p = makePlayer(smokable("cc:joint"), pick);
doubleTapHold(p, JOINT + 2);
ok(uses(p.equip.off) === 1 && p.effects.includes("speed"), "double-tap sneak + hold 1s takes a hit from the offhand joint");
ok(p.slots[0] === pick, "the main-hand item is untouched");
ok(p.equip.off.nameTag === "Test Joint" && p.equip.off.getDynamicProperty("cc:smoke"), "the joint keeps its name and strain data");
ok(!p.props["cc:smoke_stage"], "the smoke trickle stops after the hit");

// holding far longer still gives only one hit
p = makePlayer(smokable("cc:joint"));
doubleTapHold(p, JOINT * 5);
ok(uses(p.equip.off) === 1, "holding longer than the drag time still takes just one hit");

// letting go early cancels
p = makePlayer(smokable("cc:joint"));
doubleTapHold(p, JOINT - 5);
ok(uses(p.equip.off) === 0 && !p.props["cc:smoke_stage"], "letting go before 1s cancels the hit");

// the drag time follows the item: bong 2s, vape 3s
p = makePlayer(smokable("cc:bong_packed", "Test Bong"));
doubleTapHold(p, JOINT + 2);
ok(uses(p.equip.off) === 0, "a bong held only 1s gives no hit");
doubleTapHold(p, BONG + 1);
ok(uses(p.equip.off) === 1, "a bong held 2s gives a hit");
p = makePlayer(smokable("cc:vape_pen", "Test Vape"));
doubleTapHold(p, VAPE + 1);
ok(uses(p.equip.off) === 1, "a vape held 3s gives a hit");

// smoke trickles during the hold
p = makePlayer(smokable("cc:joint"));
{
  const first = 5, second = 9;
  let during = false;
  for (let t = 0; t < second + 10; t++) {
    T.onSneakSample(p, t === first || t >= second, t);
    if (t === second + 5) during = !!p.props["cc:smoke_stage"];
  }
  ok(during, "smoke trickles while the hold is in progress");
  for (let t = second + 10; t < second + 30; t++) T.onSneakSample(p, false, t);
}

// ordinary sneaking never smokes
p = makePlayer(smokable("cc:joint"));
for (let t = 0; t < 100; t++) T.onSneakSample(p, t >= 5, t);
ok(uses(p.equip.off) === 0, "just holding sneak doesn't smoke");
p = makePlayer(smokable("cc:joint"));
doubleTapHold(p, JOINT + 2, 20);
ok(uses(p.equip.off) === 0, "two taps 1 second apart don't start a hit");

// run a joint out from the offhand; a bong reverts to empty
p = makePlayer(smokable("cc:joint"));
for (let i = 0; i < 4; i++) doubleTapHold(p, JOINT + 1);
ok(p.equip.off === undefined, "a joint smoked to the end from the offhand disappears");
p = makePlayer(smokable("cc:bong_packed", "Test Bong"));
for (let i = 0; i < 6; i++) doubleTapHold(p, BONG + 1);
ok(p.equip.off?.typeId === "cc:bong", "a finished bong turns back into an empty bong in the offhand");

// non-smokable in the offhand -> nothing happens
p = makePlayer(new srv.ItemStack("minecraft:shield", 1));
doubleTapHold(p, BONG);
ok(p.equip.off.typeId === "minecraft:shield" && p.sounds === 0 && !p.props["cc:smoke_stage"], "a shield in the offhand is left alone");

// the real input path: Sneak button events + the per-tick hold check
{
  const onButton = srv.__handlers["after:playerButtonInput"]?.[0];
  ok(typeof onButton === "function", "listens for the Sneak button event");
  p = makePlayer(smokable("cc:joint"));
  p.isValid = true;
  const press = (t, down) => { srv.system.currentTick = t; onButton({ player: p, button: "Sneak", newButtonState: down ? "Pressed" : "Released" }); };
  let base = 5000;
  press(base, true); press(base + 1, false); press(base + 4, true);         // double-tap, keep holding
  for (let t = base + 4; t <= base + 4 + JOINT + 1; t++) T.tickOffhandHolds(t);
  ok(uses(p.equip.off) === 1, "button events + holding for 1s take a hit");
  onButton({ player: p, button: "Jump", newButtonState: "Pressed" });
  ok(uses(p.equip.off) === 1, "the Jump button is ignored");
  press(base + 100, false);
  base += 200;
  press(base, true); press(base + 1, false); press(base + 4, true); press(base + 10, false); // let go early
  for (let t = base + 4; t <= base + 40; t++) T.tickOffhandHolds(t);
  ok(uses(p.equip.off) === 1, "releasing the button early cancels");
}

// main-hand smoking still works the old way
p = makePlayer(undefined, smokable("cc:joint"));
T.takeHit(p, p.slots[0]);
ok(uses(p.slots[0]) === 1, "main-hand smoking still works");

console.log(fails ? `\n${fails} FAILURES` : "\nALL OFFHAND TESTS PASSED");
