import { __test as T } from "../main.mjs";
import srv from "@minecraft/server"; import ui from "@minecraft/server-ui";
let fails = 0; const ok = (c, m) => { console.log((c ? "PASS " : "FAIL ") + m); if (!c) fails++; };
let fakeNow = 5_000_000; Date.now = () => fakeNow;

const state = { "cc:status": 0 }; const spawned = [];
const block = { typeId: "cc:distiller", location: { x: 3, y: 64, z: 3 },
  get permutation() { return { getState: (k) => state[k], withState: (k, v) => ({ k, v }) }; },
  setPermutation: (p) => { state[p.k] = p.v; } };
const dim = { id: "minecraft:overworld", getBlock: () => block, spawnItem: (s) => spawned.push(s), playSound() {} };
block.dimension = dim; globalThis.__dim = dim;

const slots = new Array(36).fill(undefined);
const container = { size: 36, getItem: i => slots[i], setItem: (i, s) => { slots[i] = s; },
  addItem: s => { slots[slots.findIndex(x => x === undefined)] = s; } };
const msgs = [];
const p = { id: "p4", isValid: true, selectedSlotIndex: 0, getComponent: () => ({ container }), sendMessage: m => msgs.push(m),
  onScreenDisplay: { setActionBar: m => msgs.push(m) }, dimension: dim, location: {}, addEffect() {},
  getHeadLocation: () => ({ x: 0, y: 0, z: 0 }), getViewDirection: () => ({ x: 0, y: 0, z: 1 }) };
const D = "minecraft:overworld", loc = { x: 3, y: 64, z: 3 };
const key = T.stillKey(D, loc);
const count = (id) => slots.filter(s => s && s.typeId === id).reduce((n, s) => n + s.amount, 0);
const find = (id) => slots.find(s => s && s.typeId === id);
const clear = () => slots.fill(undefined);

const og = T.baseGenetics("og_kush");
const rosinG = { ...og, thc: 71 };

// idle menu lists the processes, with escaped percent signs
ui.__queue({ canceled: true });
await T.openDistiller(p, D, loc);
ok(/Wax/.test(globalThis.__lastBody) && /Distillate/.test(globalThis.__lastBody) && /100%%/.test(globalThis.__lastBody), "idle menu lists processes with yields");

// no fuel -> refused, nothing consumed
slots[1] = T.makeRosinItem(rosinG, 10, true);
ui.__queue({ canceled: false, selection: 0 }, { canceled: false, formValues: [0, 3, 10] });
await T.openDistiller(p, D, loc);
ok(/needs 1 Ender Pearl/.test(msgs.at(-1)) && count("cc:rosin") === 10 && !T.loadStill(key), "distillate without an ender pearl is refused");

// shatter: 10 dried rosin + blaze rod
slots[2] = new srv.ItemStack("minecraft:blaze_rod", 3);
ui.__queue({ canceled: false, selection: 0 }, { canceled: false, formValues: [0, 1, 10] });
await T.openDistiller(p, D, loc);
const still = T.loadStill(key);
ok(still && still.proc === "shatter" && count("cc:rosin") === 0 && count("minecraft:blaze_rod") === 2, "shatter batch uses 10 rosin + 1 blaze rod");
ok(still.out === 11 || still.out === 12, `10 dried rosin x 90% x 1.25 = 11-12 shatter (got ${still.out})`);
ok(state["cc:status"] === 1, "distiller shows working");

// half way
fakeNow += 60_000;
ui.__queue({ canceled: true });
await T.openDistiller(p, D, loc);
ok(/50%%/.test(globalThis.__lastBody) && /1:00 left/.test(globalThis.__lastBody), "progress shows 50%% / 1:00 left");
ok(globalThis.__lastButtons.includes("§4Stop and take the rosin back"), "can stop mid-batch");

// done at 2:00 -> collect
fakeNow += 60_000;
ui.__queue({ canceled: false, selection: 0 });
await T.openDistiller(p, D, loc);
const shatter = find("cc:shatter");
ok(shatter && shatter.amount === still.out, "collected the shatter");
ok(T.getGenetics(shatter).thc === 81 && T.getGenetics(shatter).name === "OG Kush", "71% rosin -> 81% shatter (75-85 range), keeps strain");
ok(!T.loadStill(key) && state["cc:status"] === 0, "distiller empty again after collecting");

// stop mid-batch returns rosin + fuel, and the rosin stacks with what it was
clear();
slots[1] = T.makeRosinItem(rosinG, 6, false);
slots[2] = new srv.ItemStack("minecraft:charcoal", 1);
ui.__queue({ canceled: false, selection: 0 }, { canceled: false, formValues: [0, 0, 4] });
await T.openDistiller(p, D, loc);
ok(T.loadStill(key)?.proc === "wax" && count("cc:rosin") === 2 && count("minecraft:charcoal") === 0, "wax runs on charcoal");
ui.__queue({ canceled: false, selection: 1 });
await T.openDistiller(p, D, loc);
ok(count("cc:rosin") === 6 && count("minecraft:charcoal") === 1 && !T.loadStill(key), "stopping returns the rosin and fuel");
const rosins = slots.filter(s => s && s.typeId === "cc:rosin");
ok(rosins.every(r => r.stackKey() === rosins[0].stackKey()), "returned rosin stacks with the original");

// breaking a finished distiller drops the product; live resin boosts effects
clear();
slots[1] = T.makeRosinItem(rosinG, 8, false);
slots[2] = new srv.ItemStack("minecraft:magma_cream", 1);
ui.__queue({ canceled: false, selection: 0 }, { canceled: false, formValues: [0, 2, 8] });
await T.openDistiller(p, D, loc);
fakeNow += 3 * 60_000;
spawned.length = 0;
T.dropStillContents(dim, loc, key);
const lr = spawned.find(s => s.typeId === "cc:live_resin");
ok(lr && !T.loadStill(key), "broken distiller drops the finished live resin");
ok(T.getGenetics(lr).effects.every(([, amp]) => amp === 1), "live resin makes each effect one level stronger");

// distillate THC is capped at 99
const dist = (thc) => T.concentrateGenetics({ ...og, thc }, T.DISTILL_PROCESSES.distillate).thc;
ok(dist(75) === 99.9 && dist(65) === 90 && dist(88) === 99.9, "distillate: 65% rosin -> 90%, 75% rosin -> 99.9% (the max)");
for (const [k, p] of Object.entries(T.DISTILL_PROCESSES)) {
  const lo = T.concentrateGenetics({ ...og, thc: 65 }, p).thc, hi = T.concentrateGenetics({ ...og, thc: 75 }, p).thc;
  ok(lo === p.thc[0] && hi === p.thc[1], `${p.name}: ${lo}-${hi}%`);
}

// dab: empty bong + shatter at the rolling table
clear();
slots[0] = new srv.ItemStack("cc:bong", 1);
slots[3] = shatter;
ui.__queue({ canceled: false, formValues: [true] });
await T.handleRolling(p);
ok(slots[0]?.typeId === "cc:bong_packed" && /Dab/.test(slots[0].nameTag), "shatter packs a bong as a dab");
ok(JSON.parse(slots[0].getDynamicProperty("cc:smoke")).thc === 81, "dab keeps the shatter's THC");

// cartridges: joints refuse concentrates, carts refuse buds
clear();
slots[0] = new srv.ItemStack("cc:cart_empty", 3);
slots[4] = T.makeBudItem(og, 5);
await T.handleRolling(p);
ok(/Distillate or Live Resin/.test(msgs.at(-1)), "cartridge won't take buds");
const distG = T.concentrateGenetics(rosinG, T.DISTILL_PROCESSES.distillate);
slots[5] = T.makeConcentrateItem(distG, 4, "distillate");
slots[6] = T.makeConcentrateItem(T.concentrateGenetics({ ...T.baseGenetics("blue_dream"), thc: 80 }, T.DISTILL_PROCESSES.live_resin), 2, "live_resin");
ui.__queue({ canceled: false, formValues: [true, false] });
await T.handleRolling(p);
ui.__queue({ canceled: false, formValues: [true, false] });
await T.handleRolling(p);
const carts = slots.filter(s => s && s.typeId === "cc:cart_filled");
ok(carts.length === 2 && carts[0].stackKey() === carts[1].stackKey(), "identical carts stack");
ok(count("cc:cart_empty") === 1 && count("cc:distillate") === 2, "each cart used 1 empty cart + 1 distillate");
ok(T.readCart(carts[0]).kind === "Distillate" && T.readCart(carts[0]).thc === 95.9, "cart reads back as 95.9% OG Kush distillate");
ui.__queue({ canceled: false, formValues: [true, true] });
await T.handleRolling(p);
const mixed = slots.find(s => s && s.typeId === "cc:cart_filled" && /Mixed/.test(s.nameTag));
ok(mixed && T.readCart(mixed).kind === "Mixed" && T.readCart(mixed).strains.length === 2, "two-strain mixed cart");
slots[0] = new srv.ItemStack("cc:cart_empty", 1);
slots[7] = T.makeConcentrateItem(T.concentrateGenetics({ ...T.baseGenetics("sour_diesel"), thc: 80 }, T.DISTILL_PROCESSES.distillate), 1, "distillate");
slots[8] = T.makeConcentrateItem(T.concentrateGenetics({ ...T.baseGenetics("gorilla_glue"), thc: 80 }, T.DISTILL_PROCESSES.distillate), 1, "distillate");
ui.__queue({ canceled: false, formValues: [true, true, true, true] });
await T.handleRolling(p);
ok(/at most 3/.test(msgs.at(-1)), "a cart holds at most 3 strains");

// vape pen crafting: cart leaves the inventory (crafting grid), blank pen appears -> linked
clear();
T.watchCarts(p);
slots[2] = T.makeCartItem([{ typeId: "cc:distillate", genetics: distG }]);
T.watchCarts(p);
slots[2] = undefined;                // moved into the crafting grid
T.watchCarts(p);
slots[0] = new srv.ItemStack("cc:vape_pen", 1); // crafted
T.watchCarts(p);
const pen = slots[0];
const penData = JSON.parse(pen.getDynamicProperty("cc:smoke") ?? "null");
ok(penData && penData.thc === 95.9 && penData.strains[0] === "OG Kush" && /OG Kush Vape/.test(pen.nameTag), "crafted pen takes the cart's strain and THC");

// cart put back in the inventory is no longer a match
clear();
slots[2] = T.makeCartItem([{ typeId: "cc:distillate", genetics: distG }]);
T.watchCarts(p);
slots[2] = undefined; T.watchCarts(p);
slots[3] = T.makeCartItem([{ typeId: "cc:distillate", genetics: distG }]); T.watchCarts(p);
slots[0] = new srv.ItemStack("cc:vape_pen", 1); T.watchCarts(p);
ok(/Unknown/.test(slots[0].nameTag) && slots[3], "no cart consumed -> pen marked Unknown, cart untouched");

// 16 hits, then the empty battery is left
clear();
slots[0] = pen;
const vapeSeq = [];
let vapeDataKept = true;
for (let i = 0; i < 16; i++) {
  T.takeHit(p, slots[0]);
  vapeSeq.push(slots[0]?.typeId);
  if (i < 15 && (!slots[0].getDynamicProperty("cc:smoke") || !/OG Kush Vape/.test(slots[0].nameTag))) vapeDataKept = false;
}
ok(slots[0]?.typeId === "cc:vape_battery", "after 16 hits the cart is used up and the battery remains");
const stageAt = (hits) => vapeSeq[hits - 1];
ok(stageAt(3) === "cc:vape_pen" && stageAt(4) === "cc:vape_pen_s1" && stageAt(8) === "cc:vape_pen_s2" && stageAt(12) === "cc:vape_pen_s3" && stageAt(15) === "cc:vape_pen_s3",
  "oil level drops a stage every 4 hits (full -> s1 -> s2 -> s3)");
ok(vapeDataKept, "strain, THC and name survive every oil-stage swap");

console.log(fails ? `\n${fails} FAILURES` : "\nALL PHASE 4 TESTS PASSED");
