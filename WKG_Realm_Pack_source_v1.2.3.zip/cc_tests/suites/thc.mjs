import { __test as T } from "../main.mjs";
let fails = 0; const ok = (c, m) => { console.log((c ? "PASS " : "FAIL ") + m); if (!c) fails++; };

// effect duration scales with THC
const dur = (thc, fx = [["speed", 0]]) => { const got = []; T.applyEffects({ addEffect: (id, d) => got.push([id, d]) }, fx, thc, 300); return got; };
ok(dur(15)[0][1] === 300, "15% THC = normal length (300 ticks)");
ok(dur(30)[0][1] === 450, "30% THC = 1.5x (450 ticks)");
ok(dur(45)[0][1] === 600, "45% THC = 2x (600 ticks)");
ok(dur(90)[0][1] === 1050, "90% THC = 3.5x (1050 ticks)");
ok(dur(28)[0][1] > dur(22)[0][1], "stronger strain lasts longer");
ok(dur(90, [["levitation", 0]])[0][1] === 60, "levitation stays fixed at 3s regardless of THC");

// rosin THC stays within 75-90%
let lo = 100, hi = 0;
for (let thc = 1; thc <= 45; thc++) for (let tier = 1; tier <= 4; tier++) for (const dried of [false, true]) {
  const r = T.rosinThc(thc, tier, dried); lo = Math.min(lo, r); hi = Math.max(hi, r);
}
ok(lo === 65 && hi === 75, `rosin THC always 65-75% (got ${lo}-${hi})`);
ok(T.rosinThc(22, 4, true) > T.rosinThc(22, 1, true), "better plate gives stronger rosin");
ok(T.rosinThc(22, 2, true) > T.rosinThc(22, 2, false), "dried buds give stronger rosin");
ok(T.rosinThc(28, 2, false) > T.rosinThc(16, 2, false), "stronger strain gives stronger rosin");
console.log(fails ? `\n${fails} FAILURES` : "\nALL THC TESTS PASSED");
