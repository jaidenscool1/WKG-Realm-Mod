import { __test as T } from "../main.mjs";
import srv from "@minecraft/server";
import ui from "@minecraft/server-ui";
const { ItemStack } = srv;
let fails = 0;
const ok = (cond, msg) => { console.log((cond ? "PASS " : "FAIL ") + msg); if (!cond) fails++; };

// fake player with a 36-slot inventory
function makePlayer() {
  const slots = new Array(36).fill(undefined);
  const container = { size: 36, getItem: (i) => slots[i], setItem: (i, s) => { slots[i] = s; },
    addItem: (s) => { const i = slots.findIndex(x => x === undefined); slots[i] = s; return undefined; } };
  const msgs = []; const effects = [];
  return { id: "p1", slots, selectedSlotIndex: 0, messages: msgs, effects,
    getComponent: () => ({ container }), sendMessage: (m) => msgs.push(m),
    onScreenDisplay: { setActionBar: (m) => msgs.push(m) },
    addEffect: (id, dur, o) => effects.push([id, dur, o.amplifier]),
    getHeadLocation: () => ({x:0,y:1,z:0}), getViewDirection: () => ({x:0,y:0,z:1}),
    dimension: { spawnItem: () => {}, spawnParticle: () => {} }, location: {x:0,y:0,z:0} };
}

// 1. strains
ok(Object.keys(T.STRAINS).length === 18, "18 strains defined (15 + 3 Funguy exclusives)");
ok(T.COMMON_KEYS.length === 9, "9 common (craftable) strains");

// 2. genetics round trip through lore + stacking
const g = T.baseGenetics("purple_punch");
const budA = T.makeBudItem(g, 3), budB = T.makeBudItem(T.baseGenetics("purple_punch"), 2);
ok(budA.stackKey() === budB.stackKey(), "identical genetics produce identical (stackable) buds");
const back = T.getGenetics(budA);
ok(back && back.name === "Purple Punch" && back.effects.length === 2, "genetics read back from lore");
ok(!T.isDried(budA), "fresh bud is Wet");
ok(T.isDried(T.makeBudItem(g, 1, true)), "dried flag reads back");
ok(T.makeBudItem(g,1,true).stackKey() !== budA.stackKey(), "wet and dried don't stack together");
ok(T.makeSeedItem(g).typeId === "cc:seed_purple_punch", "pure base strain drops its plain seed item");

// 3. breeding: effects merge (capped at 3), rare discovery
let rareHits = 0, maxFx = 0;
for (let i = 0; i < 400; i++) {
  const { child, rare } = T.crossGenetics(T.baseGenetics("blue_dream"), T.baseGenetics("green_crack"));
  if (rare) { rareHits++; ok(rare === "white_widow", "rare = white widow") || 0; }
  else maxFx = Math.max(maxFx, child.effects.length);
}
ok(rareHits > 60 && rareHits < 180, `rare discovery rate ~30% (got ${rareHits}/400)`);
const big = T.crossGenetics(T.baseGenetics("sleepy_joe_og"), T.baseGenetics("og_kush"));
ok((big.rare || big.child.effects.length <= 3), "bred effects capped at 3");
const hy = T.crossGenetics(T.baseGenetics("og_kush"), T.baseGenetics("tysgorilla")).child;
ok(T.makeSeedItem(hy).typeId === "cc:seed_hybrid" && T.getGenetics(T.makeSeedItem(hy)).name === hy.name, "hybrid seed round trip");

// 4. breeding station flow with stacked seeds
const p = makePlayer();
p.slots[0] = new ItemStack("cc:seed_og_kush", 5);
p.slots[1] = new ItemStack("cc:seed_tysgorilla", 1);
ui.__setResponse({ canceled: false, formValues: [0, 1, "Iron Kush"] });
await T.handleBreeding(p);
ok(p.slots[0].amount === 4 && !p.slots.some(s => s && s.typeId === "cc:seed_tysgorilla"), "breeding consumes one seed from each stack");
const child = p.slots.find(s => s && s.typeId === "cc:seed_hybrid");
ok(child && child.nameTag.includes("Iron Kush"), "custom name applied to bred seed");

// 5. rolling a blunt and smoking it to the end
const p2 = makePlayer();
p2.slots[0] = new ItemStack("cc:tobacco_leaf", 3);
p2.slots[1] = T.makeBudItem(T.baseGenetics("skywalker_og"), 2);
p2.slots[2] = T.makeBudItem(T.baseGenetics("purple_punch"), 1, true);
ui.__setResponse({ canceled: false, formValues: [true, true] });
await T.handleRolling(p2);
const blunt = p2.slots.find(s => s && s.typeId === "cc:blunt");
ok(!!blunt, "blunt created"); ok(p2.slots[0].amount === 2, "one tobacco leaf used");
ok(p2.slots.filter(s => s && s.typeId === "cc:bud").reduce((n,s)=>n+s.amount,0) === 1, "one bud per chosen strain used");
const bslot = p2.slots.indexOf(blunt); p2.selectedSlotIndex = bslot;
for (let i = 0; i < 8; i++) T.takeHit(p2);
ok(p2.slots[bslot] === undefined, "blunt used up after exactly 8 hits");
const lev = p2.effects.find(e => e[0] === "levitation");
ok(lev && lev[1] === 60, "levitation always 3 seconds");
ok(p2.effects.some(e => e[0] === "night_vision") && p2.effects.some(e => e[0] === "fire_resistance"), "blunt applies all strains' effects");

// 6. bong reverts to empty after 6
const p3 = makePlayer();
p3.slots[0] = new ItemStack("cc:bong", 1);
p3.slots[1] = T.makeBudItem(T.baseGenetics("og_kush"), 1);
ui.__setResponse({ canceled: false, formValues: [true] });
await T.handleRolling(p3);
ok(p3.slots[0].typeId === "cc:bong_packed", "bong packed in hand");
for (let i = 0; i < 6; i++) T.takeHit(p3);
ok(p3.slots[0] && p3.slots[0].typeId === "cc:bong", "bong returns to empty after 6 hits");

// 7. strain limit enforced
const p4 = makePlayer();
p4.slots[0] = new ItemStack("cc:rolling_paper", 1);
["og_kush","blue_dream","sour_diesel","purple_haze","gorilla_glue"].forEach((k,i)=> p4.slots[i+1] = T.makeBudItem(T.baseGenetics(k),1));
ui.__setResponse({ canceled: false, formValues: [true,true,true,true,true] });
await T.handleRolling(p4);
ok(!p4.slots.some(s => s && s.typeId === "cc:joint") && p4.slots[0].amount === 1, "joint refuses a 5th strain and consumes nothing");

console.log(fails ? `\n${fails} FAILURES` : "\nALL TESTS PASSED");
process.exit(fails ? 1 : 0);
