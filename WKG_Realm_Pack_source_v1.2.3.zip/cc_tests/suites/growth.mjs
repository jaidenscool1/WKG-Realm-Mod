// Crop growth loop: markers (V2: isValid is a property) advance their plant's growth state.
import { __test as T } from "../main.mjs";

let fails = 0;
const ok = (c, m) => { console.log((c ? "PASS " : "FAIL ") + m); if (!c) fails++; };

function makeWorld(plants) {
  // plants: [{ crop, typeId, growth, moist }]
  const blocks = new Map(), markers = [];
  plants.forEach((pl, i) => {
    const loc = { x: i * 3, y: 64, z: 0 };
    const block = { typeId: pl.typeId, location: loc, growth: pl.growth, tint: pl.tint ?? 0, tintSets: 0,
      get permutation() { const b = this; return { getState: (s) => (s === "cc:growth" ? b.growth : s === "cc:tint" ? b.tint : undefined),
        withState: (s, v) => ({ s, v }) }; },
      setPermutation(p) { if (p.s === "cc:growth") this.growth = p.v; else if (p.s === "cc:tint") { this.tint = p.v; this.tintSets++; } } };
    blocks.set(`${loc.x},${loc.y},${loc.z}`, block);
    blocks.set(`${loc.x},${loc.y - 1},${loc.z}`, { permutation: { getState: () => pl.moist ?? 0 } });
    const props = { "cc:crop": pl.crop, "cc:genetics": JSON.stringify(pl.genetics ?? { growth: 1 }) };
    markers.push({ isValid: true, location: { x: loc.x + 0.5, y: loc.y, z: loc.z + 0.5 }, removed: false,
      getDynamicProperty: (k) => props[k], remove() { this.removed = true; } });
  });
  globalThis.__dim = { getEntities: () => markers.filter((m) => !m.removed),
    getBlock: (l) => blocks.get(`${l.x},${l.y},${l.z}`) };
  return { blocks, markers };
}

const real = Math.random;
Math.random = () => 0; // every growth roll succeeds
const w = makeWorld([
  { crop: "cannabis", typeId: "cc:cannabis_plant", growth: 0 },
  { crop: "tobacco", typeId: "cc:tobacco_plant", growth: 1 },
  { crop: "cannabis", typeId: "cc:cannabis_plant", growth: 4 }, // already mature
  { crop: "cannabis", typeId: "minecraft:air", growth: 0 } // plant gone
]);
T.growPlants();
const at = (i) => w.blocks.get(`${i * 3},64,0`);
ok(at(0).growth >= 1, "a cannabis plant grows a stage");
ok(at(1).growth >= 2, "a tobacco plant grows a stage");
ok(at(2).growth === 4, "a mature plant stays mature");
ok(w.markers[3].removed, "a marker whose plant is gone is cleaned up");

Math.random = () => 0.99; // every roll fails
const before = at(0).growth;
T.growPlants();
ok(at(0).growth === before, "no growth when the random roll fails");
Math.random = real;

// the V2 bug: an invalid marker must be skipped, not crash the loop for everyone
const w2 = makeWorld([{ crop: "cannabis", typeId: "cc:cannabis_plant", growth: 0 },
  { crop: "cannabis", typeId: "cc:cannabis_plant", growth: 0 }]);
w2.markers[0].isValid = false;
Math.random = () => 0;
T.growPlants();
Math.random = real;
// (the fake returns the same world for all 3 dimensions, so a plant can grow up to 3 stages per call here)
ok(w2.blocks.get("0,64,0").growth === 0 && w2.blocks.get("3,64,0").growth >= 1, "invalid markers are skipped; the rest still grow");

console.log(fails ? `\n${fails} FAILURES` : "\nALL GROWTH TESTS PASSED");
