// Planting: a new plant ALWAYS gets the genetics of the seed that was clicked - including rows planted by
// holding right-click (repeat events), which used to fall back to a random common strain (lost user strains).
import { __test as T } from "../main.mjs";
import srv from "@minecraft/server";

let fails = 0;
const ok = (c, m) => { console.log((c ? "PASS " : "FAIL ") + m); if (!c) fails++; };
const H = srv.__handlers;

// a tiny world: markers are entities with a location + dynamic properties
let markers = [];
const near = (m, o, d) => Math.hypot(m.location.x - o.x, m.location.y - o.y, m.location.z - o.z) <= d;
const dimension = {
  id: "minecraft:overworld",
  getEntities: (q) => markers.filter((m) => m.valid && (!q.location || near(m, q.location, q.maxDistance ?? 1e9)))
    .slice(0, q.closest ?? 1e9),
  spawnEntity: (_, location) => {
    const p = {};
    const m = { location, valid: true, get isValid() { return this.valid; }, setDynamicProperty: (k, v) => { p[k] = v; },
      getDynamicProperty: (k) => p[k], remove() { this.valid = false; } };
    markers.push(m);
    return m;
  },
  spawnItem() {}
};
const plantBlock = (x, z) => ({ typeId: "cc:cannabis_plant", location: { x, y: 65, z }, dimension,
  permutation: { getState: () => 0, withState() { return this; } }, setPermutation() {} });
const farmland = (x, z) => ({ typeId: "minecraft:farmland", location: { x, y: 64, z }, dimension });

function makePlayer(stack) {
  const slots = new Array(36).fill(undefined);
  slots[0] = stack;
  return { id: "p" + Math.random(), dimension, selectedSlotIndex: 0, sendMessage() {}, onScreenDisplay: { setActionBar() {} },
    getComponent: () => ({ container: { size: 36, getItem: (i) => slots[i], setItem: (i, s) => { slots[i] = s; } } }), slots };
}
const click = (player, x, z, first) => { for (const h of H["before:playerInteractWithBlock"] ?? [])
  h({ block: farmland(x, z), player, itemStack: player.slots[0], isFirstEvent: first, cancel: false }); };
const place = (player, x, z) => { for (const h of H["after:playerPlaceBlock"] ?? []) h({ block: plantBlock(x, z), dimension, player }); };
const plantedAt = (x, z) => JSON.parse(markers.filter((m) => m.valid && near(m, { x: x + 0.5, y: 65, z: z + 0.5 }, 0.6))[0]
  ?.getDynamicProperty("cc:genetics") ?? "null");

const mine = { ...T.baseGenetics("og_kush"), key: null, name: "Jaiden Special", color: "§d", thc: 33.3, gen: 3 };
const same = (g) => g && g.name === mine.name && g.thc === mine.thc;

// 1. a normal single click
let p = makePlayer(T.makeSeedItem(mine, 5));
click(p, 0, 0, true); place(p, 0, 0);
ok(same(plantedAt(0, 0)), "a clicked seed plants its own strain");

// 2. holding right-click across a row: the next plants come from REPEAT events (isFirstEvent false)
for (let x = 1; x <= 4; x++) { click(p, x, 0, false); place(p, x, 0); }
ok([1, 2, 3, 4].every((x) => same(plantedAt(x, 0))), "a row planted by holding right-click keeps the strain on every plant");

// 3. no click recorded at all: use what's still in hand
markers = [];
p = makePlayer(T.makeSeedItem(mine, 3));
place(p, 0, 0);
ok(same(plantedAt(0, 0)), "if the click was missed, the seed still in hand decides");

// 4. last seed of the stack planted and the click was missed: the player's last clicked seed
p = makePlayer(T.makeSeedItem(mine, 1));
click(p, 5, 5, true);
p.slots[0] = undefined; // placed the last seed
place(p, 6, 6);
ok(same(plantedAt(6, 6)), "planting the last seed falls back to the player's last clicked seed, not a random strain");

// 5. a trampled plant's leftover marker can't leak into the new plant
markers = [];
const old = dimension.spawnEntity("cc:genetics_marker", { x: 9.5, y: 65, z: 9.5 });
old.setDynamicProperty("cc:genetics", JSON.stringify(T.baseGenetics("sour_diesel")));
p = makePlayer(T.makeSeedItem(mine, 2));
click(p, 9, 9, true); place(p, 9, 9);
ok(!old.valid && same(plantedAt(9, 9)) && markers.filter((m) => m.valid).length === 1,
  "an old leftover marker is cleared when a new plant goes in");

// 6. two neighbours of different strains keep their own genetics
markers = [];
const other = T.rollStrain("blue_dream");
const a = makePlayer(T.makeSeedItem(mine, 2)), b = makePlayer(T.makeSeedItem(other, 2));
click(a, 0, 0, true); click(b, 1, 0, true); place(b, 1, 0); place(a, 0, 0);
ok(same(plantedAt(0, 0)) && plantedAt(1, 0)?.key === "blue_dream", "neighbouring plants keep their own strains");

console.log(fails ? `\n${fails} FAILURES` : "\nALL PLANTING TESTS PASSED");
