// Phase 5: Funguy trader - exclusive strains, village residents, wanderers.
import { __test as T } from "../main.mjs";
import srv from "@minecraft/server";

let fails = 0;
const ok = (c, m) => { console.log((c ? "PASS " : "FAIL ") + m); if (!c) fails++; };
const realRandom = Math.random;
const withRandom = (v, fn) => { Math.random = () => v; try { return fn(); } finally { Math.random = realRandom; } };

// ---- exclusive strains ------------------------------------------------------
const EXCL = ["phantom_cookies", "poseidon_og", "hero_haze"];
const uniqueEffect = { phantom_cookies: "invisibility", poseidon_og: "conduit_power", hero_haze: "village_hero" };
for (const k of EXCL) {
  const s = T.STRAINS[k];
  ok(s && s.rarity === "funguy", `${k} exists as a Funguy-only strain`);
  ok(!T.COMMON_KEYS.includes(k), `${k} can't be crafted or found in grass`);
  ok(!T.BREED_RECIPES.some((r) => r[2] === k), `${k} can't be bred`);
  const eff = uniqueEffect[k];
  const others = Object.entries(T.STRAINS).filter(([key, v]) => key !== k && v.effects.some(([id]) => id === eff));
  ok(others.length === 0, `${eff} is unique to ${k}`);
  ok(T.EFFECT_NAMES[eff], `${eff} has a display name for lore`);
  const seed = T.makeSeedItem(T.baseGenetics(k), 1);
  ok(seed.typeId === `cc:seed_${k}`, `${k} seeds use their own item (the trade table sells it; it's rolled on pickup)`);
  ok(T.getGenetics(seed)?.key === k, `a traded ${k} seed resolves to its genetics`);
}
// Breeding with an exclusive passes its effect on to the hybrid.
const cross = withRandom(0.99, () => T.crossGenetics(T.baseGenetics("hero_haze"), T.baseGenetics("og_kush")));
ok(cross.child.effects.some(([id]) => id === "village_hero"), "a Hero Haze hybrid inherits Hero of the Village");

// ---- fake world bits ---------------------------------------------------------
function makeDim({ villagers = [], ground = "minecraft:grass_block" } = {}) {
  const spawned = [];
  return {
    id: "minecraft:overworld",
    spawned,
    getEntities(q) {
      if (q.type === "minecraft:villager_v2") return villagers;
      if (q.type === "cc:funguy") return spawned.filter((e) => !q.tags || q.tags.every((t) => e.tags.includes(t)));
      return [];
    },
    getTopmostBlock: ({ x, z }) => ({ typeId: ground, location: { x, y: 64, z } }),
    spawnEntity(id, loc) {
      const e = { typeId: id, location: loc, tags: [], events: [], props: {},
        triggerEvent(ev) { this.events.push(ev); }, addTag(t) { this.tags.push(t); },
        setDynamicProperty(k, v) { this.props[k] = v; }, getDynamicProperty(k) { return this.props[k]; } };
      spawned.push(e);
      return e;
    },
    spawnParticle() {}
  };
}
const msgs = [];
const makePlayer = (dim, loc = { x: 0, y: 64, z: 0 }) => ({ dimension: dim, location: loc, sendMessage: (m) => msgs.push(m) });
const villagersAt = (x, z, n = 4) => Array.from({ length: n }, (_, i) => ({ location: { x: x + i, y: 64, z: z - i } }));

// ---- village residents --------------------------------------------------------
T.writeFunguyVillages([]);
let dim = makeDim({ villagers: villagersAt(100, 100) });
withRandom(0.1, () => T.checkFunguyVillages([makePlayer(dim, { x: 100, y: 64, z: 100 })]));
ok(dim.spawned.length === 1 && dim.spawned[0].tags.includes("cc_resident"), "a player near a new village spawns a resident Funguy");
ok(dim.spawned[0].events.length === 0, "residents keep the default (resident) setup - no wanderer event");
ok(typeof dim.spawned[0].props["cc:village"] === "string", "the resident remembers his village");
ok(T.readFunguyVillages().length === 1, "the village is recorded");

withRandom(0.1, () => T.checkFunguyVillages([makePlayer(dim, { x: 100, y: 64, z: 100 })]));
ok(dim.spawned.length === 1, "the same village never gets a second Funguy");

let dim2 = makeDim({ villagers: villagersAt(500, 500) });
withRandom(0.9, () => T.checkFunguyVillages([makePlayer(dim2, { x: 500, y: 64, z: 500 })]));
ok(dim2.spawned.length === 0 && T.readFunguyVillages().length === 2, "a village that rolls no Funguy is still recorded (rolled once)");

let dim3 = makeDim({ villagers: villagersAt(900, 900, 2) });
withRandom(0.1, () => T.checkFunguyVillages([makePlayer(dim3, { x: 900, y: 64, z: 900 })]));
ok(dim3.spawned.length === 0 && T.readFunguyVillages().length === 2, "2 villagers isn't a village");

let dim4 = makeDim({ villagers: villagersAt(1300, 1300), ground: "minecraft:water" });
withRandom(0.1, () => T.checkFunguyVillages([makePlayer(dim4, { x: 1300, y: 64, z: 1300 })]));
ok(dim4.spawned.length === 0 && T.readFunguyVillages().length === 2, "no dry ground -> no spawn, village left to try again");

// resident dies -> his village can roll again
const die = srv.__handlers["after:entityDie"]?.[0];
ok(typeof die === "function", "death handler is registered");
die({ deadEntity: dim.spawned[0] });
ok(T.readFunguyVillages().length === 1, "a dead resident frees his village for a new roll");

// ---- wanderers ---------------------------------------------------------------
const wdim = makeDim();
const wp = makePlayer(wdim);
globalThis.__time = 1000;
withRandom(0.0, () => T.checkFunguyWander([wp]));
ok(wdim.spawned.length === 0, "first check only schedules the next visit");
globalThis.__time = 1000 + T.FUNGUY_WANDER_EVERY - 1;
withRandom(0.0, () => T.checkFunguyWander([wp]));
ok(wdim.spawned.length === 0, "no visit before a full in-game day");
globalThis.__time = 1000 + T.FUNGUY_WANDER_EVERY;
withRandom(0.0, () => T.checkFunguyWander([wp]));
const w = wdim.spawned[0];
ok(w && w.events.includes("cc:as_wanderer") && w.tags.includes("cc_wanderer"), "after a day a wanderer can arrive (switched to wanderer mode)");
const d = w && Math.hypot(w.location.x - 0.5, w.location.z - 0.5);
ok(d >= 15 && d <= 29, `he arrives 16-28 blocks away (got ${d?.toFixed(1)})`);
ok(msgs.some((m) => /Funguy/.test(m)), "the player gets a hint he's nearby");

globalThis.__time += T.FUNGUY_WANDER_EVERY;
withRandom(0.0, () => T.checkFunguyWander([wp]));
ok(wdim.spawned.length === 1, "only one wanderer at a time");

const wdim2 = makeDim();
T.writeFunguyVillages([]);
globalThis.__time += T.FUNGUY_WANDER_EVERY;
withRandom(0.99, () => T.checkFunguyWander([makePlayer(wdim2)]));
ok(wdim2.spawned.length === 0, "a failed roll means no visit that day");

// the remembered-village list is capped, forgetting Funguy-less villages first
{
  const big = [];
  for (let i = 0; i < T.FUNGUY_VILLAGE_MAX + 50; i++) big.push({ x: i * 200, z: 0, has: i % 2 === 0 });
  T.writeFunguyVillages(big);
  const saved = T.readFunguyVillages();
  ok(saved.length === T.FUNGUY_VILLAGE_MAX, `village list capped at ${T.FUNGUY_VILLAGE_MAX}`);
  ok(saved.filter((v) => v.has).length === big.filter((v) => v.has).length, "villages that have a Funguy are all kept");
  ok(JSON.stringify(saved).length < 32767, "the saved list stays under the 32,767-character limit");
}

console.log(fails ? `\n${fails} FAILURES` : "\nALL FUNGUY TESTS PASSED");
