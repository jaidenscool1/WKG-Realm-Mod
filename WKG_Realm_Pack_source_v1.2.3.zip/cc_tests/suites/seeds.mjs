// Strain seeds: every newly obtained seed is its own random roll of the strain; only harvesting copies values.
import { __test as T } from "../main.mjs";
import srv from "@minecraft/server";

let fails = 0;
const ok = (c, m) => { console.log((c ? "PASS " : "FAIL ") + m); if (!c) fails++; };
const statKey = (g) => `${g.thc}|${g.yieldStat}|${g.growth}`;

// rolls stay the same strain and within range
for (const [key, s] of Object.entries(T.STRAINS)) {
  let inRange = true;
  for (let i = 0; i < 200; i++) {
    const g = T.rollStrain(key);
    if (g.key !== key || g.name !== s.name || JSON.stringify(g.effects) !== JSON.stringify(s.effects)) inRange = false;
    if (g.thc < s.thc * 0.8 - 0.05 || g.thc > s.thc * 1.2 + 0.05) inRange = false;
    if (Math.abs(g.yieldStat - s.yieldStat) > 1 || g.yieldStat < 1) inRange = false;
    if (g.growth < s.growth * 0.85 - 0.01 || g.growth > s.growth * 1.15 + 0.01) inRange = false;
  }
  ok(inRange, `${key}: rolls keep name + effects, THC ±20%, yield ±1, growth ±15%`);
}
{
  const seen = new Set();
  for (let i = 0; i < 50; i++) seen.add(statKey(T.rollStrain("og_kush")));
  ok(seen.size >= 45, `50 rolled OG Kush seeds are (almost) all different (${seen.size} distinct)`);
}

// a crafted/traded plain seed becomes a rolled seed, still the same strain item
const crafted = new srv.ItemStack("cc:seed_blue_dream", 1);
const rolled = T.describedSeed(crafted);
const rg = T.getGenetics(rolled);
ok(rolled.typeId === "cc:seed_blue_dream", "rolled seed keeps its strain item (icon + coloured name)");
ok(rg.key === "blue_dream" && rolled.getLore().some((l) => l.startsWith("§8#")), "rolled seed carries its own genetics");
ok(rolled.getLore().some((l) => l.includes("Speed")) && rolled.getLore().some((l) => l.includes(`${rg.thc}%`)), "its description shows the rolled THC and the effects");
ok(rolled.getLore().some((l) => /Common strain/.test(l)), "and the strain's rarity line");
ok(T.describedSeed(rolled) === undefined, "an already-rolled seed is left alone");
const twoCrafted = [T.describedSeed(new srv.ItemStack("cc:seed_og_kush", 1)), T.describedSeed(new srv.ItemStack("cc:seed_og_kush", 1))];
ok(statKey(T.getGenetics(twoCrafted[0])) !== statKey(T.getGenetics(twoCrafted[1])) || twoCrafted[0].stackKey() !== twoCrafted[1].stackKey(),
  "two crafted OG Kush seeds come out different");

// seeds described by the previous version (text but no genetics ID) get rolled too
const oldStyle = new srv.ItemStack("cc:seed_og_kush", 3);
oldStyle.setLore(["§7THC: §f22%", "§b• Regeneration I"]);
const migrated = T.describedSeed(oldStyle);
ok(migrated && migrated.amount === 3 && T.getGenetics(migrated).key === "og_kush", "old described seeds are upgraded to rolled seeds");

// harvesting copies the plant's exact values -> those seeds match and stack
const plant = T.rollStrain("hero_haze");
const h1 = T.makeSeedItem(plant, 1), h2 = T.makeSeedItem(plant, 2);
ok(h1.stackKey() === h2.stackKey() && statKey(T.getGenetics(h2)) === statKey(plant), "seeds harvested from one plant are identical (stack)");

// rare discoveries are rolled too
{
  const a = T.rollStrain("blue_dream"), b = T.rollStrain("green_crack");
  const real = Math.random;
  let calls = 0;
  Math.random = () => (calls++ === 0 ? 0 : real()); // first call: force the rare roll
  const { child, rare } = T.crossGenetics(a, b);
  Math.random = real;
  ok(rare === "white_widow" && child.key === "white_widow", "rolled parents can still discover a rare strain");
}

// inventory pass: plain + old-style seeds rolled, hybrids / rolled / other items untouched
const hybrid = T.makeSeedItem({ ...T.baseGenetics("og_kush"), key: null, name: "Og Dream", gen: 1 }, 1);
const slots = new Array(36).fill(undefined);
slots[0] = new srv.ItemStack("cc:seed_hero_haze", 1);
slots[5] = oldStyle;
slots[6] = rolled;
slots[7] = hybrid;
slots[9] = new srv.ItemStack("minecraft:dirt", 64);
const player = { getComponent: () => ({ container: { size: 36, getItem: (i) => slots[i], setItem: (i, s) => { slots[i] = s; } } }) };
ok(T.describePlayerSeeds(player) === 2, "an inventory pass rolls exactly the 2 unrolled strain seeds");
ok(slots[6] === rolled && slots[7] === hybrid && slots[9].typeId === "minecraft:dirt", "rolled seeds, hybrids and other items untouched");
ok(T.describePlayerSeeds(player) === 0, "a second pass changes nothing");

// ---- drop rates (user-tuned 2026-09-28): grass 5%, finished plant always 1-3 seeds ----
{
  const onBreak = srv.__handlers["after:playerBreakBlock"]?.[0];
  const g = T.rollStrain("og_kush");
  let drops = [];
  const marker = { isValid: true, getDynamicProperty: (k) => (k === "cc:genetics" ? JSON.stringify(g) : undefined), remove() {} };
  const dimension = { id: "minecraft:overworld", getEntities: () => [marker], spawnItem: (s) => drops.push(s) };
  const player = { onScreenDisplay: { setActionBar() {} } };
  const breakBlock = (id, growth) => onBreak({ block: { location: { x: 0, y: 64, z: 0 } }, dimension, player,
    brokenBlockPermutation: { type: { id }, getState: () => growth } });
  const N = 4000;
  let withSeeds = 0, sameStrain = true;
  const counts = new Set();
  for (let i = 0; i < N; i++) {
    drops = [];
    breakBlock("cc:cannabis_plant", 4);
    const seeds = drops.filter((s) => s.typeId === "cc:seed_og_kush");
    if (seeds.length) {
      withSeeds++;
      counts.add(seeds[0].amount);
      if (T.getGenetics(seeds[0]).thc !== g.thc) sameStrain = false;
    }
  }
  ok(withSeeds === N, `a finished plant always drops seeds (got ${(100 * withSeeds / N).toFixed(1)}%)`);
  ok(counts.has(1) && counts.has(2) && counts.has(3) && ![...counts].some((c) => c < 1 || c > 3), `1-3 seeds per drop (saw ${[...counts].sort()})`);
  ok(sameStrain, "harvested seeds copy the plant's exact values");
  let grass = 0;
  for (let i = 0; i < N; i++) {
    drops = [];
    breakBlock("minecraft:short_grass", 0);
    if (drops.length) grass++;
  }
  ok(Math.abs(grass / N - 0.05) < 0.015, `grass drops a seed ~5% of the time (got ${(100 * grass / N).toFixed(1)}%)`);
}

console.log(fails ? `\n${fails} FAILURES` : "\nALL SEED TESTS PASSED");
