import { __test as T } from "../main.mjs";
import srv from "@minecraft/server"; import ui from "@minecraft/server-ui";
let fails = 0; const ok = (c, m) => { console.log((c ? "PASS " : "FAIL ") + m); if (!c) fails++; };
const runTimeouts = () => { const q = globalThis.__timeouts || []; globalThis.__timeouts = []; q.forEach(f => f()); };

const state = { "cc:plate": 0, "cc:pressing": false }; const spawned = [];
const block = { typeId: "cc:nug_press", location: { x: 1, y: 64, z: 1 },
  get permutation() { return { getState: (k) => state[k], withState: (k, v) => ({ k, v }) }; },
  setPermutation: (p) => { state[p.k] = p.v; } };
const dim = { id: "minecraft:overworld", getBlock: () => block, spawnItem: (s) => spawned.push(s), playSound() {} };
block.dimension = dim; globalThis.__dim = dim;

const slots = new Array(36).fill(undefined);
const container = { size: 36, getItem: i => slots[i], setItem: (i, s) => { slots[i] = s; },
  addItem: s => { slots[slots.findIndex(x => x === undefined)] = s; } };
const msgs = [];
const p = { id: "p", isValid: true, selectedSlotIndex: 0, getComponent: () => ({ container }), sendMessage: m => msgs.push(m),
  onScreenDisplay: { setActionBar: m => msgs.push(m) }, dimension: dim, location: {} };
const loc = { x: 1, y: 64, z: 1 }, D = "minecraft:overworld";
const count = (id) => slots.filter(s => s && s.typeId === id).reduce((n, s) => n + s.amount, 0);

// plate install / upgrade / remove
T.swapPressPlate(p, D, loc);
ok(state["cc:plate"] === 0 && /install/.test(msgs.at(-1)), "empty hand on empty press: hint shown");
slots[0] = new srv.ItemStack("cc:press_plate_copper", 1);
T.swapPressPlate(p, D, loc);
ok(state["cc:plate"] === 1 && slots[0] === undefined, "copper plate installed from hand");
slots[0] = new srv.ItemStack("cc:press_plate_diamond", 1);
T.swapPressPlate(p, D, loc);
ok(state["cc:plate"] === 3 && count("cc:press_plate_copper") === 1, "diamond swapped in, copper returned");
slots[0] = undefined;
T.swapPressPlate(p, D, loc);
ok(state["cc:plate"] === 0 && count("cc:press_plate_diamond") === 1, "empty-hand sneak-hit removes plate");

// no plate -> menu offers no press button
ui.__queue({ canceled: false, selection: 0 });
await T.openPress(p, D, loc);
ok(!globalThis.__lastButtons.includes("Press buds"), "no 'Press buds' option without a plate");

// install netherite, press 10 dried Skywalker OG
slots[0] = new srv.ItemStack("cc:press_plate_netherite", 1); T.swapPressPlate(p, D, loc);
slots[5] = T.makeBudItem(T.baseGenetics("skywalker_og"), 10, true);
ui.__queue({ canceled: false, selection: 0 }, { canceled: false, formValues: [0, 10] });
await T.openPress(p, D, loc);
ok(slots[5] === undefined && state["cc:pressing"] === true, "buds consumed and press lowers while working");
ui.__queue({ canceled: false, selection: 0 });
await T.openPress(p, D, loc);
ok(/already working/.test(msgs.at(-1)), "can't start a second press mid-press");
T.swapPressPlate(p, D, loc);
ok(state["cc:plate"] === 4, "can't pull the plate mid-press");
runTimeouts();
ok(state["cc:pressing"] === false, "press raises again when done");
const r = spawned.at(-1);
ok(r && r.typeId === "cc:rosin" && r.amount === 7, `10 buds x 70% = 7 rosin (got ${r && r.amount})`);
ok(T.getGenetics(r).name === "Skywalker OG" && T.isDried(r), "rosin keeps genetics and 'pressed from dried'");
ok(T.getGenetics(r).thc === 72, `dried Skywalker OG (26%) on netherite -> 72% THC rosin (got ${T.getGenetics(r).thc})`);

// menu body shows percent signs (escaped as %% for the form)
ui.__queue({ canceled: true });
await T.openPress(p, D, loc);
ok(/70%%/.test(globalThis.__lastBody) && /Copper 20%%/.test(globalThis.__lastBody), "press menu escapes % so it shows in-game");

// limits: min 4, max 32
ok(T.PRESS_MIN_BUDS === 4 && T.PRESS_MAX_BUDS === 32, "press takes 4-32 buds");
slots[7] = T.makeBudItem(T.baseGenetics("og_kush"), 3);
msgs.length = 0;
ui.__queue({ canceled: false, selection: 0 });
await T.openPress(p, D, loc);
ok(/at least 4/.test(msgs.at(-1)) && slots[7].amount === 3, "3 buds is not enough to press");
slots[8] = T.makeBudItem(T.baseGenetics("og_kush"), 3);
spawned.length = 0;
ui.__queue({ canceled: false, selection: 0 }, { canceled: false, formValues: [0, 6] });
await T.openPress(p, D, loc); runTimeouts();
ok(slots[7] === undefined && slots[8] === undefined, "two stacks of 3 combine into one press of 6");
slots[9] = T.makeBudItem(T.baseGenetics("og_kush"), 64);
ui.__queue({ canceled: false, selection: 0 }, { canceled: false, formValues: [0, 40] });
await T.openPress(p, D, loc); runTimeouts();
ok(slots[9] && slots[9].amount === 32, "never presses more than 32 at once");
slots[9] = undefined;

// yield rates per tier over many presses
for (const [id, plate] of Object.entries(T.PRESS_PLATES)) {
  let total = 0; const N = 200;
  for (let i = 0; i < N; i++) {
    state["cc:plate"] = plate.tier; spawned.length = 0;
    slots[6] = T.makeBudItem(T.baseGenetics("og_kush"), 10);
    ui.__queue({ canceled: false, selection: 0 }, { canceled: false, formValues: [0, 10] });
    await T.openPress(p, D, loc); runTimeouts();
    total += spawned.reduce((n, s) => n + s.amount, 0);
  }
  const avg = total / N / 10;
  ok(Math.abs(avg - plate.rate) < 0.05, `${plate.name} averages ${(avg * 100).toFixed(0)}% (target ${plate.rate * 100}%)`);
}
console.log(fails ? `\n${fails} FAILURES` : "\nALL PRESS TESTS PASSED");
