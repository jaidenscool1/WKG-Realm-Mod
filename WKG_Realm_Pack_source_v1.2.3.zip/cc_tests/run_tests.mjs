// Runs the Cannabis Craft logic tests against the real cc_main.js, using fake
// @minecraft/server + server-ui modules (see node_modules/@minecraft).
// Usage (from com.mojang):  node cc_tests/run_tests.mjs [path/to/cc_main.js]
import { readFileSync, writeFileSync, readdirSync, existsSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";

const here = dirname(fileURLToPath(import.meta.url));
let src = process.argv.slice(2).find((a) => !a.startsWith("-"));
if (!src) {
  const packs = join(here, "..", "development_behavior_packs");
  const hit = existsSync(packs) && readdirSync(packs).map((d) => join(packs, d, "scripts", "cc_main.js")).find(existsSync);
  src = hit;
}
if (!src || !existsSync(src)) {
  console.error("Couldn't find cc_main.js - pass its path: node cc_tests/run_tests.mjs <path>");
  process.exit(1);
}

// Copy the script and export its internals so the suites can call them directly.
const exportsLine = `
export const __test = { getGenetics, makeBudItem, makeSeedItem, baseGenetics, crossGenetics, registerGenetics,
  handleBreeding, handleRolling, takeHit, isDried, STRAINS, COMMON_KEYS, openRack, rackKey, loadRack, dropRackContents,
  swapPressPlate, openPress, PRESS_PLATES, PRESS_MIN_BUDS, PRESS_MAX_BUDS, applyEffects, thcDurationMult, rosinThc,
  openDistiller, stillKey, loadStill, dropStillContents, DISTILL_PROCESSES, concentrateGenetics, makeConcentrateItem,
  makeRosinItem, makeCartItem, readCart, watchCarts, BREED_RECIPES, EFFECT_NAMES, checkFunguyVillages, checkFunguyWander,
  findFunguySpot, readFunguyVillages, writeFunguyVillages, FUNGUY_WANDER_EVERY, onSneakSample, offhandHit, SMOKE_FAMILIES, tickOffhandHolds, FUNGUY_VILLAGE_MAX, rollStrain, describedSeed, describePlayerSeeds, strainName, NAME_COLORS, NAME_COLOR_CHOICES,
  RAINBOW, growPlants, tintFor, mergeEffects, makeGuideBook, tradeBookForGuide, buildGuidePages, packCigarettes, addToRack, TOBACCO_BATCH, revertLitPacks };
`;
// Helper modules next to cc_main.js (cc_guide.js, cc_glyphs.js, ...) are copied as .mjs, imports rewritten.
const toMjs = (code) => code.replace(/from "\.\/(cc_\w+)\.js"/g, 'from "./$1.mjs"');
for (const f of readdirSync(dirname(src)).filter((f) => /^cc_\w+\.js$/.test(f) && f !== "cc_main.js")) {
  writeFileSync(join(here, f.replace(/\.js$/, ".mjs")), toMjs(readFileSync(join(dirname(src), f), "utf8")));
}
writeFileSync(join(here, "main.mjs"), toMjs(readFileSync(src, "utf8")) + exportsLine);
console.log(`Testing ${src}\n`);

let failed = 0;
for (const suite of readdirSync(join(here, "suites")).filter((f) => f.endsWith(".mjs")).sort()) {
  const r = spawnSync(process.execPath, [join(here, "suites", suite)], { cwd: here, encoding: "utf8" });
  const out = (r.stdout || "") + (r.stderr || "");
  const bad = r.status !== 0 || /FAIL|THREW|Error/.test(out);
  if (bad) failed++;
  console.log(`=== ${suite}: ${bad ? "FAILED" : "ok"}`);
  if (bad || process.argv.includes("-v")) console.log(out);
}
console.log(failed ? `\n${failed} suite(s) failed` : "\nAll suites passed");
process.exit(failed ? 1 : 0);
