"""Funguy model + texture: villager-shaped, amanita mushroom cap, tie-dye robe.
Writes models/entity/cc_funguy.geo.json and textures/entity/cc_funguy.png (128x64, box UV).
Run: python cc_tools/gen_funguy.py [preview.png]"""
import json, math, os, random, sys
from PIL import Image

RP = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "development_resource_packs", "WKG_Realm_Pack_RP")
TW, TH = 128, 64
random.seed(3)

# name, parent, pivot, cubes [(origin, size, uv, inflate)]
BONES = [
    ("body", None, [0, 24, 0], [([-4, 12, -3], [8, 12, 6], [16, 20], 0), ([-4, 6, -3], [8, 18, 6], [0, 38], 0.5)]),
    ("head", "body", [0, 24, 0], [([-4, 24, -4], [8, 10, 8], [0, 0], 0)]),
    ("nose", "head", [0, 26, 0], [([-1, 23, -6], [2, 4, 2], [24, 0], 0)]),
    # cap sits down over the forehead (brim just above the brow), like a villager's hat
    ("cap", "head", [0, 30, 0], [([-6, 30, -6], [12, 3, 12], [64, 0], 0), ([-4, 33, -4], [8, 2, 8], [64, 16], 0)]),
    ("arms", "body", [0, 22, 0], [([-4, 16, -2], [8, 4, 4], [40, 38], 0), ([-8, 16, -2], [4, 8, 4], [44, 22], 0),
                                   ([4, 16, -2], [4, 8, 4], [44, 22], 0)]),
    ("leg0", None, [-2, 12, 0], [([-4, 0, -2], [4, 12, 4], [0, 22], 0)]),
    ("leg1", None, [2, 12, 0], [([0, 0, -2], [4, 12, 4], [0, 22], 0)]),
]

SKIN = (167, 98, 90)       # villager skin, sampled from the user's screenshot
SKIN_DARK = (136, 79, 66)
HAIR = (62, 42, 30)
PANTS = (92, 62, 42)
SHOES = (54, 38, 28)
CAP_RED = (196, 38, 34)
CAP_DARK = (150, 26, 24)
SPOT = (242, 240, 228)
GILL = (228, 212, 178)
GILL_LINE = (196, 178, 142)
DYE = [(128, 58, 168), (196, 70, 150), (232, 142, 52), (150, 198, 62), (40, 158, 170)]

img = Image.new("RGBA", (TW, TH), (0, 0, 0, 0))
px = img.load()


def faces(u, v, w, h, d):
    """Box-UV face rectangles: name -> (x0, y0, width, height)."""
    return {
        "up": (u + d, v, w, d), "down": (u + d + w, v, w, d),
        "east": (u, v + d, d, h), "north": (u + d, v + d, w, h),
        "west": (u + d + w, v + d, d, h), "south": (u + 2 * d + w, v + d, w, h),
    }


def paint(u, v, size, fn):
    w, h, d = size
    for face, (x0, y0, fw, fh) in faces(u, v, w, h, d).items():
        for y in range(fh):
            for x in range(fw):
                c = fn(face, x, y, fw, fh)
                if c:
                    px[x0 + x, y0 + y] = tuple(c) + (255,)


def jitter(c, amt=8):
    return [max(0, min(255, ch + random.randint(-amt, amt))) for ch in c]


def tie_dye(face, x, y, fw, fh, cx=None, cy=None):
    cx = fw / 2 if cx is None else cx
    cy = fh / 2 if cy is None else cy
    a = math.atan2(y - cy, x - cx) / (2 * math.pi)
    r = math.hypot(x - cx, y - cy)
    band = int(((a + r * 0.09 + (0.37 if face in ("south", "east") else 0)) % 1) * len(DYE))
    return jitter(DYE[band], 5)


# Face copied texel-by-texel from the user's in-game screenshot of a vanilla villager
# (sampled at each texel centre, then brightened 10% to undo the in-game lighting).
# Rows 0-4 were under that villager's hat, so they're plain forehead skin.
FACE_COLORS = {
    "s": (167, 98, 90),    # skin
    "S": (172, 103, 103),  # skin, pinker
    "L": (177, 108, 100),  # skin, lighter
    "d": (136, 79, 66),    # darker skin (sides, behind the nose)
    "c": (114, 57, 54),    # cheek spots
    "b": (55, 36, 24),     # unibrow
    "w": (239, 195, 222),  # eye whites
    "g": (12, 117, 24),    # eyes
}
FACE = [
    "SLLLLLLS",
    "SLLLLLLS",
    "SLLLLLLS",
    "SLLLLLLS",
    "SLLLLLLS",
    "SbbbbbbS",
    "Lwgssgwl",
    "dsSddLsd",
    "dscddcsd",
    "dssddssd",
]
FACE_COLORS["l"] = FACE_COLORS["L"]
SKIN_LIGHT = FACE_COLORS["L"]
# The nose cube (origin y23, 4 tall) starts right under the eye row (row 6), as in the screenshot.


def head(face, x, y, fw, fh):
    if face == "north":
        return FACE_COLORS[FACE[y][x]]
    if face == "up":
        return jitter(SKIN_LIGHT, 3)
    if face == "down":
        return SKIN_DARK
    # back and sides: plain skin, darker toward the chin like the face
    return jitter(SKIN_DARK if y >= 7 else SKIN, 3)


NOSE = (136, 79, 66)  # sampled from the same screenshot
NOSE_TIP = (118, 68, 56)


def nose(face, x, y, fw, fh):
    if face == "down":
        return NOSE_TIP
    return NOSE


# White amanita spots: 2x2 on the cap top, and a row of spots around the rim.
TOP_SPOTS = [(1, 1), (6, 0), (9, 3), (3, 5), (0, 8), (7, 7), (10, 9), (4, 10)]
SIDE_SPOTS = {"north": [1, 5, 9], "east": [2, 7], "west": [3, 8], "south": [0, 4, 9]}


def cap(face, x, y, fw, fh):
    if face == "down":
        return GILL_LINE if (x + y) % 3 == 0 else GILL
    if face == "up":
        if any(sx <= x <= sx + 1 and sy <= y <= sy + 1 for sx, sy in TOP_SPOTS):
            return jitter(SPOT, 4)
        return jitter(CAP_RED, 6)
    if y == fh - 1:
        return jitter(CAP_DARK, 5)
    if y <= 1 and any(sx <= x <= sx + 1 for sx in SIDE_SPOTS[face]):
        return jitter(SPOT, 4)
    return jitter(CAP_RED, 6)


def cap_top(face, x, y, fw, fh):
    if face == "up" and any(sx <= x <= sx + 1 and sy <= y <= sy + 1 for sx, sy in [(1, 1), (5, 2), (2, 5)]):
        return jitter(SPOT, 3)
    if face in ("north", "east", "west", "south") and y == 0 and x in (1, 5):
        return jitter(SPOT, 3)
    return jitter(CAP_RED, 6)


def robe(face, x, y, fw, fh):
    if face in ("north", "south", "east", "west") and y >= fh - 1:
        return (70, 36, 96)  # dark hem
    if face == "north" and y == 6:
        return (84, 58, 34)  # belt
    return tie_dye(face, x, y, fw, fh, cy=fh * 0.35)


def sleeve(face, x, y, fw, fh):
    return tie_dye(face, x, y, fw, fh)


def arm_bar(face, x, y, fw, fh):
    if face == "north" and 2 <= x <= 5:
        return jitter(SKIN, 4)  # folded hands
    return tie_dye(face, x, y, fw, fh)


def leg(face, x, y, fw, fh):
    if face in ("north", "south", "east", "west") and y >= fh - 2:
        return jitter(SHOES, 4)
    if face == "down":
        return SHOES
    return jitter(PANTS, 5)


PAINTERS = {(0, 0): head, (24, 0): nose, (64, 0): cap, (64, 16): cap_top, (16, 20): robe, (0, 38): robe,
            (44, 22): sleeve, (40, 38): arm_bar, (0, 22): leg}


def geometry():
    bones = []
    for name, parent, pivot, cubes in BONES:
        b = {"name": name, "pivot": pivot, "cubes": []}
        if parent:
            b["parent"] = parent
        for origin, size, uv, inflate in cubes:
            c = {"origin": origin, "size": size, "uv": uv}
            if inflate:
                c["inflate"] = inflate
            if name == "arms" and origin[0] == 4:
                c["mirror"] = True
            if name == "leg1":
                c["mirror"] = True
            b["cubes"].append(c)
        bones.append(b)
    return {"format_version": "1.12.0", "minecraft:geometry": [{
        "description": {"identifier": "geometry.cc.funguy", "texture_width": TW, "texture_height": TH,
                        "visible_bounds_width": 2, "visible_bounds_height": 3, "visible_bounds_offset": [0, 1.5, 0]},
        "bones": bones}]}


def preview(path):
    S = 10
    sheet = Image.new("RGBA", (600, 460), (120, 120, 128, 255))
    sheet.alpha_composite(img.resize((TW * 3, TH * 3), Image.NEAREST), (10, 10))
    # front view (north faces), arms folded shown in front of the robe
    fx, fy = 470, 440
    order = [("leg0", 0), ("leg1", 0), ("body", 1), ("head", 0), ("cap", 0), ("cap", 1), ("arms", 1), ("arms", 2),
             ("arms", 0), ("nose", 0)]
    bone = {b[0]: b for b in BONES}
    for name, i in order:
        origin, size, uv, inflate = bone[name][3][i]
        w, h, d = size
        x0, y0, fw, fh = faces(uv[0], uv[1], w, h, d)["north"]
        face = img.crop((x0, y0, x0 + fw, y0 + fh)).resize((int((w + 2 * inflate) * S), int((h + 2 * inflate) * S)), Image.NEAREST)
        oy = origin[1] - (6 if name == "arms" else 0)  # folded arms sit a bit lower once rotated
        sheet.alpha_composite(face, (int(fx + (origin[0] - inflate) * S), int(fy - (oy + h + inflate) * S)))
    sheet.save(path)


def main():
    for (u, v), fn in PAINTERS.items():
        for _name, _p, _pv, cubes in BONES:
            for origin, size, uv, _inf in cubes:
                if tuple(uv) == (u, v):
                    paint(u, v, size, fn)
                    break
            else:
                continue
            break
    os.makedirs(os.path.join(RP, "textures", "entity"), exist_ok=True)
    img.save(os.path.join(RP, "textures", "entity", "cc_funguy.png"))
    with open(os.path.join(RP, "models", "entity", "cc_funguy.geo.json"), "w", encoding="utf-8") as f:
        json.dump(geometry(), f, indent=2)
        f.write("\n")
    if len(sys.argv) > 1:
        preview(sys.argv[1])
    print("wrote cc_funguy geometry + texture")


if __name__ == "__main__":
    main()
