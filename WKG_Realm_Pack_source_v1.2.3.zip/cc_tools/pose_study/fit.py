"""Fit the hand->camera transform + rotation conventions to the three bong screenshots."""
import itertools, json, sys, time
import numpy as np
from scipy import ndimage, optimize
from bongrender import Conv, label_image

NEW = sys.argv[1]
S = 0.25
HIT = (0.75, 19.75, -0.5)
# (screenshot, pose). 12/13 are from the older single-bone bong: rest [15,-90,0]; hit [55,-75,-8] + hit shift
SHOTS = [("17", dict(lean=0)), ("16", dict(lean=15)), ("18", dict(lean=30)),
         ("12", dict(lean=15)), ("13", dict(lean=55, spin=-75, inner_roll=-8, pos=HIT)),
         ("19", dict(lean=30)), ("20", dict(lean=30, tip=-40, pos=HIT))]  # current two-bone bong: hold, right-click


def load(n):
    glass, bowl = np.load(f"{NEW}/mask_{n}.npy")
    lab, k = ndimage.label(glass | bowl)
    sizes = ndimage.sum(np.ones_like(lab), lab, range(1, k + 1))
    keep = lab == (1 + int(np.argmax(sizes)))          # the bong only
    bowl = bowl & ndimage.binary_dilation(keep, iterations=3)
    small = lambda m: np.asarray(
        __import__("PIL.Image", fromlist=["Image"]).fromarray((m * 255).astype(np.uint8)).resize((480, 270))) > 127
    return small(keep | bowl), small(bowl)


REAL = [load(n) for n, _ in SHOTS]
IGNORE = np.zeros((270, 480), bool); IGNORE[int(945 * S):int(1040 * S), int(595 * S):int(1325 * S)] = True  # hotbar


def loss(params, conv):
    total = 0.0
    for (n, pose), (all_r, bowl_r) in zip(SHOTS, REAL):
        lab = label_image(params, conv, scale_px=S, **pose)
        a, b = (lab > 0) & ~IGNORE, (lab == 2) & ~IGNORE
        ar, br = all_r & ~IGNORE, bowl_r & ~IGNORE
        iou = (a & ar).sum() / max(1, (a | ar).sum())
        ioub = (b & br).sum() / max(1, (b | br).sum())
        total += (1 - iou) + 0.6 * (1 - ioub)
    return total


BOUNDS = [(-60, 60), (-60, 60), (120, 240), (-10, 40), (-10, 40), (-70, -8), (400, 2500)]  # around the held-item frame prior
results = []
t0 = time.time()
for sx, sy, sz, order, mirror in itertools.product((1, -1), (1, -1), (1, -1), ("xyz", "zyx"), (False, True)):
    conv = Conv(sx, sy, sz, order, mirror)
    r = optimize.differential_evolution(loss, BOUNDS, args=(conv,), popsize=10, maxiter=45, tol=1e-4,
                                        seed=1, polish=False, updating="deferred", workers=1)
    results.append((r.fun, conv, r.x))
    print(f"{r.fun:.3f}  {conv}  t={time.time()-t0:.0f}s", flush=True)

results.sort(key=lambda x: x[0])
best = []
for fun, conv, x in results[:4]:  # refine the best few
    r = optimize.minimize(loss, x, args=(conv,), method="Nelder-Mead", options={"maxiter": 1500, "xatol": 0.05, "fatol": 1e-4})
    best.append((r.fun, conv, r.x))
    print("refined", round(r.fun, 3), conv, np.round(r.x, 2).tolist(), flush=True)
best.sort(key=lambda x: x[0])
fun, conv, x = best[0]
json.dump({"loss": fun, "signs": conv.s, "order": conv.order, "mirror": conv.mirror, "params": list(map(float, x)),
           "runners_up": [{"loss": b[0], "conv": repr(b[1]), "params": list(map(float, b[2]))} for b in best[1:]]},
          open(f"{NEW}/calib.json", "w"), indent=2)
print("BEST", fun, conv, np.round(x, 2).tolist())
