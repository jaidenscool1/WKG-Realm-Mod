"""Deeper fit of the camera for the winning convention (and the runner-up, to compare)."""
import json, sys, time
import numpy as np
from scipy import optimize

NEW = sys.argv[1]
sys.argv = ["x", NEW]
exec(open("fit.py", encoding="utf-8").read().split("BOUNDS = ")[0])
from bongrender import Conv


def loss2(params, conv):
    # shape matters most; the bowl only as a tie-breaker for which way it faces
    total = 0.0
    for (n, pose), (all_r, bowl_r) in zip(SHOTS, REAL):
        lab = label_image(params, conv, scale_px=S, **pose)
        a, b = (lab > 0) & ~IGNORE, (lab == 2) & ~IGNORE
        ar, br_ = all_r & ~IGNORE, bowl_r & ~IGNORE
        total += (1 - (a & ar).sum() / max(1, (a | ar).sum())) + 0.25 * (1 - (b & br_).sum() / max(1, (b | br_).sum()))
    return total


BOUNDS = [(-70, 70), (-70, 90), (130, 280), (-15, 45), (-15, 40), (-80, -6), (250, 3000)]
out = {}
for signs, order, mirror in [((-1, 1, -1), "xyz", False)]:  # the convention that won with 5 shots
    conv = Conv(*signs, order, mirror)
    t0 = time.time()
    r = optimize.differential_evolution(loss2, BOUNDS, args=(conv,), popsize=20, maxiter=110, tol=1e-6, seed=3,
                                        polish=False, updating="deferred", mutation=(0.5, 1.0), recombination=0.8)
    best = (r.fun, r.x)
    for k in range(6):  # local polish from jittered starts
        x0 = best[1] + np.random.default_rng(k).normal(0, [3, 3, 3, 1, 1, 2, 60])
        rr = optimize.minimize(loss2, x0, args=(conv,), method="Nelder-Mead", options={"maxiter": 2500, "xatol": 0.02, "fatol": 1e-5})
        if rr.fun < best[0]: best = (rr.fun, rr.x)
    out[repr(conv)] = {"loss": float(best[0]), "signs": signs, "order": order, "mirror": mirror, "params": list(map(float, best[1]))}
    print(round(best[0], 3), conv, np.round(best[1], 2).tolist(), f"{time.time()-t0:.0f}s", flush=True)

win = min(out.values(), key=lambda v: v["loss"])
json.dump(win, open(f"{NEW}/calib.json", "w"), indent=2)
json.dump(out, open(f"{NEW}/calib_all.json", "w"), indent=2)
print("WIN", win)
