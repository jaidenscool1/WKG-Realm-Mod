"""Bong pose study sheets, rendered with the calibrated renderer."""
import json, math, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import bongrender as br
from texrender import render, clean_background

OLD, NEW = sys.argv[1], sys.argv[2]
cal = json.load(open(f"{NEW}/calib.json"))
conv = br.Conv(*cal["signs"], cal["order"], cal["mirror"])
P = cal["params"]
BG = clean_background(f"{OLD}/images/18.webp", f"{NEW}/mask_18.npy").convert("RGBA")
BG13 = clean_background(f"{OLD}/images/13.webp", f"{NEW}/mask_13.npy").convert("RGBA")
FB = lambda n: ImageFont.truetype("C:/Windows/Fonts/arialbd.ttf", n)
FR = lambda n: ImageFont.truetype("C:/Windows/Fonts/arial.ttf", n)
RED, GREEN, BLUE, GOLD = (255, 90, 90), (90, 230, 110), (100, 180, 255), (255, 215, 90)
CROP = (930, 300, 1920, 1040)  # region of the screen the bong lives in
PW = 380; PH = int(PW * (CROP[3] - CROP[1]) / (CROP[2] - CROP[0]))
NOW = dict(lean=30, spin=-90, tip=0.0, pos=(0, 19, 0))
HIT_POS = (0.75, 19.75, -0.5)


def panel(pose, bg=BG):
    frame = Image.alpha_composite(bg, render(P, conv, **pose))
    hotbar = (595, 945, 1325, 1040)  # the game draws the hotbar over held items
    frame.paste(bg.crop(hotbar), hotbar[:2])
    return frame.crop(CROP).resize((PW, PH), Image.LANCZOS).convert("RGB")


def neck_angle(pose):
    """Screen angle of the neck (degrees from vertical, + = top to the right)."""
    faces, f = br.transform_faces(P, conv, **pose)
    neck = [F for F in faces if F[0] == 4]  # cube 4 = neck
    pts = np.vstack([F[2] for F in neck])
    ys = [c for c in range(3)]
    # neck axis: centre of its top (rim end) vs bottom (shoulder end) in model space -> use cube corners
    c = br.CUBES[4]; o = np.array(c["origin"]); s = np.array(c["size"])
    a = o + s * np.array([0.5, 0.0, 0.5]); b = o + s * np.array([0.5, 1.0, 0.5])
    def to_screen(v):
        Rb = conv.euler((pose["lean"], pose["spin"], 0)); Rr = conv.euler((pose.get("tip", 0), 0, 0))
        M, t, f = br.hand_to_camera(P, conv)
        p = ((v @ Rb.T) @ Rr.T + np.array(pose.get("pos", (0, 19, 0)))) @ M.T + t
        return br.project(p[None], f)[0]
    A, B = to_screen(a), to_screen(b)
    top, bot = (A, B) if A[1] < B[1] else (B, A)
    return math.degrees(math.atan2(top[0] - bot[0], bot[1] - top[1]))


def sheet(title, subtitle, rows, path):
    lab_w, gap, head = 250, 10, 120
    ncol = max(len(r[2]) for r in rows)
    W = lab_w + ncol * (PW + gap) + 20
    Hh = head + len(rows) * (PH + 50) + 30
    im = Image.new("RGB", (W, Hh), (24, 24, 28)); d = ImageDraw.Draw(im)
    d.text((20, 18), title, font=FB(40), fill=(255, 255, 255))
    d.text((20, 70), subtitle, font=FR(24), fill=(200, 200, 200))
    y = head
    for name, col, items in rows:
        d.text((20, y + PH // 2 - 40), name[0], font=FB(28), fill=col)
        for k, line in enumerate(name[1:]):
            d.text((20, y + PH // 2 + 4 + k * 28), line, font=FR(22), fill=(210, 210, 210))
        for i, (code, text, pose, is_now) in enumerate(items):
            x = lab_w + i * (PW + gap)
            im.paste(panel(pose), (x, y))
            if is_now:
                d.rectangle([x - 4, y - 4, x + PW + 3, y + PH + 3], outline=GOLD, width=5)
            d.rectangle([x, y, x + 70, y + 40], fill=(0, 0, 0))
            d.text((x + 8, y + 4), code, font=FB(30), fill=col)
            d.text((x, y + PH + 8), text + ("   (NOW)" if is_now else ""), font=FB(22), fill=GOLD if is_now else (235, 235, 235))
        y += PH + 50
    im.save(path)
    return im


def pose(**kw):
    p = dict(NOW); p.update(kw); return p


if __name__ == "__main__":
    # 1. calibration check: real screenshots vs renders at the same settings
    real = [("17", "lean 0", pose(lean=0)), ("16", "lean 15", pose(lean=15)), ("18", "lean 30 (now)", pose(lean=30)),
            ("13", "old hit (went sideways)", pose(lean=55, spin=-75, inner_roll=-8, pos=HIT_POS))]
    W = len(real) * (PW + 10) + 30
    im = Image.new("RGB", (W, 2 * PH + 190), (24, 24, 28)); d = ImageDraw.Draw(im)
    d.text((20, 15), "Check: real game (top) vs my render of the same settings (bottom)", font=FB(34), fill=(255, 255, 255))
    for i, (n, text, ps) in enumerate(real):
        shot = Image.open(f"{OLD}/images/{n}.webp").convert("RGB").crop(CROP).resize((PW, PH), Image.LANCZOS)
        x = 20 + i * (PW + 10)
        im.paste(shot, (x, 70)); im.paste(panel(ps, bg=BG13 if n == "13" else BG), (x, 80 + PH))
        d.text((x, 90 + 2 * PH), text, font=FB(26), fill=RED)
    im.save(f"{NEW}/study_0_check.png")

    # "Straight up" from the real screenshots (lean 15 looked nearly upright in-game); the renderer alone says ~0,
    # but its lean-0 render disagrees with the real lean-0 screenshot, so trust the game here.
    straight = 15
    rows = [
        (("RED - LEAN", "side to side", "(inner bone x)"), RED,
         [(f"R{i+1}", f"lean {v}", pose(lean=v), v == 30) for i, v in enumerate([0, 15, 30, 45, 60])]),
        (("GREEN - SPIN", "which way the", "bowl faces (y)"), GREEN,
         [(f"G{i+1}", f"spin {v}", pose(spin=v), v == -90) for i, v in enumerate([-180, -135, -90, -45, 0])]),
        (("BLUE - TIP", "toward / away", "(root x, resting)"), BLUE,
         [(f"B{i+1}", f"tip {v:+d}", pose(tip=v), v == 0) for i, v in enumerate([30, 15, 0, -15, -30])]),
    ]
    sheet("Bong study - resting (just holding it)",
          "Only one ring changes per row; everything else stays at the current setting (gold box = now). Renders are my approximation, within about 10 degrees.",
          rows, f"{NEW}/study_1_rest.png")

    rows = [
        (("BLUE - TIP", "during a hit", "(root x)"), BLUE,
         [(f"H{i+1}", f"hit tip {v}", pose(tip=v, pos=HIT_POS), v == -40) for i, v in enumerate([-20, -40, -60, -80])]),
        (("COMBOS", "rest + hit", "ideas"), GOLD,
         [("C1", f"lean {straight} (near straight in-game)", pose(lean=straight), False),
          ("C2", f"lean {straight}, hit tip -40", pose(lean=straight, tip=-40, pos=HIT_POS), False),
          ("C3", f"lean {straight}, spin -45", pose(lean=straight, spin=-45), False),
          ("C4", f"lean {straight}, spin -45, hit -60", pose(lean=straight, spin=-45, tip=-60, pos=HIT_POS), False)]),
    ]
    sheet("Bong study - taking a hit (and a few combos)",
          "Hit poses include the small hit shift. C1-C4 mix settings; pick any code or mix numbers yourself.",
          rows, f"{NEW}/study_2_hit.png")
    print("straight-up lean =", straight)
