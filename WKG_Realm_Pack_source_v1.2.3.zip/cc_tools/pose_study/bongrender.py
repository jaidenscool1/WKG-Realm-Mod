"""Small software renderer for the held bong, calibrated against real screenshots.

Chain for a model vertex (all in 1/16-block units):
  cube rotation (downstem) -> inner bone cc_bong_shape rotation [lean, spin, 0]
  -> root bone (animated: tip, position) -> hand frame -> camera (fitted) -> perspective.
Discrete unknowns (rotation sign per axis, Euler order, mirror) and the hand->camera
transform are fitted so renders of lean 0/15/30 match the three in-game screenshots.
"""
import json, math, os
import numpy as np
from PIL import Image, ImageDraw

RP = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "development_resource_packs", "WKG_Realm_Pack_RP")
W, H = 1920, 1080
CX, CY = 957.0, 530.0          # crosshair = view centre
VIEW_Y0, VIEW_Y1 = 23, 1040    # game area inside the window

GEO = json.load(open(os.path.join(RP, "models", "entity", "cc_bong.geo.json")))["minecraft:geometry"][0]
CUBES = [b for b in GEO["bones"] if b["name"] == "cc_bong_shape"][0]["cubes"]
BOWL_INDEX = len(CUBES) - 1  # last cube is the bowl


def rot(axis, deg):
    t = math.radians(deg); c, s = math.cos(t), math.sin(t)
    if axis == 0: return np.array([[1, 0, 0], [0, c, -s], [0, s, c]])
    if axis == 1: return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]])
    return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])


class Conv:
    """Discrete conventions: signs per axis, order ('xyz' = x applied first), mirror of x."""
    def __init__(self, sx=1, sy=1, sz=1, order="xyz", mirror=False):
        self.s, self.order, self.mirror = (sx, sy, sz), order, mirror

    def euler(self, r):
        m = np.eye(3)
        for ch in self.order:          # first letter applied first
            i = "xyz".index(ch)
            m = rot(i, self.s[i] * r[i]) @ m
        return m

    def __repr__(self):
        return f"signs={self.s} order={self.order} mirror={self.mirror}"


def cube_corners(c):
    o, s = np.array(c["origin"], float), np.array(c["size"], float)
    x0, y0, z0 = o; x1, y1, z1 = o + s
    V = {
        "north": [(x1, y1, z0), (x0, y1, z0), (x0, y0, z0), (x1, y0, z0)],
        "south": [(x0, y1, z1), (x1, y1, z1), (x1, y0, z1), (x0, y0, z1)],
        "east": [(x1, y1, z1), (x1, y1, z0), (x1, y0, z0), (x1, y0, z1)],
        "west": [(x0, y1, z0), (x0, y1, z1), (x0, y0, z1), (x0, y0, z0)],
        "up": [(x0, y1, z0), (x1, y1, z0), (x1, y1, z1), (x0, y1, z1)],
        "down": [(x0, y0, z1), (x1, y0, z1), (x1, y0, z0), (x0, y0, z0)],
    }
    N = {"north": (0, 0, -1), "south": (0, 0, 1), "east": (1, 0, 0), "west": (-1, 0, 0), "up": (0, 1, 0), "down": (0, -1, 0)}
    return {f: (np.array(v, float), np.array(N[f], float)) for f, v in V.items()}


FACES = [cube_corners(c) for c in CUBES]


def hand_to_camera(params, conv):
    """params: a1,a2,a3 (deg), tx,ty,tz, f"""
    a1, a2, a3, tx, ty, tz, f = params
    M = rot(1, a2) @ rot(0, a1) @ rot(2, a3)
    if conv.mirror:
        M = M @ np.diag([-1, 1, 1])
    return M, np.array([tx, ty, tz]), f


def transform_faces(params, conv, lean=30, spin=-90, tip=0.0, pos=(0, 19, 0), root_yaw=0.0, root_roll=0.0, scale=1.0, inner_roll=0.0, root_pivot=(0, 0, 0)):
    M, t, f = hand_to_camera(params, conv)
    Rb = conv.euler((lean, spin, inner_roll))
    Rr = conv.euler((tip, root_yaw, root_roll))
    pos = np.array(pos, float)
    out = []
    for ci, (c, faces) in enumerate(zip(CUBES, FACES)):
        Rc = conv.euler(c["rotation"]) if "rotation" in c else np.eye(3)
        pc = np.array(c.get("pivot", [0, 0, 0]), float)
        for fname, (v, n) in faces.items():
            p = (v - pc) @ Rc.T + pc
            p = p * scale
            p = p @ Rb.T
            rp = np.array(root_pivot, float)
            p = (p - rp) @ Rr.T + rp + pos
            P = p @ M.T + t
            nn = (M @ Rr @ Rb @ Rc @ n)
            out.append((ci, fname, P, nn))
    return out, f


def project(P, f):
    Z = -P[:, 2]
    Z = np.maximum(Z, 1e-3)
    return np.stack([CX + f * P[:, 0] / Z, CY - f * P[:, 1] / Z], 1)


def label_image(params, conv, scale_px=0.25, **pose):
    """Painter's-order label image: 0 background, 1 glass, 2 bowl."""
    faces, f = transform_faces(params, conv, **pose)
    w, h = int(W * scale_px), int(H * scale_px)
    img = Image.new("L", (w, h), 0)
    d = ImageDraw.Draw(img)
    vis = []
    for ci, fname, P, nn in faces:
        if np.any(P[:, 2] > -1): continue
        centre = P.mean(0)
        if np.dot(nn, -centre) <= 0: continue          # back face
        vis.append((-centre[2], ci, P))
    for depth, ci, P in sorted(vis, key=lambda x: -x[0]):
        q = project(P, f) * scale_px
        d.polygon([tuple(x) for x in q], fill=2 if ci == BOWL_INDEX else 1)
    a = np.asarray(img)
    a = a.copy()
    a[: int(VIEW_Y0 * scale_px)] = 0
    a[int(VIEW_Y1 * scale_px):] = 0
    return a
