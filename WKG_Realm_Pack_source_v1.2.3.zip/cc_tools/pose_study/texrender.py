"""Textured render of the held bong over a cleaned-up screenshot."""
import os
import numpy as np
from PIL import Image, ImageDraw, ImageFilter
from scipy import ndimage
import bongrender as br

UP = 16  # texture upscale for sampling


def homography(src, dst):
    """Coefficients mapping dst (output) points -> src (input) points, for PIL PERSPECTIVE."""
    A, b = [], []
    for (x, y), (u, v) in zip(dst, src):
        A.append([x, y, 1, 0, 0, 0, -u * x, -u * y]); b.append(u)
        A.append([0, 0, 0, x, y, 1, -v * x, -v * y]); b.append(v)
    return np.linalg.lstsq(np.array(A, float), np.array(b, float), rcond=None)[0]


def render(params, conv, stage="packed", tint=(0.68, 0.72, 0.96), **pose):
    tex = Image.open(os.path.join(br.RP, "textures", "items", f"cc_bong_model_{stage}.png")).convert("RGBA")
    tex = tex.resize((tex.width * UP, tex.height * UP), Image.NEAREST)
    faces, f = br.transform_faces(params, conv, **pose)
    layer = Image.new("RGBA", (br.W, br.H), (0, 0, 0, 0))
    L = np.array([0.35, 0.85, 0.4]); L /= np.linalg.norm(L)
    vis = []
    for ci, fname, P, nn in faces:
        if np.any(P[:, 2] > -1): continue
        centre = P.mean(0)
        if np.dot(nn, -centre) <= 0: continue
        vis.append((-centre[2], ci, fname, P, nn))
    for depth, ci, fname, P, nn in sorted(vis, key=lambda x: -x[0]):
        q = br.project(P, f)
        uv = br.CUBES[ci]["uv"][fname]
        (u, v), (w, h) = uv["uv"], uv["uv_size"]
        src = [(u * UP, v * UP), ((u + w) * UP, v * UP), ((u + w) * UP, (v + h) * UP), (u * UP, (v + h) * UP)]
        x0, y0 = np.floor(q.min(0)).astype(int); x1, y1 = np.ceil(q.max(0)).astype(int)
        x0, y0 = max(x0, 0), max(y0, 0); x1, y1 = min(x1, br.W), min(y1, br.H)
        if x1 - x0 < 1 or y1 - y0 < 1: continue
        coeffs = homography(src, [(a - x0, b - y0) for a, b in q])
        piece = tex.transform((x1 - x0, y1 - y0), Image.PERSPECTIVE, tuple(coeffs), Image.NEAREST)
        n = nn / np.linalg.norm(nn)
        shade = 0.62 + 0.38 * max(0.0, float(np.dot(n, L)))
        arr = np.asarray(piece).astype(float)
        arr[..., :3] *= np.array(tint) * shade
        piece = Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8))
        mask = Image.new("L", piece.size, 0)
        ImageDraw.Draw(mask).polygon([(a - x0, b - y0) for a, b in q], fill=255)
        alpha = Image.fromarray(np.minimum(np.asarray(mask), np.asarray(piece)[..., 3]))
        layer.paste(piece, (x0, y0), alpha)
    # clip to the game view
    arr = np.asarray(layer).copy()
    arr[: br.VIEW_Y0, :, 3] = 0; arr[br.VIEW_Y1:, :, 3] = 0
    return Image.fromarray(arr)


def clean_background(shot_path, mask_path, dx=-760):
    """Paint the real bong out by copying the ground from further left, with a soft edge."""
    im = np.asarray(Image.open(shot_path).convert("RGB")).astype(float)
    glass, bowl = np.load(mask_path)
    m = ndimage.binary_dilation(glass | bowl, iterations=10)
    m[:, :900] = False
    m[945:1040, 595:1325] = False  # keep the hotbar
    src = np.roll(im, -dx, axis=1)  # pixel (x) <- pixel (x + dx)
    # bottom rows: the shifted copy would land on the hotbar, so also take them from higher up
    src[935:] = np.roll(src, 120, axis=0)[935:]
    soft = np.asarray(Image.fromarray((m * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(6))) / 255.0
    out = im * (1 - soft[..., None]) + src * soft[..., None]
    return Image.fromarray(out.astype(np.uint8))
