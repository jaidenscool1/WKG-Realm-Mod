"""First-person OFFHAND poses for the smokable attachables, derived from vanilla's shield.

Idea: the vanilla shield has a main-hand and an off-hand first-person pose that show it at
mirror-image spots on screen. Whatever maps one to the other (with the unknown first-person arm
frames cancelling out) is applied to our main-hand idle poses:
    P_off = S_off * Mshield * S_main^-1 * P_main * Mitem
(S_* = shield bone transforms, M* = mirror of each model about its own centre plane).
Rotation convention = the one fitted from in-game screenshots (calib.json).
Run: python offhand_pose.py"""
import json, os
import numpy as np
from scipy.optimize import least_squares
import bongrender as br

HERE = os.path.dirname(os.path.abspath(__file__))
cal = json.load(open(os.path.join(HERE, "calib.json")))
conv = br.Conv(*cal["signs"], cal["order"], cal["mirror"])


def bone(rot, pos, pivot):
    """4x4 for a bone: rotate about pivot, then translate by pos."""
    R = conv.euler(rot)
    pv = np.array(pivot, float)
    T = np.eye(4)
    T[:3, :3] = R
    T[:3, 3] = pv - R @ pv + np.array(pos, float)
    return T


def mirror_x(plane_x):
    M = np.eye(4)
    M[0, 0] = -1
    M[0, 3] = 2 * plane_x
    return M


def solve(P, pivot, near=(0, 0, 0)):
    """Euler rotation + position giving 4x4 P for a bone with this pivot. `near` picks, among the
    equivalent Euler triples, the one closest to another pose so an animation between them is smooth."""
    R = P[:3, :3]
    best = None
    for dx in (-360, 0, 360):
        for start in ([near[0], near[1], near[2]], [near[0] + 180, 180 - near[1], near[2] + 180], [0, 0, 0]):
            fit = least_squares(lambda e: (conv.euler(e) - R).ravel(), x0=[start[0] + dx, start[1], start[2]])
            if np.abs(conv.euler(fit.x) - R).max() > 1e-4:
                continue
            e = fit.x.copy()
            for i in range(3):  # unwrap each angle toward `near`
                e[i] = near[i] + ((e[i] - near[i] + 180) % 360 - 180)
            d = np.abs(e - np.array(near)).sum()
            if best is None or d < best[0]:
                best = (d, e)
    e = best[1]
    pv = np.array(pivot, float)
    pos = P[:3, 3] - pv + conv.euler(e) @ pv
    err = np.abs(conv.euler(e) - R).max()
    return [round(float(a), 1) for a in e], [round(float(p), 2) for p in pos], err


SHIELD_PIVOT = [1.0, 15.5, 3.0]
S_MAIN = bone([91.0, 65.0, -43.0], [5.3, 26.0, 0.4], SHIELD_PIVOT)
S_OFF = bone([1.0, 176.0, -2.5], [-13.5, -5.8, 5.1], SHIELD_PIVOT)
M_SHIELD = mirror_x(1.0)  # the shield is symmetric about x = 1

# name: (main-hand rotation, position, root pivot, model centre x) - idle poses and the end frame
# of each main-hand "raised" (taking a hit) pose, as tuned in-game.
ITEMS = {
    "stick": ([-20, 90, 0], [0, 19, 0], [0, 0, 0], 0.0),
    "vape": ([0, 0, 0], [0, 19, 0], [0, 0, 0], 0.0),
    "bong": ([0, 0, 0], [0, 19, 0], [11.0, 6.9, 2.6], 0.0),
    "stick_raised": ([-20, 50, 0], [0.75, 19.75, -4.5], [0, 0, 0], 0.0),
    "vape_raised": ([0, 25, 0], [0.75, 19.75, -8.5], [0, 0, 0], 0.0),
    "bong_raised": ([-30, 9.5, 46.8], [0, 19, -4], [11.0, 6.9, 2.6], 0.0),
}


def offhand(rot, pos, pivot, cx, near=(0, 0, 0)):
    P = S_OFF @ M_SHIELD @ np.linalg.inv(S_MAIN) @ bone(rot, pos, pivot) @ mirror_x(cx)
    return solve(P, pivot, near)


if __name__ == "__main__":
    out = {}
    for name, args in ITEMS.items():
        base = name.replace("_raised", "")
        near = out[base]["rotation"] if base != name else (0, 0, 0)  # raised: closest to its idle
        e, p, err = offhand(*args, near=near)
        out[name] = {"rotation": e, "position": p}
        print(f"{name:13s} rotation {e}  position {p}  (fit error {err:.2e})")
    json.dump(out, open(os.path.join(HERE, "offhand_pose.json"), "w"), indent=2)
