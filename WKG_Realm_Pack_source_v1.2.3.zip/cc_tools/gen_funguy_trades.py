"""Funguy trade tables. One price list -> two tables (resident and wanderer).
Every Funguy rolls his own random stock from the groups below, 6 trades max:
  always the shatter buy, then PICK seeds and PICK gear chosen at random.
Resident (village) Funguys restock and allow more uses; wanderers have fewer uses.
Run: python cc_tools/gen_funguy_trades.py"""
import json, os

BP = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "development_behavior_packs", "WKG_Realm_Pack_BP")

PRICE_MULTIPLIER = 0.05  # same as most vanilla villager trades

# (group, how many each Funguy offers, [(wants item, wants qty, gives item, gives qty)])
# Keep the picks adding up to 6 or less (user: max 6 trades per Funguy).
GROUPS = [
    ("buys", 1, [
        ("cc:shatter", 1, "minecraft:emerald", 2),
    ]),
    ("seeds", 3, [
        # common (also craftable)
        ("minecraft:emerald", 3, "cc:seed_og_kush", 1),
        ("minecraft:emerald", 3, "cc:seed_blue_dream", 1),
        ("minecraft:emerald", 3, "cc:seed_sour_diesel", 1),
        ("minecraft:emerald", 3, "cc:seed_purple_haze", 1),
        ("minecraft:emerald", 3, "cc:seed_gorilla_glue", 1),
        ("minecraft:emerald", 3, "cc:seed_green_crack", 1),
        ("minecraft:emerald", 3, "cc:seed_tysgorilla", 1),
        ("minecraft:emerald", 3, "cc:seed_tender_lad", 1),
        ("minecraft:emerald", 3, "cc:seed_purple_nurple", 1),
        # breed-only
        ("minecraft:emerald", 10, "cc:seed_white_widow", 1),
        ("minecraft:emerald", 10, "cc:seed_purple_punch", 1),
        ("minecraft:emerald", 10, "cc:seed_skywalker_og", 1),
        # trade-only, then Funguy exclusives
        ("minecraft:emerald", 8, "cc:seed_george_droid", 1),
        ("minecraft:emerald", 8, "cc:seed_sleepy_joe_og", 1),
        ("minecraft:emerald", 8, "cc:seed_black_mamba", 1),
        ("minecraft:emerald", 16, "cc:seed_phantom_cookies", 1),
        ("minecraft:emerald", 16, "cc:seed_poseidon_og", 1),
        ("minecraft:emerald", 16, "cc:seed_hero_haze", 1),
    ]),
    ("gear", 2, [
        ("minecraft:emerald", 6, "cc:drying_rack", 1),
        ("minecraft:emerald", 12, "cc:nug_press", 1),
        ("minecraft:emerald", 4, "cc:press_plate_copper", 1),
        ("minecraft:emerald", 8, "cc:press_plate_iron", 1),
        ("minecraft:emerald", 6, "cc:rolling_paper", 2),
        ("minecraft:emerald", 8, "cc:cart_empty", 1),
    ]),
]
MAX_TRADES = 6
assert sum(pick for _g, pick, _t in GROUPS) <= MAX_TRADES


def table(resident):
    groups = []
    for _name, pick, trades in GROUPS:
        groups.append({
            "num_to_select": pick,
            "trades": [{
                # price_multiplier makes an emerald price respond to demand, which is how the
                # Hero of the Village discount (hero_demand_discount in funguy.json) is applied.
                "wants": [{"item": wi, "quantity": wq, "price_multiplier": PRICE_MULTIPLIER}
                          if wi == "minecraft:emerald" else {"item": wi, "quantity": wq}],
                "gives": [{"item": gi, "quantity": gq}],
                "max_uses": 32 if resident else 8,
                "reward_exp": False,
            } for wi, wq, gi, gq in trades],
        })
    return {"tiers": [{"total_exp_required": 0, "groups": groups}]}


def main():
    out = os.path.join(BP, "trading")
    os.makedirs(out, exist_ok=True)
    for name, resident in (("cc_funguy_resident", True), ("cc_funguy_wanderer", False)):
        with open(os.path.join(out, name + ".json"), "w", encoding="utf-8") as f:
            json.dump(table(resident), f, indent=2)
            f.write("\n")
    print("wrote trading/cc_funguy_resident.json and cc_funguy_wanderer.json")


if __name__ == "__main__":
    main()
