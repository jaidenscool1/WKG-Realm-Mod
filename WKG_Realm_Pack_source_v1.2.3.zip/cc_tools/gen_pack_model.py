"""Held model for the Marlboro Reds pack: a small 3D box with a cigarette inside that slides out of the lid when
you take a hit. Writes models/entity/cc_cig_pack.geo.json, textures/items/cc_cig_pack_model.png (32x32, per-face
UV), the animation.cc.pack.* animations, and points the 4 pack attachables at them.
Held-item space has +y DOWN on screen (see the bong), so the pack is modelled upside down: the lid (visual top)
is at LOW y and the cigarette slides out toward -y. Side textures are painted flipped to match.
Run: python cc_tools/gen_pack_model.py"""
import json, os, sys
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, "..")
RP = os.path.join(ROOT, "development_resource_packs", "WKG_Realm_Pack_RP")
TEX = 32
RED, RED_D, WHITE, WHITE_D, BLACK = (206, 30, 36), (150, 18, 24), (244, 244, 240), (206, 204, 198), (40, 36, 36)
FILTER, FILTER_D, PAPER, PAPER_D = (214, 140, 60), (178, 108, 40), (246, 244, 238), (214, 212, 204)
HOLE = (60, 40, 30)

# upside-down model: pack y 0..7 (y 0 = lid/visual top); cigarette y 1..7 inside, filter at the low-y end
PACK = {"origin": [-2, 0, -1], "size": [4, 7, 2]}
CIG = {"origin": [-0.5, 1, -0.5], "size": [1, 6, 1]}
CIG_SLIDE = -8  # the cigarette leaves the lid completely (it's 6 long)
STRIP_Y = 28  # texture row of the held-cigarette strip


def paint_pack(face, x, y, w, h):
    # y here is texture row 0 = model HIGH y = visual BOTTOM (upside-down model), so flip for visuals
    vy = h - 1 - y
    if face == "down":  # visual top of the pack: open lid showing filter tips
        return FILTER if (x + y) % 2 == 0 else HOLE
    if face == "up":
        return WHITE_D
    edge = x in (0, w - 1)
    if vy <= 2:  # red lid band
        c = RED_D if edge else RED
        if face in ("north", "south") and vy == 2 and 1 <= x <= w - 2:
            c = WHITE  # chevron hint
        return c
    if face in ("north", "south") and vy == 4 and 1 <= x <= w - 2:
        return BLACK  # brand line
    return WHITE_D if edge else WHITE


def paint_cig(face, x, y, w, h):
    vy = h - 1 - y  # visual top = filter
    if face == "down":
        return FILTER
    if face == "up":
        return PAPER_D
    return (FILTER if x == 0 else FILTER_D) if vy <= 1 else (PAPER if x == 0 else PAPER_D)


def face_sizes(size):
    sx, sy, sz = size
    return {"north": (sx, sy), "south": (sx, sy), "east": (sz, sy), "west": (sz, sy), "up": (sx, sz), "down": (sx, sz)}


def stick_cubes():
    """The joint's stick geometry (12 slices along z, z=-6 = mouth end) mapped onto the pack texture's strip."""
    return [{"origin": [-1, -1, -6 + k], "size": [2, 2, 1],
             "uv": {f: {"uv": [11 - k, STRIP_Y], "uv_size": [1, 2]} for f in ("north", "south", "east", "west", "up", "down")}}
            for k in range(12)]


def build_texture_and_uv():
    img = Image.new("RGBA", (TEX, TEX), (0, 0, 0, 0))
    px = img.load()
    cur_x = cur_y = row_h = 0
    uvs = {}
    for name, cube, painter in (("pack", PACK, paint_pack), ("cig", CIG, paint_cig)):
        uv = {}
        for face, (w, h) in face_sizes(cube["size"]).items():
            w, h = int(round(w)), int(round(h))
            if cur_x + w > TEX:
                cur_x, cur_y, row_h = 0, cur_y + row_h, 0
            for y in range(h):
                for x in range(w):
                    px[cur_x + x, cur_y + y] = tuple(painter(face, x, y, w, h)) + (255,)
            uv[face] = {"uv": [cur_x, cur_y], "uv_size": [w, h]}
            cur_x += w
            row_h = max(row_h, h)
        uvs[name] = uv
    # strip for the held cigarette (same layout as the joint/cigarette icon: cols 2-13, rows 6-7; col 13 = mouth end)
    assert cur_y + row_h <= STRIP_Y, "pack atlas overlaps the cigarette strip"
    cig_icon = Image.open(os.path.join(RP, "textures", "items", "cc_cigarette.png")).convert("RGBA")
    img.alpha_composite(cig_icon.crop((2, 6, 14, 8)), (0, STRIP_Y))
    img.save(os.path.join(RP, "textures", "items", "cc_cig_pack_model.png"))
    return uvs


BP = os.path.join(ROOT, "development_behavior_packs", "WKG_Realm_Pack_BP")
NL = chr(10)


def make_lit_items():
    """cc:cigarette_pack_lit(_sN): twins of the pack stages (same icon/name/durability, hidden from creative)."""
    it_path = os.path.join(RP, "textures", "item_texture.json")
    it = json.load(open(it_path, encoding="utf-8"))
    for s in ("", "_s1", "_s2", "_s3"):
        src = json.load(open(os.path.join(BP, "items", f"cigarette_pack{s}.json"), encoding="utf-8"))
        item = src["minecraft:item"]
        lit_id = f"cc:cigarette_pack_lit{s}"
        item["description"]["identifier"] = lit_id
        item["description"]["menu_category"] = {"category": "none"}
        item["components"]["minecraft:icon"] = lit_id
        item["components"]["minecraft:display_name"] = {"value": f"item.{lit_id}.name"}
        item["components"]["minecraft:use_modifiers"] = {"use_duration": 3.0, "movement_modifier": 0.4}
        with open(os.path.join(BP, "items", f"cigarette_pack_lit{s}.json"), "w", encoding="utf-8") as f:
            json.dump(src, f, indent=2)
            f.write(NL)
        it["texture_data"][lit_id] = {"textures": f"textures/items/cc_cigarette_pack{s}"}
    json.dump(it, open(it_path, "w", encoding="utf-8"), indent=2)
    texts = os.path.join(RP, "texts")
    for fn in os.listdir(texts):
        if fn.endswith(".lang"):
            path = os.path.join(texts, fn)
            t = open(path, encoding="utf-8", newline="").read()
            if not t.endswith(NL):
                t += NL
            for s in ("", "_s1", "_s2", "_s3"):
                key = f"item.cc:cigarette_pack_lit{s}.name="
                if key not in t:
                    t += key + "§cMarlboro Reds§r (12)" + NL
            open(path, "w", encoding="utf-8", newline="").write(t)


def main():
    uvs = build_texture_and_uv()
    geo = {"format_version": "1.16.0", "minecraft:geometry": [{
        "description": {"identifier": "geometry.cc.cig_pack", "texture_width": TEX, "texture_height": TEX,
                        "visible_bounds_width": 2, "visible_bounds_height": 2, "visible_bounds_offset": [0, 0.5, 0]},
        "bones": [
            {"name": "root", "binding": "q.item_slot_to_bone_name(context.item_slot)", "pivot": [0, 4, 0]},
            # same resting lean/turn as the bong's cc_bong_shape, which sits well in first person
            {"name": "cc_pack_shape", "parent": "root", "pivot": [0, 0, 0], "rotation": [20, -90, 0],
             "cubes": [{**PACK, "uv": uvs["pack"]}]},
            {"name": "cc_pack_cig", "parent": "cc_pack_shape", "pivot": [0, 0, 0],
             "cubes": [{**CIG, "uv": uvs["cig"]}]},
            # the cigarette once it's out of the pack: the joint's stick model, posed with the joint's tuned poses
            {"name": "cc_pack_held_cig", "parent": "root", "pivot": [0, 0, 0], "cubes": stick_cubes()},
            # third person: a cigarette bound to the player's HEAD, so it sits on the lips whatever the arm does
            {"name": "cc_mouth_cig", "binding": "'head'", "pivot": [0, 0, 0], "cubes": stick_cubes()},
        ]}]}
    with open(os.path.join(RP, "models", "entity", "cc_cig_pack.geo.json"), "w", encoding="utf-8") as f:
        json.dump(geo, f, indent=2)
        f.write("\n")

    # offhand first-person poses, mirrored from the main-hand ones (same method as the other smokables)
    sys.path.insert(0, os.path.join(HERE, "pose_study"))
    import offhand_pose as op
    import numpy as np
    idle = ([0, 0, 0], [0, 19, 0], [0, 4, 0], 0.0)  # the pack's resting pose; it stays there during a hit
    off_idle = op.offhand(*idle)
    # joint poses (user-tuned), main hand and the offhand mirror
    J_IDLE = ([-20, 90, 0], [0, 19, 0], [0, 0, 0], 0.0)
    J_RAISED = ([-20, 50, 0], [0.75, 19.75, -4.5], [0, 0, 0], 0.0)
    joint_off = json.load(open(os.path.join(HERE, "pose_study", "offhand_pose.json")))

    def local(root_pose, target_rot, target_pos, near=(0, 0, 0)):
        """Pose of a child bone (pivot 0) under `root_pose` that puts it exactly at the target root-level pose."""
        rot, pos, pivot = root_pose[0], root_pose[1], [0, 4, 0]
        child = np.linalg.inv(op.bone(rot, pos, pivot)) @ op.bone(target_rot, target_pos, [0, 0, 0])
        e, p, _ = op.solve(child, [0, 0, 0], near)
        return e, p

    held_from = local(idle, *J_IDLE[:2], near=J_IDLE[0])
    held_to = local(idle, *J_RAISED[:2], near=held_from[0])
    off_root = (off_idle[0], off_idle[1])
    off_from = local(off_root, joint_off["stick"]["rotation"], joint_off["stick"]["position"], near=joint_off["stick"]["rotation"])
    off_to = local(off_root, joint_off["stick_raised"]["rotation"], joint_off["stick_raised"]["position"], near=off_from[0])

    SWAP, END = 0.3, 0.65  # slide out 0-0.3s, then carry it to the mouth by 0.65s
    hide = {"0.0": [1, 1, 1], str(SWAP): [1, 1, 1], str(SWAP + 0.01): [0, 0, 0]}
    show = {"0.0": [0, 0, 0], str(SWAP): [0, 0, 0], str(SWAP + 0.01): [1, 1, 1]}

    def raised_anim(root, frm, to):
        return {"loop": "hold_on_last_frame", "animation_length": END, "override_previous_animation": True, "bones": {
            "root": {"rotation": root[0], "position": root[1]},
            "cc_pack_cig": {"position": {"0.0": [0, 0, 0], str(SWAP): [0, CIG_SLIDE, 0]}, "scale": hide},
            "cc_pack_held_cig": {"scale": show, "rotation": {str(SWAP): frm[0], str(END): to[0]},
                                 "position": {str(SWAP): frm[1], str(END): to[1]}},
            "cc_mouth_cig": {"scale": 0}}}

    def rest_anim(root):
        return {"loop": True, "bones": {"root": {"rotation": root[0], "position": root[1]},
                                        "cc_pack_cig": {"position": [0, 0, 0], "scale": 1},
                                        "cc_pack_held_cig": {"scale": 0}, "cc_mouth_cig": {"scale": 0}}}

    anims_path = os.path.join(RP, "animations", "cc_smokable_pose.animation.json")
    A = json.load(open(anims_path, encoding="utf-8"))
    A["animations"]["animation.cc.pack.idle"] = rest_anim(idle)
    A["animations"]["animation.cc.pack.raised"] = raised_anim(idle, held_from, held_to)
    A["animations"]["animation.cc.pack.offhand_fp"] = rest_anim(off_root)
    A["animations"]["animation.cc.pack.raised_off"] = raised_anim(off_root, off_from, off_to)

    def lit_anim(root, at_mouth):
        """Lit pack: the pack at rest, the cigarette parked at the mouth - no take-out animation."""
        return {"loop": True, "bones": {"root": {"rotation": root[0], "position": root[1]},
                                        "cc_pack_cig": {"scale": 0},
                                        "cc_pack_held_cig": {"scale": 1, "rotation": at_mouth[0], "position": at_mouth[1]},
                                        "cc_mouth_cig": {"scale": 0}}}
    A["animations"]["animation.cc.pack.lit"] = lit_anim(idle, held_to)
    A["animations"]["animation.cc.pack.lit_off"] = lit_anim(off_root, off_to)
    with open(anims_path, "w", encoding="utf-8") as f:
        json.dump(A, f, indent=2)
        f.write("\n")

    make_lit_items()
    for s in ("", "_s1", "_s2", "_s3", "_lit", "_lit_s1", "_lit_s2", "_lit_s3"):
        p = os.path.join(RP, "attachables", f"cigarette_pack{s}.json")
        if not os.path.exists(p):
            json.dump(json.load(open(os.path.join(RP, "attachables", "cigarette_pack.json"), encoding="utf-8")),
                      open(p, "w", encoding="utf-8"))
        a = json.load(open(p, encoding="utf-8"))
        d = a["minecraft:attachable"]["description"]
        d["geometry"] = {"default": "geometry.cc.cig_pack"}
        d["textures"] = {"default": "textures/items/cc_cig_pack_model", "enchanted": "textures/items/cc_cig_pack_model"}
        d["identifier"] = f"cc:cigarette_pack{s}"
        if "_lit" in s:  # cigarette already at the mouth: same static pose whether or not the button is held
            d["animations"].update({"idle": "animation.cc.pack.lit", "raised": "animation.cc.pack.lit",
                                    "offhand_fp": "animation.cc.pack.lit_off", "raised_off": "animation.cc.pack.lit_off"})
        else:
            d["animations"].update({"idle": "animation.cc.pack.idle", "raised": "animation.cc.pack.raised",
                                    "offhand_fp": "animation.cc.pack.offhand_fp", "raised_off": "animation.cc.pack.raised_off"})
        with open(p, "w", encoding="utf-8") as f:
            json.dump(a, f, indent=2)
            f.write("\n")
    print("pack model + animations written; held cig main", held_from, "->", held_to, "| offhand", off_from, "->", off_to)


if __name__ == "__main__":
    main()
