"""Preview a block .geo.json with its texture: front (north), side (east) and top views, orthographic.
Handles per-face UV (dict) cubes, no bone rotation. Faces are drawn back-to-front.
  python cc_tools/render_geo.py <geo.json> <texture.png> <out.png> [--scale 12] [more geo:texture pairs...]"""
import json, sys
from PIL import Image, ImageDraw


def cubes(path):
    g = json.load(open(path, encoding="utf-8"))["minecraft:geometry"][0]
    tw, th = g["description"]["texture_width"], g["description"]["texture_height"]
    out = []
    for b in g["bones"]:
        for c in b.get("cubes", []):
            out.append(c)
    return out, tw, th


def face_img(tex, c, face, tw, th, w, h):
    uv = c.get("uv", {}).get(face)
    if not uv:
        return None
    (u, v), (us, vs) = uv["uv"], uv["uv_size"]
    sx, sy = tex.width / tw, tex.height / th
    box = (round(u * sx), round(v * sy), round((u + us) * sx), round((v + vs) * sy))
    if box[2] <= box[0] or box[3] <= box[1]:
        return None
    return tex.crop(box).resize((max(1, w), max(1, h)), Image.NEAREST)


def view(geo, texpath, S):
    cs, tw, th = cubes(geo)
    tex = Image.open(texpath).convert("RGBA")
    W = 32 * S
    panels = []
    # front: look at north faces (z min), x left->right, y up; draw far (large z) first
    for name, face, key, hx, vy in (("north", "north", lambda c: -c["origin"][2], 0, 1),
                                     ("south", "south", lambda c: c["origin"][2], 0, 1),
                                     ("side", "east", lambda c: c["origin"][0], 2, 1),
                                     ("top", "up", lambda c: c["origin"][1], 0, 2)):
        im = Image.new("RGBA", (W, W), (70, 74, 90, 255))
        for c in sorted(cs, key=key):
            o, s = c["origin"], c["size"]
            w, h = round(s[hx] * S), round(s[vy] * S)
            f = face_img(tex, c, face, tw, th, w, h)
            if f is None:
                continue
            if name == "side":
                x = round((16 - o[2] - s[2]) * S)
            elif name == "south":
                x = round((16 - o[0] - s[0]) * S)  # seen from behind: mirrored
            else:
                x = round((o[hx] + 16) * S)
            if name == "top":
                y = round((o[2] + 16) * S)
            else:
                y = round((24 - o[1] - s[1]) * S)
            im.alpha_composite(f, (x, y))
        ImageDraw.Draw(im).text((6, 4), name, fill=(255, 255, 255, 255))
        panels.append(im)
    row = Image.new("RGBA", (W * 4 + 24, W), (40, 40, 50, 255))
    for i, p in enumerate(panels):
        row.alpha_composite(p, (i * (W + 8), 0))
    return row


def main():
    args = sys.argv[1:]
    S = 12
    if "--scale" in args:
        i = args.index("--scale"); S = int(args[i + 1]); del args[i:i + 2]
    out = args[2]
    pairs = [(args[0], args[1])] + [tuple(a.split(":", 1)) if ":" in a and not a[1:3] == ":/" else None for a in args[3:]]
    rows = [view(g, t, S) for g, t in pairs if g]
    sheet = Image.new("RGBA", (rows[0].width, sum(r.height + 8 for r in rows)), (30, 30, 36, 255))
    y = 0
    for r in rows:
        sheet.alpha_composite(r, (0, y)); y += r.height + 8
    sheet.save(out)
    print("wrote", out)


if __name__ == "__main__":
    main()
