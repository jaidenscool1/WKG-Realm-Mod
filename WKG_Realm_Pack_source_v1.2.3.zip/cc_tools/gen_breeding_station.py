"""Breeding Station: a small genetics machine (cabinet + control panel, glass growth chamber with a sprout,
two seed tanks piped into the chamber, status beacon). Writes models/blocks/breeding_station.geo.json and
textures/blocks/cc_breeding_station.png (64x64, per-face UV, 1 texel per model pixel).
The control panel is modelled on the SOUTH (+z) face; placement_direction rotations turn it toward the player.
Run: python cc_tools/gen_breeding_station.py"""
import json, os, random
from PIL import Image

RP = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "development_resource_packs", "WKG_Realm_Pack_RP")
TEX = 64
rng = random.Random(11)

STEEL, STEEL_D, STEEL_L = (92, 98, 108), (62, 66, 76), (128, 134, 146)
TRIM = (48, 52, 60)
BRASS, BRASS_D = (196, 158, 64), (150, 116, 42)
GLASS_EDGE, GLASS_HI = (176, 214, 226), (226, 244, 250)
SCREEN, SCREEN_L = (18, 44, 26), (70, 220, 110)
LEAF, LEAF_D = (70, 150, 52), (44, 106, 36)
SEED, SEED_D, SEED_L = (140, 110, 60), (104, 80, 44), (120, 170, 70)
RED, RED_L = (200, 36, 36), (255, 110, 100)
YELLOW, GREEN_LED = (240, 200, 40), (60, 230, 90)


def jit(c, a=6):
    return tuple(max(0, min(255, v + rng.randint(-a, a))) for v in c)


# ---- painters: fn(face, x, y, w, h) -> RGB/RGBA or None (transparent) ----
def cabinet(face, x, y, w, h):
    edge = x in (0, w - 1) or y in (0, h - 1)
    if face in ("up", "down"):
        return STEEL_D
    if edge:
        return TRIM
    if face == "south":  # control panel
        if 2 <= y <= 4 and 2 <= x <= 7:  # screen with a DNA helix
            if y in (2, 4) and x % 2 == 0 or y == 3 and x % 2 == 1:
                return SCREEN_L
            return SCREEN
        if y == 2 and x in (10, 12):
            return jit(STEEL_L, 3)  # dials
        if y == 3 and x in (10, 12):
            return (30, 30, 34)
        if y == 6 and 2 <= x <= 12:
            return [GREEN_LED, YELLOW, RED, GREEN_LED, (40, 40, 44)][x % 5]  # status LEDs
        return jit(STEEL, 4)
    if face in ("east", "west") and 2 <= y <= 5 and 2 <= x <= w - 3 and x % 2 == 0:
        return STEEL_D  # vents
    if (x, y) in ((1, 1), (w - 2, 1), (1, h - 2), (w - 2, h - 2)):
        return STEEL_L  # rivets
    return jit(STEEL, 4)


def top_plate(face, x, y, w, h):
    if face == "up" and (x, y) in ((1, 1), (w - 2, 1), (1, h - 2), (w - 2, h - 2)):
        return STEEL_L
    return jit(TRIM if face != "up" else STEEL_D, 4)


def chamber(face, x, y, w, h):
    if face in ("up", "down"):
        return None  # capped / sits on the plate
    if x in (0, w - 1):
        return GLASS_EDGE
    if y == 0 or y == h - 1:
        return (150, 190, 204)
    if (x, y) in ((w - 2, 1), (w - 3, 2)):  # small glint
        return GLASS_HI
    return None  # see the sprout inside


def cap(face, x, y, w, h):
    if face == "up" and 2 <= x <= w - 3 and 2 <= y <= h - 3:
        return jit(STEEL_L, 4)
    if face != "up" and face != "down" and x % 3 == 0:
        return YELLOW  # warning stripes
    return jit(STEEL_D, 4)


def sprout(face, x, y, w, h):
    # 4 wide x 6 tall plane: stem + two small fan leaves + top leaf
    if x in (1, 2) and y >= 3:
        return LEAF_D if x == 1 else None
    pts = {(0, 3), (0, 2), (3, 3), (3, 2), (1, 1), (2, 1), (1, 0), (2, 2), (1, 2)}
    return (LEAF if (x + y) % 2 else LEAF_D) if (x, y) in pts else None


def tank(face, x, y, w, h):
    if face == "up":
        return jit(STEEL_D, 4)
    if face == "down":
        return STEEL_D
    if x in (0, w - 1) or y == 0:
        return STEEL_D
    fill_from = h // 3  # lower two thirds hold seeds
    if y >= fill_from:
        return rng.choice([SEED, SEED_D, SEED_L, SEED])
    return GLASS_HI if x == 1 else None


def pipe(face, x, y, w, h):
    return BRASS if (x + y) % 2 == 0 else BRASS_D


def beacon(face, x, y, w, h):
    return RED_L if face == "up" else RED


def console(face, x, y, w, h):
    if face == "up" and y == 0 and 1 <= x <= w - 2:
        return [RED, GREEN_LED, YELLOW][x % 3]  # buttons
    return jit(TRIM, 3)


# (name, origin, size, painter) - centered block coordinates, y 0..16
PARTS = [
    ("cabinet", [-7, 0, -7], [14, 8, 14], cabinet),
    ("top_plate", [-8, 8, -8], [16, 1, 16], top_plate),
    ("console", [-5, 9, 5], [10, 1, 2], console),
    ("chamber", [-3, 9, -3], [6, 6, 6], chamber),
    ("sprout_x", [-2, 9, 0], [4, 5, 0], sprout),
    ("sprout_z", [0, 9, -2], [0, 5, 4], sprout),
    ("cap", [-4, 15, -4], [8, 1, 8], cap),
    ("beacon", [-1, 16, -1], [2, 1, 2], beacon),
    ("tank_l", [-7, 9, -3], [3, 5, 5], tank),
    ("tank_r", [4, 9, -3], [3, 5, 5], tank),
    ("pipe_l", [-4, 12, -1], [1, 1, 1], pipe),
    ("pipe_r", [3, 12, -1], [1, 1, 1], pipe),
]


def face_sizes(size):
    sx, sy, sz = size
    return {"north": (sx, sy), "south": (sx, sy), "east": (sz, sy), "west": (sz, sy), "up": (sx, sz), "down": (sx, sz)}


def main():
    img = Image.new("RGBA", (TEX, TEX), (0, 0, 0, 0))
    px = img.load()
    cur_x = cur_y = row_h = 0
    cubes = []
    for name, origin, size, painter in PARTS:
        uv = {}
        for face, (w, h) in face_sizes(size).items():
            if w == 0 or h == 0:
                continue
            if cur_x + w > TEX:
                cur_x, cur_y, row_h = 0, cur_y + row_h, 0
            assert cur_y + h <= TEX, "texture atlas full"
            for y in range(h):
                for x in range(w):
                    c = painter(face, x, y, w, h)
                    if c is not None:
                        px[cur_x + x, cur_y + y] = tuple(c[:3]) + ((c[3],) if len(c) == 4 else (255,))
            uv[face] = {"uv": [cur_x, cur_y], "uv_size": [w, h]}
            cur_x += w
            row_h = max(row_h, h)
        cubes.append({"origin": origin, "size": size, "uv": uv})
    img.save(os.path.join(RP, "textures", "blocks", "cc_breeding_station.png"))
    geo = {"format_version": "1.12.0", "minecraft:geometry": [{
        "description": {"identifier": "geometry.cc_breeding_station", "texture_width": TEX, "texture_height": TEX,
                        "visible_bounds_width": 2, "visible_bounds_height": 2, "visible_bounds_offset": [0, 0.5, 0]},
        "bones": [{"name": "station", "pivot": [0, 0, 0], "cubes": cubes}]}]}
    with open(os.path.join(RP, "models", "blocks", "breeding_station.geo.json"), "w", encoding="utf-8") as f:
        json.dump(geo, f, indent=2)
        f.write("\n")
    print(f"breeding station: {len(cubes)} parts, atlas used to row {cur_y + row_h}/{TEX}")


if __name__ == "__main__":
    main()
