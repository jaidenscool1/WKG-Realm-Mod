"""Vape pen oil-level stages (cc:vape_pen_s1..s3), drawn from the full-pen textures.
Icon: the cartridge window (cols 6-9, rows 2-6) drains from the top down.
Held model: the oil slices (uv cols 11-13; 11 sits on the battery side) empty from the mouth end.
Run: python cc_tools/gen_vape_stages.py [preview.png]"""
import os, sys
from PIL import Image

RP = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "development_resource_packs", "WKG_Realm_Pack_RP")
ITEMS = os.path.join(RP, "textures", "items")

GLASS_ICON = (196, 204, 216, 255)
GLASS_ICON_HI = (232, 238, 246, 255)
GLASS_MODEL = [(214, 220, 230, 255), (190, 198, 210, 255), (160, 168, 182, 255)]  # rows 6/7/8 shading

ICON_OIL_ROWS = {1: 4, 2: 3, 3: 1}   # rows of oil left (of 5) per stage
MODEL_OIL = {1: [11, 12], 2: [11], 3: []}  # full oil columns left per stage
MODEL_RESIDUE = {3: 11}              # a half-strength film in the last column


def mix(a, b, t):
    return tuple(round(a[i] * (1 - t) + b[i] * t) for i in range(3)) + (255,)


def icon_stage(full, stage):
    im = full.copy(); px = im.load()
    keep = ICON_OIL_ROWS[stage]
    for y in range(2, 7 - keep):  # the emptied rows at the top of the window
        for x in range(6, 10):
            px[x, y] = GLASS_ICON_HI if x == 6 else GLASS_ICON
    return im


def model_stage(full, stage):
    im = full.copy(); px = im.load()
    for x in (11, 12, 13):
        if x in MODEL_OIL[stage]:
            continue
        for r, y in enumerate((6, 7, 8)):
            oil = px[x, y]
            px[x, y] = mix(oil, GLASS_MODEL[r], 0.55) if MODEL_RESIDUE.get(stage) == x else GLASS_MODEL[r]
    return im


def main():
    icon = Image.open(os.path.join(ITEMS, "cc_vape_pen.png")).convert("RGBA")
    model = Image.open(os.path.join(ITEMS, "cc_vape_pen_model.png")).convert("RGBA")
    out = [icon, model]
    for s in (1, 2, 3):
        i, m = icon_stage(icon, s), model_stage(model, s)
        i.save(os.path.join(ITEMS, f"cc_vape_pen_s{s}.png"))
        m.save(os.path.join(ITEMS, f"cc_vape_pen_model_s{s}.png"))
        out += [i, m]
    if len(sys.argv) > 1:
        sheet = Image.new("RGBA", (4 * 200, 2 * 170), (139, 139, 139, 255))
        for n in range(4):
            sheet.alpha_composite(out[2 * n].resize((160, 160), Image.NEAREST), (n * 200 + 20, 5))
            strip = out[2 * n + 1].crop((2, 6, 16, 9)).resize((14 * 12, 3 * 12), Image.NEAREST)
            sheet.alpha_composite(strip, (n * 200 + 16, 190))
        sheet.save(sys.argv[1])
    print("wrote vape pen stages 1-3")


if __name__ == "__main__":
    main()
