"""Third-person poses for every smokable attachable. All first-person poses were tuned in first person and looked
huge in third person, so the shared controller now plays third-person animations whenever !c.is_first_person.
  - every item is scaled down (SCALE)
  - while taking a hit (and always, for a lit pack) the cigarette/joint/vape sits at the player's mouth
Offsets come from the vanilla player model: rightItem pivot [-6,15,1], mouth about (0, 25.5, -4.5) -> the mouth
is (+6, +10.5, -5.5) from the right hand (mirrored in x for the left hand). Uncalibrated - tune the numbers below.
Run AFTER gen_pack_model.py (it rewrites the controller and attachable animation maps).
Run: python cc_tools/gen_third_person.py"""
import json, os

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
RP = os.path.join(ROOT, "development_resource_packs", "WKG_Realm_Pack_RP")

SCALE = 0.45                  # third-person size vs the current models
HAND = [0, 19, 0]             # root position that puts the model at the hand (as in first person)
MOUTH = [1.5, 11.5, -5.5]     # hand -> mouth, right hand (x flips for the left hand). In-game: [6, 10.5] sat ~4.5 px to
                              # the player's left of the mouth and ~1 px low (the held arm is raised, not hanging)
AT_MOUTH_ROT = [10, 180, 0]   # stick turned to point forward out of the mouth, tipped slightly down

# per family: first-person idle root pose (kept for the in-hand look), extra scale, mouth-end z of the stick model,
# root pivot, and whether it goes to the mouth during a hit
FAMILIES = {
    "stick": {"rot": [-20, 90, 0], "scale": 1.0, "mouth_z": -6, "pivot": [0, 0, 0], "to_mouth": True},
    "vape": {"rot": [0, 0, 0], "scale": 0.667, "mouth_z": -5.25, "pivot": [0, 0, 0], "to_mouth": True},
    "bong": {"rot": [0, 0, 0], "scale": 1.0, "mouth_z": None, "pivot": [11.0, 6.9, 2.6], "to_mouth": False},
    "pack": {"rot": [0, 0, 0], "scale": 1.0, "mouth_z": None, "pivot": [0, 4, 0], "to_mouth": False},
}


# Head-bound cigarette (pack): position relative to the player's head bone. Head pivot is the neck (y 24); the mouth
# is ~1.5 px up and the face is at z -4 (front = -z). Bound bones get the same -24 y as the hand binding, hence +24.
# User-tuned look: hanging from the corner of the mouth (viewer's left facing the player = the player's right, -x)
# with the lit end drooping ~20 degrees.
LIPS = [-1.5, 25.5, -4.5]
DROOP = 20  # lit end hangs down
YAW = 20    # lit end angled toward the viewer's left (the player's right, -x)
LIPS_ROT = [-DROOP, 180 + YAW, 0]  # Bedrock's x rotation runs opposite to the maths convention (fitted: x sign -1)


def lips_pos():
    """Bone position that keeps the stick's mouth end (local (0,0,-6)) on LIPS after droop, turn and scale.
    Rotation order: x first (in the bone's own frame), then y."""
    import math
    d, y = math.radians(DROOP), math.radians(180 + YAW)
    v = [0, 6 * math.sin(d), -6 * math.cos(d)]                                   # droop (maths +DROOP about x)
    v = [v[0] * math.cos(y) + v[2] * math.sin(y), v[1], -v[0] * math.sin(y) + v[2] * math.cos(y)]  # then turn about y
    return [round(LIPS[i] - v[i] * SCALE, 3) for i in range(3)]


def mouth(side):
    return [MOUTH[0] * side, MOUTH[1], MOUTH[2]]


def root_at_mouth(fam, side):
    """Root pose putting the stick's mouth end at the mouth, pointing forward (root pivot 0)."""
    s = SCALE * fam["scale"]
    m = mouth(side)
    # after the 180-degree turn the mouth end (0,0,mouth_z) sits at z = -mouth_z; tilt ignored (~1 px)
    return AT_MOUTH_ROT, [HAND[0] + m[0], HAND[1] + m[1], HAND[2] + m[2] + fam["mouth_z"] * s], [s, s, s]


def held_cig_at_mouth(side):
    """Pack: pose of the child bone cc_pack_held_cig (root scaled about pivot [0,4,0]) with its filter at the mouth."""
    s, pv, m = SCALE, [0, 4, 0], mouth(side)
    filt = [0, 0, 6]  # the joint stick's mouth end (0,0,-6) after the 180-degree turn
    return AT_MOUTH_ROT, [(m[i] - pv[i]) / s + pv[i] - filt[i] for i in range(3)]


def anims():
    out = {}
    for name, fam in FAMILIES.items():
        s = SCALE * fam["scale"]
        in_hand = {"rotation": fam["rot"], "position": HAND, "scale": s}
        for side, suffix in ((1, ""), (-1, "_off")):
            if name == "pack":
                hidden = {"scale": 0}
                base = {"root": in_hand, "cc_pack_cig": {"position": [0, 0, 0], "scale": 1}, "cc_pack_held_cig": hidden,
                        "cc_mouth_cig": hidden}
                lit = {"root": in_hand, "cc_pack_cig": hidden, "cc_pack_held_cig": hidden,
                       "cc_mouth_cig": {"scale": SCALE, "rotation": LIPS_ROT, "position": lips_pos()}}
                out[f"animation.cc.pack.third{suffix}"] = {"loop": True, "bones": base}
                out[f"animation.cc.pack.third_raised{suffix}"] = {"loop": True, "bones": lit}
                out[f"animation.cc.pack.lit_third{suffix}"] = {"loop": True, "bones": lit}
                continue
            out[f"animation.cc.{name}.third{suffix}"] = {"loop": True, "bones": {"root": in_hand}}
            if fam["to_mouth"]:
                rot, pos, sc = root_at_mouth(fam, side)
                raised = {"root": {"rotation": rot, "position": pos, "scale": sc[0]}}
            else:  # bong: stays in hand, tipped a little toward the face
                raised = {"root": {"rotation": [fam["rot"][0] - 25, fam["rot"][1], fam["rot"][2]], "position": HAND, "scale": s}}
            out[f"animation.cc.{name}.third_raised{suffix}"] = {"loop": True, "bones": raised}
    return out


def family_of(desc):
    ident = desc["identifier"]
    if ident.startswith("cc:cigarette_pack"):
        return "pack_lit" if "_lit" in ident else "pack"
    idle = desc["animations"]["idle"]
    return idle.split(".")[2]  # animation.cc.<family>.idle


def main():
    ap = os.path.join(RP, "animations", "cc_smokable_pose.animation.json")
    A = json.load(open(ap, encoding="utf-8"))
    A["animations"].update(anims())
    json.dump(A, open(ap, "w", encoding="utf-8"), indent=2)

    FP_MAIN = "c.is_first_person && c.item_slot == 'main_hand'"
    OFF = "c.is_first_person && c.item_slot == 'off_hand'"
    TP_MAIN = "!c.is_first_person && c.item_slot == 'main_hand'"
    TP_OFF = "!c.is_first_person && c.item_slot != 'main_hand'"
    cp = os.path.join(RP, "animation_controllers", "cc_smokable_pose.animation_controllers.json")
    C = json.load(open(cp, encoding="utf-8"))
    st = C["animation_controllers"]["controller.animation.cc.smokable_pose"]["states"]
    st["idle"]["animations"] = [{"idle": FP_MAIN}, {"offhand_fp": OFF}, {"third": TP_MAIN}, {"third_off": TP_OFF}]
    st["raised"]["animations"] = [{"raised": "c.is_first_person"}, {"third_raised": "!c.is_first_person"}]
    json.dump(C, open(cp, "w", encoding="utf-8"), indent=2)

    n = 0
    for f in os.listdir(os.path.join(RP, "attachables")):
        p = os.path.join(RP, "attachables", f)
        a = json.load(open(p, encoding="utf-8"))
        d = a["minecraft:attachable"]["description"]
        if d.get("animations", {}).get("controller") != "controller.animation.cc.smokable_pose":
            continue
        fam = family_of(d)
        if fam == "pack_lit":
            d["animations"].update({"third": "animation.cc.pack.lit_third", "third_off": "animation.cc.pack.lit_third_off",
                                    "third_raised": "animation.cc.pack.lit_third"})
        else:
            d["animations"].update({"third": f"animation.cc.{fam}.third", "third_off": f"animation.cc.{fam}.third_off",
                                    "third_raised": f"animation.cc.{fam}.third_raised"})
        json.dump(a, open(p, "w", encoding="utf-8"), indent=2)
        n += 1
    print(f"third-person poses for {n} attachables")


if __name__ == "__main__":
    main()
