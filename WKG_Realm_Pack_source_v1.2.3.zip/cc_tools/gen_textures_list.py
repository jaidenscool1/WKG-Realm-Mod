"""Writes RP textures/textures_list.json (the game's texture cache list) from every texture in the RP.
Rerun after adding or removing textures.  Run: python cc_tools/gen_textures_list.py"""
import json, os

RP = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "development_resource_packs", "WKG_Realm_Pack_RP")
TEX = os.path.join(RP, "textures")

paths = []
for root, _dirs, files in os.walk(TEX):
    for f in files:
        name, ext = os.path.splitext(f)
        if ext.lower() in (".png", ".tga"):
            rel = os.path.relpath(os.path.join(root, name), RP).replace("\\", "/")
            paths.append(rel)
paths = sorted(set(paths))
with open(os.path.join(TEX, "textures_list.json"), "w", encoding="utf-8") as fh:
    json.dump(paths, fh, indent=2)
    fh.write("\n")
print(f"textures_list.json: {len(paths)} textures")
