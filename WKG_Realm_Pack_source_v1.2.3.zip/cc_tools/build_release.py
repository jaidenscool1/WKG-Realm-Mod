"""Builds the Realm release: WKG_Realm_Pack_BP.mcpack, WKG_Realm_Pack_RP.mcpack and WKG_Realm_Pack.mcaddon.
Leaves out files the game doesn't use (FD's typescripts/, caches, tool leftovers).

  python cc_tools/build_release.py                 # build from the current versions
  python cc_tools/build_release.py --bump 1.2.0    # first set both packs (and their cross-dependencies) to 1.2.0

Realms cache packs by header version, so bump before every Realm upload. Output goes to com.mojang/releases/."""
import argparse, io, json, os, zipfile

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
PACKS = {
    "BP": os.path.join(ROOT, "development_behavior_packs", "WKG_Realm_Pack_BP"),
    "RP": os.path.join(ROOT, "development_resource_packs", "WKG_Realm_Pack_RP"),
}
SKIP_DIRS = {"typescripts", "__pycache__", ".git", "node_modules"}
SKIP_FILES = {".DS_Store", "Thumbs.db"}


def manifest_path(pack):
    return os.path.join(PACKS[pack], "manifest.json")


def bump(version):
    v = [int(p) for p in version.split(".")]
    manifests = {k: json.load(open(manifest_path(k), encoding="utf-8")) for k in PACKS}
    uuids = {m["header"]["uuid"] for m in manifests.values()}
    for k, m in manifests.items():
        m["header"]["version"] = v
        for dep in m.get("dependencies", []):
            if dep.get("uuid") in uuids:
                dep["version"] = v
        with open(manifest_path(k), "w", encoding="utf-8") as f:
            json.dump(m, f, indent=2)
            f.write("\n")
    print("both packs set to", version)


def pack_bytes(pack):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        base = PACKS[pack]
        for root, dirs, files in os.walk(base):
            dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
            for f in files:
                if f in SKIP_FILES:
                    continue
                full = os.path.join(root, f)
                z.write(full, os.path.relpath(full, base).replace("\\", "/"))
    return buf.getvalue()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--bump", help="new version for both packs, e.g. 1.2.0")
    ap.add_argument("--out", default=os.path.join(ROOT, "releases"))
    args = ap.parse_args()
    if args.bump:
        bump(args.bump)
    version = ".".join(map(str, json.load(open(manifest_path("BP"), encoding="utf-8"))["header"]["version"]))
    os.makedirs(args.out, exist_ok=True)
    packs = {k: pack_bytes(k) for k in PACKS}
    for k, data in packs.items():
        with open(os.path.join(args.out, f"WKG_Realm_Pack_{k}.mcpack"), "wb") as f:
            f.write(data)
    addon = os.path.join(args.out, f"WKG_Realm_Pack_v{version}.mcaddon")
    with zipfile.ZipFile(addon, "w", zipfile.ZIP_STORED) as z:
        for k, data in packs.items():
            z.writestr(f"WKG_Realm_Pack_{k}.mcpack", data)
    for k, data in packs.items():
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            names = z.namelist()
            assert "manifest.json" in names, f"{k}: manifest.json not at zip root"
            assert not any(n.startswith("typescripts/") for n in names), f"{k}: typescripts leaked in"
            print(f"{k}: {len(names)} files, {len(data) / 1e6:.1f} MB")
    print("wrote", os.path.relpath(addon, ROOT))


if __name__ == "__main__":
    main()
