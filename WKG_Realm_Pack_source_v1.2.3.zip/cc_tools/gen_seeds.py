"""Seed icons: a scatter of green kernels (wheat-seed style), a few kernels tipped with the
potion colour of the strain's effects so they read as "still green, with a hint".
Run: python cc_tools/gen_seeds.py [preview.png]"""
import json, os, sys
from PIL import Image

RP = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "development_resource_packs", "WKG_Realm_Pack_RP")
OUT = os.path.join(RP, "textures", "items")

# Effects per strain - keep in sync with STRAINS in scripts/cc_main.js
STRAINS = {
    "og_kush": ["regeneration", "resistance"],
    "blue_dream": ["speed", "absorption"],
    "sour_diesel": ["speed", "haste"],
    "purple_haze": ["slow_falling", "jump_boost"],
    "gorilla_glue": ["strength", "regeneration"],
    "green_crack": ["haste", "speed"],
    "tysgorilla": ["strength"],
    "tender_lad": ["absorption"],
    "purple_nurple": ["regeneration", "health_boost"],
    "white_widow": ["jump_boost", "speed"],
    "purple_punch": ["night_vision", "saturation"],
    "skywalker_og": ["levitation", "fire_resistance"],
    "george_droid": ["water_breathing", "resistance"],
    "sleepy_joe_og": ["blindness", "mining_fatigue", "slow_falling"],
    "black_mamba": ["speed", "haste"],
    "phantom_cookies": ["invisibility"],
    "poseidon_og": ["conduit_power"],
    "hero_haze": ["village_hero"],
}
# Roughly the vanilla potion colours, nudged apart where two would look the same on green.
EFFECT_COLOR = {
    "speed": (124, 211, 240), "haste": (240, 214, 74), "strength": (176, 36, 44),
    "jump_boost": (196, 255, 110), "regeneration": (240, 122, 200), "resistance": (154, 92, 240),
    "fire_resistance": (255, 122, 42), "water_breathing": (58, 110, 240), "night_vision": (48, 48, 176),
    "absorption": (255, 176, 32), "saturation": (200, 118, 60), "levitation": (246, 246, 255),
    "slow_falling": (232, 228, 192), "blindness": (28, 28, 30), "mining_fatigue": (110, 110, 110),
    "health_boost": (255, 64, 64),
    "invisibility": (206, 210, 236), "conduit_power": (29, 194, 209), "village_hero": (32, 230, 120),
}
HYBRID = ["regeneration", "haste", "speed"]  # one item for every hybrid: a mixed "rainbow" hint

# Seed item names: each word of the strain name takes the colour of one of its effects (Bedrock § codes chosen
# to match EFFECT_COLOR above). Written into every .lang file; the items point at the key via minecraft:display_name.
NAMES = {
    "og_kush": "OG Kush", "blue_dream": "Blue Dream", "sour_diesel": "Sour Diesel", "purple_haze": "Purple Haze",
    "gorilla_glue": "Gorilla Glue", "green_crack": "Green Crack", "tysgorilla": "Tysgorilla", "tender_lad": "Tender Lad",
    "purple_nurple": "Purple Nurple", "white_widow": "White Widow", "purple_punch": "Purple Punch",
    "skywalker_og": "Skywalker OG", "george_droid": "George Droid", "sleepy_joe_og": "Sleepy Joe OG",
    "black_mamba": "Black Mamba", "phantom_cookies": "Phantom Cookies", "poseidon_og": "Poseidon OG",
    "hero_haze": "Hero Haze",
}
EFFECT_CODE = {
    # bright shades only - the item tooltip is dark, so dark red/blue/gray codes are unreadable
    "speed": "§b", "haste": "§e", "strength": "§c", "jump_boost": "§a", "regeneration": "§d", "resistance": "§u",
    "fire_resistance": "§6", "water_breathing": "§s", "night_vision": "§9", "absorption": "§g", "saturation": "§n",
    "levitation": "§f", "slow_falling": "§h", "blindness": "§7", "mining_fatigue": "§n", "health_boost": "§p",
    "invisibility": "§i", "conduit_power": "§3", "village_hero": "§q",
}
LANG_DIR = os.path.join(RP, "texts")
BP_ITEMS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "development_behavior_packs",
                        "WKG_Realm_Pack_BP", "items")


def colored_name(key):
    words, effects = NAMES[key].split(" "), STRAINS[key]
    return " ".join(EFFECT_CODE[effects[i % len(effects)]] + w for i, w in enumerate(words)) + "§r Seeds"


def write_names():
    lines = {f"item.cc:seed_{k}.name": colored_name(k) for k in STRAINS}
    for f in os.listdir(LANG_DIR):
        if not f.endswith(".lang"):
            continue
        path = os.path.join(LANG_DIR, f)
        text = open(path, encoding="utf-8", newline="").read()
        out, seen = [], set()
        for line in text.splitlines(keepends=True):
            key = line.split("=", 1)[0]
            if key in lines:
                end = "\r\n" if line.endswith("\r\n") else "\n"
                out.append(f"{key}={lines[key]}{end}")
                seen.add(key)
            else:
                out.append(line)
        if out and not out[-1].endswith("\n"):
            out[-1] += "\n"
        out += [f"{k}={v}\n" for k, v in lines.items() if k not in seen]
        open(path, "w", encoding="utf-8", newline="").write("".join(out))
    # explicit localization key on each seed item (the default lookup showed the raw key in-game)
    for k in list(STRAINS) + ["hybrid"]:
        path = os.path.join(BP_ITEMS, f"seed_{k}.json")
        data = json.load(open(path, encoding="utf-8"))
        data["minecraft:item"]["components"]["minecraft:display_name"] = {"value": f"item.cc:seed_{k}.name"}
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2)
            fh.write("\n")

OUTLINE = (36, 64, 22)
BODY = (84, 150, 44)
LIGHT = (140, 205, 84)
SHADE = (60, 112, 32)

# Kernel top-left corners (each kernel is 2x3 with an outline), laid out like a handful of seeds.
KERNELS = [(3, 2), (8, 1), (11, 5), (5, 6), (1, 9), (8, 9), (12, 11), (4, 12)]
ACCENT_KERNELS = [1, 3, 6, 4]  # which kernels get tipped, in order of the strain's effects


def mix(a, b, t):
    return tuple(round(a[i] * (1 - t) + b[i] * t) for i in range(3))


def kernel(px, x, y, accent=None):
    # outline ring around a 2x3 body
    for dx in range(-1, 3):
        for dy in range(-1, 4):
            inside = 0 <= dx < 2 and 0 <= dy < 3
            corner = dx in (-1, 2) and dy in (-1, 3)
            if not inside and not corner:
                px[x + dx, y + dy] = OUTLINE + (255,)
    px[x, y] = LIGHT + (255,)
    px[x + 1, y] = BODY + (255,)
    px[x, y + 1] = BODY + (255,)
    px[x + 1, y + 1] = BODY + (255,)
    px[x, y + 2] = BODY + (255,)
    px[x + 1, y + 2] = SHADE + (255,)
    if accent:
        px[x, y] = mix(accent, (255, 255, 255), 0.15) + (255,)
        px[x + 1, y] = accent + (255,)
        px[x, y + 1] = mix(BODY, accent, 0.45) + (255,)


def seed_icon(effects):
    im = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    px = im.load()
    accents = {}
    for i, eff in enumerate(effects):
        accents[ACCENT_KERNELS[i]] = EFFECT_COLOR[eff]
    if len(effects) == 1:  # one effect: tip a second kernel so the hint still shows
        accents[ACCENT_KERNELS[2]] = EFFECT_COLOR[effects[0]]
    for k, (x, y) in enumerate(KERNELS):
        kernel(px, x, y, accents.get(k))
    return im


def main():
    icons = {f"cc_seed_{k}": seed_icon(v) for k, v in STRAINS.items()}
    icons["cc_seed_hybrid"] = seed_icon(HYBRID)
    for name, im in icons.items():
        im.save(os.path.join(OUT, name + ".png"))
    write_names()
    if len(sys.argv) > 1:
        sheet = Image.new("RGBA", (len(icons) * 100, 120), (139, 139, 139, 255))
        for i, (name, im) in enumerate(icons.items()):
            sheet.alpha_composite(im.resize((96, 96), Image.NEAREST), (i * 100 + 2, 2))
        sheet.save(sys.argv[1])
    print(f"wrote {len(icons)} seed icons")


if __name__ == "__main__":
    main()
