// Deep consistency audit of the WKG Realm Pack (both packs). Run: node cc_tools/audit.js
// Checks JSON syntax, manifests, every cross-file reference (icons, textures, geometry, animations, attachables,
// lang keys, recipes, loot, trades, entities), Bedrock limits (selection boxes, lore-free recipe unlock rules,
// UV bounds) and Realm rules (stable script modules only). Exit code 1 if any ERROR.
const fs = require("fs"), path = require("path");
const ROOT = path.join(__dirname, "..");
const BP = path.join(ROOT, "development_behavior_packs", "WKG_Realm_Pack_BP");
const RP = path.join(ROOT, "development_resource_packs", "WKG_Realm_Pack_RP");
const errors = [], warns = [];
const err = (m) => errors.push(m), warn = (m) => warns.push(m);
const rel = (p) => path.relative(ROOT, p).replace(/\\/g, "/");

function walk(dir, out = []) {
  for (const f of fs.readdirSync(dir)) {
    const p = path.join(dir, f);
    if (fs.statSync(p).isDirectory()) { if (!["typescripts", "node_modules"].includes(f)) walk(p, out); }
    else out.push(p);
  }
  return out;
}
const lenient = (t) => t.replace(/^﻿/, "").replace(/\/\/[^\n"]*$/gm, "").replace(/\/\*[\s\S]*?\*\//g, "").replace(/,(\s*[}\]])/g, "$1");
function readJson(p) {
  const t = fs.readFileSync(p, "utf8");
  try { return JSON.parse(t.replace(/^﻿/, "")); }
  catch (e) {
    try { const v = JSON.parse(lenient(t)); warn(`${rel(p)}: not strict JSON (comments/trailing commas) - the game tolerates it`); return v; }
    catch (e2) { err(`${rel(p)}: invalid JSON (${e2.message})`); return null; }
  }
}
const texExists = (p) => [".png", ".tga", ".jpg"].some((e) => fs.existsSync(path.join(RP, p + e)));

// ---------- 1. JSON syntax ----------
const bpFiles = walk(BP), rpFiles = walk(RP);
const J = new Map();
for (const p of [...bpFiles, ...rpFiles].filter((p) => p.endsWith(".json"))) J.set(p, readJson(p));
const jsonIn = (base, sub) => [...J.entries()].filter(([p, v]) => v && p.startsWith(path.join(base, sub) + path.sep));

// ---------- 2. manifests ----------
const mBP = J.get(path.join(BP, "manifest.json")), mRP = J.get(path.join(RP, "manifest.json"));
const uuids = new Set();
for (const [name, m] of [["BP", mBP], ["RP", mRP]]) {
  for (const u of [m.header.uuid, ...m.modules.map((x) => x.uuid)]) { if (uuids.has(u)) err(`${name} manifest: duplicate uuid ${u}`); uuids.add(u); }
}
const dep = (m, uuid) => (m.dependencies || []).find((d) => d.uuid === uuid);
if (!dep(mBP, mRP.header.uuid)) err("BP manifest doesn't depend on the RP");
else if (String(dep(mBP, mRP.header.uuid).version) !== String(mRP.header.version)) err("BP -> RP dependency version != RP version");
if (dep(mRP, mBP.header.uuid) && String(dep(mRP, mBP.header.uuid).version) !== String(mBP.header.version)) err("RP -> BP dependency version != BP version");
if (String(mBP.header.version) !== String(mRP.header.version)) warn("BP and RP header versions differ");
for (const d of mBP.dependencies.filter((d) => d.module_name)) {
  if (/beta|rc|preview|internal/.test(d.version)) err(`script module ${d.module_name} ${d.version} is not stable (Realms need stable)`);
  if (["@minecraft/server-net", "@minecraft/server-admin", "@minecraft/server-gametest", "@minecraft/debug-utilities"].includes(d.module_name))
    err(`${d.module_name} isn't available on Realms`);
}
const scriptModule = mBP.modules.find((m) => m.type === "script");
if (!scriptModule || !fs.existsSync(path.join(BP, scriptModule.entry))) err("BP script entry missing");

// ---------- 3. scripts: imports resolve, only stable module names ----------
for (const p of bpFiles.filter((p) => p.endsWith(".js") && p.includes(`${path.sep}scripts${path.sep}`))) {
  const src = fs.readFileSync(p, "utf8");
  for (const m of src.matchAll(/(?:import|export)[^;]*?from\s+["']([^"']+)["']|import\s+["']([^"']+)["']/g)) {
    const spec = m[1] || m[2];
    if (spec.startsWith(".")) {
      const base = path.resolve(path.dirname(p), spec);
      // Bedrock resolves extension-less imports (FD relies on it)
      if (![base, base + ".js"].some((f) => fs.existsSync(f) && fs.statSync(f).isFile())) err(`${rel(p)}: import ${spec} not found`);
    }
    else if (!mBP.dependencies.some((d) => d.module_name === spec) && spec !== "@minecraft/common") err(`${rel(p)}: imports ${spec} without a manifest dependency`);
  }
}

// ---------- 4. RP registries ----------
const itemTex = J.get(path.join(RP, "textures", "item_texture.json")).texture_data;
const terrainTex = J.get(path.join(RP, "textures", "terrain_texture.json")).texture_data;
for (const [k, v] of Object.entries(itemTex)) for (const t of [].concat(v.textures)) if (typeof t === "string" && !texExists(t)) (k.startsWith("cc:") ? err : warn)(`item_texture ${k} -> missing ${t}`);
for (const [k, v] of Object.entries(terrainTex)) for (const t of [].concat(v.textures)) if (typeof t === "string" && !texExists(t)) (k.startsWith("cc") ? err : warn)(`terrain_texture ${k} -> missing ${t}`);
const geos = new Map();
for (const [p, v] of jsonIn(RP, "models")) for (const g of v["minecraft:geometry"] || []) geos.set(g.description.identifier, { p, g });
const anims = new Set(), controllers = new Set();
for (const [, v] of jsonIn(RP, "animations")) for (const k of Object.keys(v.animations || {})) anims.add(k);
for (const [, v] of jsonIn(RP, "animation_controllers")) for (const k of Object.keys(v.animation_controllers || {})) controllers.add(k);
const renderCtl = new Set(["controller.render.item_default", "controller.render.default"]);
for (const [, v] of jsonIn(RP, "render_controllers")) for (const k of Object.keys(v.render_controllers || {})) renderCtl.add(k);
const langs = fs.readdirSync(path.join(RP, "texts")).filter((f) => f.endsWith(".lang")).map((f) => [f, fs.readFileSync(path.join(RP, "texts", f), "utf8")]);
const langHas = (key) => langs.filter(([, t]) => !new RegExp("^" + key.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "=", "m").test(t)).map(([f]) => f);

// geometry UVs inside the texture
for (const [id, { p, g }] of geos) {
  if (!id.startsWith("geometry.cc")) continue;
  const { texture_width: tw, texture_height: th } = g.description;
  for (const b of g.bones || []) for (const c of b.cubes || []) {
    if (Array.isArray(c.uv)) continue;
    for (const [face, f] of Object.entries(c.uv || {})) {
      const [u, v] = f.uv, [w, h] = f.uv_size;
      if (u < 0 || v < 0 || u + Math.max(w, 0) > tw || v + Math.max(h, 0) > th) err(`${id} bone ${b.name} ${face} UV outside the ${tw}x${th} texture`);
    }
  }
}

// ---------- 5. items ----------
const itemIds = new Set(), blockIds = new Set(), entityIds = new Set();
for (const [p, v] of jsonIn(BP, "items")) {
  const it = v["minecraft:item"]; if (!it) continue;
  const id = it.description.identifier; itemIds.add(id);
  if (!id.startsWith("cc:")) continue;
  const c = it.components || {};
  const icon = c["minecraft:icon"];
  const iconKey = typeof icon === "string" ? icon : icon?.texture ?? icon?.textures?.default;
  if (!iconKey || !itemTex[iconKey]) err(`${id}: icon '${iconKey}' not in item_texture.json`);
  const dn = c["minecraft:display_name"]?.value;
  if (!dn) err(`${id}: no minecraft:display_name`); else { const miss = langHas(dn); if (miss.length) err(`${id}: lang key ${dn} missing in ${miss.join(",")}`); }
  if (typeof c["minecraft:food"]?.saturation_modifier === "string") err(`${id}: string saturation_modifier`);
  if (c["minecraft:durability"] && (c["minecraft:max_stack_size"] ?? 64) !== 1) err(`${id}: durability needs max_stack_size 1`);
  const bp = c["minecraft:block_placer"]; if (bp) blockIds.has(bp.block) || (bp.__check = true);
}

// ---------- 6. blocks ----------
for (const [p, v] of jsonIn(BP, "blocks")) {
  const b = v["minecraft:block"]; if (!b) continue;
  const id = b.description.identifier; blockIds.add(id);
  if (!id.startsWith("cc:")) continue;
  const all = [b.components, ...(b.permutations || []).map((x) => x.components)];
  const dn = b.components["minecraft:display_name"];
  if (!dn) err(`${id}: no minecraft:display_name`); else { const miss = langHas(dn); if (miss.length) err(`${id}: lang key ${dn} missing in ${miss.join(",")}`); }
  for (const c of all) {
    const g = c["minecraft:geometry"]; const gid = typeof g === "string" ? g : g?.identifier;
    if (gid && !gid.startsWith("minecraft:") && !geos.has(gid)) err(`${id}: geometry ${gid} not found`);
    const mi = c["minecraft:material_instances"];
    if (mi) for (const [face, m] of Object.entries(mi)) if (typeof m === "object" && m.texture && !terrainTex[m.texture]) err(`${id}: material ${face} texture ${m.texture} not in terrain_texture.json`);
    for (const k of ["minecraft:selection_box", "minecraft:collision_box"]) {
      const bx = c[k]; if (!bx || typeof bx !== "object" || Array.isArray(bx)) continue;
      const maxY = k === "minecraft:selection_box" ? 16 : 24;
      if (bx.origin[0] < -8 || bx.origin[2] < -8 || bx.origin[1] < 0 || bx.origin[0] + bx.size[0] > 8 || bx.origin[2] + bx.size[2] > 8 || bx.origin[1] + bx.size[1] > maxY)
        err(`${id}: ${k} outside the allowed box (y max ${maxY})`);
    }
    const loot = c["minecraft:loot"]; if (loot && !fs.existsSync(path.join(BP, loot))) err(`${id}: loot table ${loot} missing`);
  }
}
for (const [p, v] of jsonIn(BP, "items")) {
  const bp = v["minecraft:item"]?.components?.["minecraft:block_placer"];
  if (bp && !blockIds.has(bp.block) && !bp.block.startsWith("minecraft:")) err(`${v["minecraft:item"].description.identifier}: places unknown block ${bp.block}`);
}

// ---------- 7. entities (BP + RP) ----------
for (const [p, v] of jsonIn(BP, "entities")) {
  const e = v["minecraft:entity"]; if (!e) continue;
  entityIds.add(e.description.identifier);
  const s = JSON.stringify(e);
  for (const m of s.matchAll(/"table":"([^"]+)"/g)) if (!fs.existsSync(path.join(BP, m[1]))) err(`${e.description.identifier}: trade table ${m[1]} missing`);
  for (const m of s.matchAll(/"minecraft:loot":\{"table":"([^"]+)"/g)) if (!fs.existsSync(path.join(BP, m[1]))) err(`${e.description.identifier}: loot ${m[1]} missing`);
}
for (const [p, v] of jsonIn(RP, "entity")) {
  const d = v["minecraft:client_entity"]?.description; if (!d || !d.identifier.startsWith("cc:")) continue;
  for (const t of Object.values(d.textures || {})) if (!texExists(t)) err(`${d.identifier}: texture ${t} missing`);
  for (const g of Object.values(d.geometry || {})) if (!geos.has(g)) err(`${d.identifier}: geometry ${g} missing`);
  for (const a of Object.values(d.animations || {})) if (!anims.has(a) && !controllers.has(a)) err(`${d.identifier}: animation ${a} missing`);
  for (const r of d.render_controllers || []) if (typeof r === "string" && !renderCtl.has(r)) err(`${d.identifier}: render controller ${r} missing`);
  if (!entityIds.has(d.identifier)) err(`${d.identifier}: client entity without a BP entity`);
  const miss = langHas(`entity.${d.identifier}.name`); if (miss.length) err(`${d.identifier}: entity name missing in ${miss.join(",")}`);
}

// ---------- 8. attachables ----------
for (const [p, v] of jsonIn(RP, "attachables")) {
  const d = v["minecraft:attachable"]?.description; if (!d || !d.identifier.startsWith("cc:")) continue;
  if (!itemIds.has(d.identifier)) err(`attachable ${d.identifier}: no such item`);
  for (const t of Object.values(d.textures || {})) if (!texExists(t)) err(`attachable ${d.identifier}: texture ${t} missing`);
  const bones = new Set();
  for (const g of Object.values(d.geometry || {})) { if (!geos.has(g)) err(`attachable ${d.identifier}: geometry ${g} missing`); else for (const b of geos.get(g).g.bones) bones.add(b.name); }
  for (const [k, a] of Object.entries(d.animations || {})) {
    if (!anims.has(a) && !controllers.has(a)) { err(`attachable ${d.identifier}: ${k} -> ${a} missing`); continue; }
    for (const [, av] of jsonIn(RP, "animations")) {
      const def = av.animations?.[a];
      if (def) for (const bone of Object.keys(def.bones || {})) if (!bones.has(bone)) err(`attachable ${d.identifier}: ${a} animates missing bone ${bone}`);
    }
  }
  const ctl = d.animations?.controller;
  if (ctl) for (const [, cv] of jsonIn(RP, "animation_controllers")) {
    const c = cv.animation_controllers?.[ctl]; if (!c) continue;
    for (const st of Object.values(c.states)) for (const a of st.animations || []) for (const key of typeof a === "string" ? [a] : Object.keys(a))
      if (!d.animations[key]) err(`attachable ${d.identifier}: controller wants '${key}'`);
  }
}

// ---------- 9. recipes, trades, loot ----------
const known = (id) => id.startsWith("minecraft:") || itemIds.has(id) || blockIds.has(id);
for (const [p, v] of jsonIn(BP, "recipes")) {
  const k = Object.keys(v).find((k) => k.startsWith("minecraft:recipe")); if (!k) continue;
  const r = v[k], fv = v.format_version;
  const ids = JSON.stringify(r).match(/"item":"([^"]+)"/g)?.map((m) => m.slice(8, -1)) ?? [];
  for (const id of ids) if (!known(id)) err(`${rel(p)}: unknown item ${id}`);
  if (fv >= "1.20" && !r.unlock && k !== "minecraft:recipe_furnace" && !k.startsWith("minecraft:recipe_brewing")) err(`${rel(p)}: format ${fv} recipe without unlock`);
}
for (const [p, v] of jsonIn(BP, "trading")) for (const m of JSON.stringify(v).matchAll(/"item":"([^"]+)"/g)) if (!known(m[1])) err(`${rel(p)}: unknown item ${m[1]}`);
for (const [p, v] of jsonIn(BP, "loot_tables")) for (const m of JSON.stringify(v).matchAll(/"name":"([^"]+)"/g))
  if (m[1].includes(":") && !known(m[1])) (m[1].startsWith("cc:") || m[1].startsWith("farmersdelight:") ? err : warn)(`${rel(p)}: item ${m[1]} not in this pack (compat table for another add-on)`);

// ---------- 10. script-referenced ids exist ----------
const main = fs.readFileSync(path.join(BP, "scripts", "cc_main.js"), "utf8");
for (const m of new Set(main.match(/"cc:[a-z0-9_]*[a-z0-9]"/g))) {
  const id = m.slice(1, -1);
  if (["cc:crop", "cc:genetics", "cc:nutrients", "cc:growth", "cc:tint", "cc:plate", "cc:pressing", "cc:status", "cc:smoke", "cc:uses",
       "cc:smoke_stage", "cc:village", "cc:guide_given", "cc:racks", "cc:stills", "cc:funguy_villages", "cc:funguy_next_wander",
       "cc:as_wanderer", "cc:genetics_marker"].includes(id)) continue;
  if (!itemIds.has(id) && !blockIds.has(id) && !entityIds.has(id)) err(`cc_main.js references ${id}, which isn't an item/block/entity`);
}

// ---------- 11. size ----------
const size = (files) => files.reduce((s, f) => s + fs.statSync(f).size, 0);
const bpSize = size(bpFiles), rpSize = size(rpFiles);

console.log(`Checked ${J.size} JSON files, ${itemIds.size} items, ${blockIds.size} blocks, ${entityIds.size} entities, ${geos.size} geometries, ${anims.size} animations`);
console.log(`Pack sizes (without typescripts): BP ${(bpSize / 1e6).toFixed(1)} MB, RP ${(rpSize / 1e6).toFixed(1)} MB`);
console.log(`Manifests: v${mBP.header.version.join(".")}, min_engine ${mBP.header.min_engine_version.join(".")}, modules ${mBP.dependencies.filter((d) => d.module_name).map((d) => d.module_name + " " + d.version).join(", ")}`);
for (const w of warns) console.log("WARN  " + w);
for (const e of errors) console.log("ERROR " + e);
console.log(errors.length ? `\n${errors.length} ERROR(S)` : "\nNo errors.");
process.exit(errors.length ? 1 : 0);
