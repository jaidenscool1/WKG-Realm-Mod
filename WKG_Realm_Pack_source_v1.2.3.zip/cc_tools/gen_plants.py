"""Cannabis + tobacco crop textures (drawn in code) and the tall 4-plane crop geometry.
Cannabis: stages 0-2 shared (16x16), stages 3-4 per strain tint group (16x24, tall geometry).
Tobacco:  stages 0-1 (16x16), stages 2-3 (16x24, tall geometry).
Run: python cc_tools/gen_plants.py [preview.png]"""
import json, math, os, random, sys
from PIL import Image

RP = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "development_resource_packs", "WKG_Realm_Pack_RP")
BLOCKS = os.path.join(RP, "textures", "blocks")
TALL_H = 24

# tint group -> (leaf, leaf_dark, leaf_light, bud, bud_dark, pistil, frost amount 0..1)
TINTS = [
    ("green", (58, 124, 44), (36, 88, 30), (98, 162, 62), (132, 178, 84), (92, 136, 58), (222, 124, 44), 0.25),
    ("purple", (62, 110, 52), (42, 76, 40), (96, 146, 70), (128, 78, 150), (86, 50, 112), (230, 150, 70), 0.3),
    ("frosty", (66, 132, 70), (42, 96, 50), (110, 170, 104), (186, 206, 180), (140, 170, 140), (236, 170, 110), 0.7),
    ("dark", (34, 78, 34), (20, 52, 24), (58, 104, 48), (64, 88, 56), (46, 58, 50), (196, 108, 50), 0.2),
    ("golden", (92, 134, 42), (64, 100, 32), (138, 172, 64), (196, 184, 86), (150, 140, 58), (240, 164, 40), 0.25),
    ("red", (60, 120, 44), (38, 86, 30), (100, 158, 62), (172, 84, 70), (122, 54, 48), (206, 58, 44), 0.25),
]
STEM = (78, 118, 46)
STEM_DARK = (56, 90, 36)
FROST = (236, 240, 232)


def new(h=16):
    return Image.new("RGBA", (16, h), (0, 0, 0, 0))


def put(px, x, y, c, w, h):
    if 0 <= x < w and 0 <= y < h:
        px[x, y] = tuple(c) + (255,)


def line(px, x0, y0, x1, y1, c, w, h):
    n = max(abs(x1 - x0), abs(y1 - y0), 1)
    for i in range(n + 1):
        put(px, round(x0 + (x1 - x0) * i / n), round(y0 + (y1 - y0) * i / n), c, w, h)


def fan_leaf(px, x, y, size, side, pal, w, h, fingers=5):
    """Palmate cannabis fan leaf growing from node (x, y): a short stalk out to the side, then fingers spread in a
    wide fan around that direction (middle finger longest). side -1 = left, +1 = right, 0 = straight up."""
    leaf, dark, light = pal
    direction = -90 if side == 0 else (-160 if side < 0 else -20)  # degrees; 0 = right, -90 = up
    stalk = 0 if side == 0 else (1 if size < 4 else 2)
    cx = x + round(math.cos(math.radians(direction)) * stalk)
    cy = y + round(math.sin(math.radians(direction)) * stalk)
    line(px, x, y, cx, cy, STEM, w, h)
    spread = 170 if fingers >= 5 else 120
    for i in range(fingers):
        t = i / (fingers - 1) if fingers > 1 else 0.5
        ang = math.radians(direction - spread / 2 + spread * t)
        mid = 1 - abs(t - 0.5) * 2  # 1 for the middle finger, 0 for the outer ones
        length = size * (0.45 + 0.55 * mid)
        ex, ey = cx + math.cos(ang) * length, cy + math.sin(ang) * length
        line(px, cx, cy, round(ex), round(ey), leaf, w, h)
        nx, ny = -math.sin(ang), math.cos(ang)
        for s in range(1, max(2, int(length))):
            sx, sy = cx + math.cos(ang) * s, cy + math.sin(ang) * s
            if length >= 4 and 1 < s < length - 1:  # fatter middle of long fingers
                put(px, round(sx + nx * 0.8), round(sy + ny * 0.8), dark, w, h)
            if s % 2 == 1:  # serration highlights
                put(px, round(sx - nx), round(sy - ny), light, w, h)
    put(px, cx, cy, dark, w, h)


def stem(px, x, y0, y1, w, h, thick_until=None):
    for y in range(y1, y0 + 1):
        put(px, x, y, STEM, w, h)
        if thick_until is not None and y >= thick_until:
            put(px, x + 1, y, STEM_DARK, w, h)


def bud(px, cx, cy, rw, rh, t, w, h, rng):
    """A bud cluster: bumpy blob with pistil hairs and frost specks."""
    _, _, _, b, bd, pistil, frost = t[1:]
    for yy in range(-rh, rh + 1):
        for xx in range(-rw, rw + 1):
            if (xx / (rw + 0.5)) ** 2 + (yy / (rh + 0.5)) ** 2 <= 1.0 and rng.random() > 0.06:
                put(px, cx + xx, cy + yy, bd if (xx + yy) % 3 == 0 else b, w, h)
    for _ in range(max(2, rw * rh)):
        put(px, cx + rng.randint(-rw, rw), cy + rng.randint(-rh, rh), pistil, w, h)
    for _ in range(int((rw * rh + 2) * frost * 2)):
        put(px, cx + rng.randint(-rw, rw), cy + rng.randint(-rh, rh), FROST, w, h)


def cannabis(stage, t=TINTS[0]):
    rng = random.Random(100 + stage)
    pal = t[1:4]
    if stage == 0:
        im = new(); px = im.load(); w, h = 16, 16
        stem(px, 8, 15, 12, w, h)
        for dx in (-2, -1, 1, 2):  # round cotyledons
            put(px, 8 + dx, 12, pal[0], w, h)
        put(px, 6, 11, pal[2], w, h); put(px, 10, 11, pal[2], w, h)
        fan_leaf(px, 8, 11, 2, 0, pal, w, h, fingers=3)
        return im
    if stage == 1:
        im = new(); px = im.load(); w, h = 16, 16
        stem(px, 8, 15, 8, w, h)
        fan_leaf(px, 8, 12, 3, -1, pal, w, h, fingers=3)
        fan_leaf(px, 8, 12, 3, 1, pal, w, h, fingers=3)
        fan_leaf(px, 8, 8, 3, 0, pal, w, h, fingers=5)
        return im
    if stage == 2:
        im = new(); px = im.load(); w, h = 16, 16
        stem(px, 8, 15, 3, w, h, thick_until=12)
        for y, size in ((13, 5), (9, 4)):
            fan_leaf(px, 8, y, size, -1, pal, w, h, fingers=5)
            fan_leaf(px, 8, y, size, 1, pal, w, h, fingers=5)
        fan_leaf(px, 8, 5, 4, 0, pal, w, h, fingers=5)
        return im
    # tall stages (16x24): 3 = pre-flower, 4 = flowering
    im = new(TALL_H); px = im.load(); w, h = 16, TALL_H
    top = 3 if stage == 4 else 4
    stem(px, 8, h - 1, top, w, h, thick_until=h - 8)
    nodes = [(h - 4, 6), (h - 9, 5), (h - 14, 5), (h - 18, 4)]
    for y, size in nodes:
        fan_leaf(px, 8, y, size, -1, pal, w, h, fingers=7 if size >= 5 else 5)
        fan_leaf(px, 8, y, size, 1, pal, w, h, fingers=7 if size >= 5 else 5)
    if stage == 3:
        fan_leaf(px, 8, top + 2, 3, 0, pal, w, h, fingers=5)
        for y, _ in nodes[1:]:  # first white pistils at the nodes and tip
            put(px, 7, y - 1, (240, 238, 226), w, h); put(px, 9, y - 1, (240, 238, 226), w, h)
        put(px, 8, top, (240, 238, 226), w, h)
        return im
    # flowering: main cola on top, side buds at the upper nodes, a few yellowing fan leaf tips
    bud(px, 8, top + 3, 2, 3, t, w, h, rng)
    for y, _ in nodes[1:3]:
        bud(px, 5, y - 1, 1, 1, t, w, h, rng)
        bud(px, 11, y - 1, 1, 1, t, w, h, rng)
    for _ in range(4):
        x, y = rng.randint(1, 14), rng.randint(h - 8, h - 2)
        if px[x, y][3]:
            put(px, x, y, (170, 168, 60), w, h)
    return im


TOB_LEAF, TOB_DARK, TOB_LIGHT = (104, 150, 62), (72, 116, 44), (146, 186, 88)
TOB_FLOWER, TOB_FLOWER_DARK = (238, 146, 178), (206, 104, 146)


def tobacco_leaf(px, x, y, length, width, side, w, h):
    """Broad oval tobacco leaf with a pale midrib, pointing out to `side` and slightly up."""
    for i in range(length):
        t = i / max(1, length - 1)
        half = max(0, round(math.sin(math.pi * min(1, t * 1.1)) * width))
        cx = x + side * i
        cy = y - round(i * 0.35)
        for d in range(-half, half + 1):
            put(px, cx, cy + d, TOB_DARK if d == half else TOB_LEAF, w, h)
        put(px, cx, cy, TOB_LIGHT, w, h)  # midrib


def tobacco(stage):
    if stage < 2:
        im = new(); px = im.load(); w, h = 16, 16
        if stage == 0:
            put(px, 8, 15, STEM, w, h); put(px, 8, 14, STEM, w, h)
            tobacco_leaf(px, 7, 13, 3, 1, -1, w, h); tobacco_leaf(px, 9, 13, 3, 1, 1, w, h)
        else:
            stem(px, 8, 15, 10, w, h)
            tobacco_leaf(px, 7, 13, 6, 2, -1, w, h); tobacco_leaf(px, 9, 13, 6, 2, 1, w, h)
            tobacco_leaf(px, 8, 10, 4, 1, 0, w, h)
        return im
    im = new(TALL_H); px = im.load(); w, h = 16, TALL_H
    top = 4 if stage == 3 else 7
    stem(px, 8, h - 1, top, w, h, thick_until=h - 10)
    for y, length, width in ((h - 3, 8, 3), (h - 8, 7, 2), (h - 13, 5, 2)):
        tobacco_leaf(px, 7, y, length, width, -1, w, h)
        tobacco_leaf(px, 9, y, length, width, 1, w, h)
    if stage == 3:  # pink trumpet flowers on top
        for fx, fy in ((6, top), (8, top - 2), (10, top), (7, top + 2), (9, top + 1)):
            put(px, fx, fy, TOB_FLOWER, w, h)
            put(px, fx, fy + 1, TOB_FLOWER_DARK, w, h)
            put(px, fx, fy + 2, TOB_LIGHT, w, h)
    else:
        tobacco_leaf(px, 8, top + 3, 3, 1, 0, w, h)
    return im


def tall_geometry():
    """4 crossed planes (straight + diagonal), 16 wide x 24 tall, centered on the block."""
    def plane(name, rot):
        return {"name": name, "pivot": [0, 0, 0], "rotation": [0, rot, 0], "cubes": [{
            "origin": [-8, 0, 0], "size": [16, TALL_H, 0],
            "uv": {"north": {"uv": [0, 0], "uv_size": [16, TALL_H]}, "south": {"uv": [0, 0], "uv_size": [16, TALL_H]}}}]}
    return {"format_version": "1.12.0", "minecraft:geometry": [{
        "description": {"identifier": "geometry.cc_plant_tall", "texture_width": 16, "texture_height": TALL_H,
                        "visible_bounds_width": 2, "visible_bounds_height": 3, "visible_bounds_offset": [0, 1, 0]},
        "bones": [plane("plane_a", 0), plane("plane_b", 90), plane("plane_c", 45), plane("plane_d", -45)]}]}


def main():
    out = {}
    for s in range(3):
        out[f"cc_plant_{s}"] = cannabis(s)
    for i, t in enumerate(TINTS):
        for s in (3, 4):
            out[f"cc_plant_{s}_{t[0]}"] = cannabis(s, t)
    for s in range(4):
        out[f"cc_tobacco_{s}"] = tobacco(s)
    for name, im in out.items():
        im.save(os.path.join(BLOCKS, name + ".png"))
    with open(os.path.join(RP, "models", "blocks", "cc_plant_tall.geo.json"), "w", encoding="utf-8") as f:
        json.dump(tall_geometry(), f, indent=2)
        f.write("\n")
    if len(sys.argv) > 1:
        S = 6
        order = ([f"cc_plant_{s}" for s in range(3)] + [f"cc_plant_3_{t[0]}" for t in TINTS[:1]] +
                 [f"cc_plant_4_{t[0]}" for t in TINTS] + [f"cc_tobacco_{s}" for s in range(4)])
        sheet = Image.new("RGBA", (len(order) * (16 * S + 8) + 8, TALL_H * S + 16), (120, 160, 210, 255))
        x = 8
        for name in order:
            im = out[name]
            sheet.alpha_composite(im.resize((16 * S, im.height * S), Image.NEAREST), (x, 8 + (TALL_H - im.height) * S))
            x += 16 * S + 8
        sheet.save(sys.argv[1])
    print(f"wrote {len(out)} crop textures + geometry.cc_plant_tall")


if __name__ == "__main__":
    main()
