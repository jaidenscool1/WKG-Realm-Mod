"""Tobacco products: dried tobacco, cigarettes and the 12-pack ("Marlboro Reds").
Draws the icons, and writes the BP items + recipe, RP attachables, item_texture entries and lang names.
The cigarette texture uses the joint's layout (stick in rows 6-7, cols 2-13; col 13 = mouth end), so the held
model is the joint's geometry.cc.stick_joint with the joint's tuned poses (incl. offhand).
Run: python cc_tools/gen_cigarettes.py [preview.png]"""
import copy, json, os, sys
from PIL import Image

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
BP = os.path.join(ROOT, "development_behavior_packs", "WKG_Realm_Pack_BP")
RP = os.path.join(ROOT, "development_resource_packs", "WKG_Realm_Pack_RP")
ITEMS = os.path.join(RP, "textures", "items")

PAPER, PAPER_D = (244, 242, 236), (214, 212, 204)
FILTER, FILTER_D, FILTER_SPECK = (214, 140, 60), (178, 108, 40), (236, 176, 96)
ASH, EMBER = (163, 165, 160), (250, 67, 11)
RED, RED_D, WHITE, BLACK = (206, 30, 36), (150, 18, 24), (244, 244, 240), (40, 36, 36)


def dried_tobacco():
    leaf = Image.open(os.path.join(ITEMS, "cc_tobacco_leaf.png")).convert("RGBA")
    px = leaf.load()
    for y in range(16):
        for x in range(16):
            r, g, b, a = px[x, y]
            if a:  # cured: golden brown instead of green
                lum = (r + g + b) / 3
                px[x, y] = (min(255, int(lum * 1.35 + 20)), int(lum * 0.95), int(lum * 0.45), a)
    return leaf


def cigarette():
    joint = Image.open(os.path.join(ITEMS, "cc_joint.png")).convert("RGBA")
    im = joint.copy()
    px = im.load()
    for y in (6, 7):
        for x in range(2, 14):
            if x == 2:
                c = ASH
            elif x == 3:
                c = EMBER
            elif x >= 11:
                c = FILTER_SPECK if (x + y) % 3 == 0 else (FILTER if y == 6 else FILTER_D)
            else:
                c = PAPER if y == 6 else PAPER_D
            px[x, y] = c + (255,)
    return im


def pack(left):
    """Red-topped box, filters poking out of the open top (`left` of 4 shown)."""
    im = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    px = im.load()
    shown = [5, 7, 9, 11][:left]  # filter tips, spaced one pixel apart
    for x in shown:
        for y in (2, 3):
            px[x, y] = (FILTER if y == 2 else FILTER_D) + (255,)
    for y in range(4, 16):
        for x in range(3, 13):
            edge = x in (3, 12) or y == 15
            if y <= 8:  # red lid with a white chevron
                c = RED_D if edge else RED
                if y >= 6 and abs(x - 7.5) <= (y - 5) * 1.6 - 1.5:
                    c = WHITE
            else:
                c = PAPER_D if edge else WHITE
                if y == 11 and 5 <= x <= 10:
                    c = BLACK  # brand line
                if y == 13 and 6 <= x <= 9:
                    c = RED
            px[x, y] = c + (255,)
    return im


def main():
    icons = {"cc_dried_tobacco": dried_tobacco(), "cc_cigarette": cigarette(),
             "cc_cigarette_pack": pack(4), "cc_cigarette_pack_s1": pack(3), "cc_cigarette_pack_s2": pack(2),
             "cc_cigarette_pack_s3": pack(1)}
    for name, im in icons.items():
        im.save(os.path.join(ITEMS, name + ".png"))

    # ---- BP items + recipe ----
    joint_item = json.load(open(os.path.join(BP, "items", "joint.json"), encoding="utf-8"))
    base_item = json.load(open(os.path.join(BP, "items", "tobacco_leaf.json"), encoding="utf-8"))

    def smokable(ident, stack, durability, menu):
        d = copy.deepcopy(joint_item)
        it = d["minecraft:item"]
        it["description"]["identifier"] = ident
        it["description"]["menu_category"] = menu
        c = it["components"]
        c["minecraft:icon"] = ident
        c["minecraft:display_name"] = {"value": f"item.{ident}.name"}
        c["minecraft:max_stack_size"] = stack
        c["minecraft:allow_off_hand"] = {"value": True}
        if durability:
            c["minecraft:durability"] = {"max_durability": durability}
            c["minecraft:use_modifiers"] = {"use_duration": 3.0, "movement_modifier": 0.4}  # packs: 3 s hit
        else:
            c.pop("minecraft:durability", None)
        return d

    smoking_menu = copy.deepcopy(joint_item["minecraft:item"]["description"]["menu_category"])
    out = {
        "cigarette": smokable("cc:cigarette", 16, 0, smoking_menu),
        "cigarette_pack": smokable("cc:cigarette_pack", 1, 12, smoking_menu),
    }
    for s in (1, 2, 3):
        out[f"cigarette_pack_s{s}"] = smokable(f"cc:cigarette_pack_s{s}", 1, 12, {"category": "none"})
    dried = copy.deepcopy(base_item)
    dried["minecraft:item"]["description"]["identifier"] = "cc:dried_tobacco"
    dried["minecraft:item"]["components"]["minecraft:icon"] = "cc:dried_tobacco"
    dried["minecraft:item"]["components"]["minecraft:display_name"] = {"value": "item.cc:dried_tobacco.name"}
    out["dried_tobacco"] = dried
    for name, d in out.items():
        with open(os.path.join(BP, "items", name + ".json"), "w", encoding="utf-8") as f:
            json.dump(d, f, indent=2)
            f.write("\n")
    recipe = {"format_version": "1.21.0", "minecraft:recipe_shapeless": {
        "description": {"identifier": "cc:recipe_cigarette"}, "tags": ["crafting_table"],
        "unlock": [{"item": "cc:dried_tobacco"}],
        "ingredients": [{"item": "cc:rolling_paper"}, {"item": "cc:dried_tobacco"}],
        "result": {"item": "cc:cigarette", "count": 2}}}
    with open(os.path.join(BP, "recipes", "cigarette.json"), "w", encoding="utf-8") as f:
        json.dump(recipe, f, indent=2)
        f.write("\n")

    # ---- RP: item textures, attachables (joint's model + poses, cigarette texture), lang ----
    it_path = os.path.join(RP, "textures", "item_texture.json")
    it = json.load(open(it_path, encoding="utf-8"))
    for name in ["dried_tobacco", "cigarette", "cigarette_pack", "cigarette_pack_s1", "cigarette_pack_s2", "cigarette_pack_s3"]:
        it["texture_data"][f"cc:{name}"] = {"textures": f"textures/items/cc_{name}"}
    json.dump(it, open(it_path, "w", encoding="utf-8"), indent=2)
    joint_att = json.load(open(os.path.join(RP, "attachables", "joint.json"), encoding="utf-8"))
    for name in ["cigarette", "cigarette_pack", "cigarette_pack_s1", "cigarette_pack_s2", "cigarette_pack_s3"]:
        a = copy.deepcopy(joint_att)
        desc = a["minecraft:attachable"]["description"]
        desc["identifier"] = f"cc:{name}"
        desc["textures"] = {"default": "textures/items/cc_cigarette", "enchanted": "textures/items/cc_cigarette"}
        with open(os.path.join(RP, "attachables", name + ".json"), "w", encoding="utf-8") as f:
            json.dump(a, f, indent=2)
            f.write("\n")
    names = {"item.cc:dried_tobacco.name": "Dried Tobacco", "item.cc:cigarette.name": "Cigarette"}
    for s in ("", "_s1", "_s2", "_s3"):
        names[f"item.cc:cigarette_pack{s}.name"] = "§cMarlboro Reds§r (12)"
    texts = os.path.join(RP, "texts")
    for f in os.listdir(texts):
        if not f.endswith(".lang"):
            continue
        path = os.path.join(texts, f)
        t = open(path, encoding="utf-8", newline="").read()
        if not t.endswith("\n"):
            t += "\n"
        for k, v in names.items():
            if k + "=" not in t:
                t += f"{k}={v}\n"
        open(path, "w", encoding="utf-8", newline="").write(t)

    if len(sys.argv) > 1:
        sheet = Image.new("RGBA", (len(icons) * 110 + 10, 120), (139, 139, 139, 255))
        for i, im in enumerate(icons.values()):
            sheet.alpha_composite(im.resize((96, 96), Image.NEAREST), (10 + i * 110, 12))
        sheet.save(sys.argv[1])
    print("tobacco products written:", ", ".join(out))


if __name__ == "__main__":
    main()
