"""3D held model for the bong (empty + 3 packed stages), matching the icon:
stepped glass beaker with water, tall neck, mouthpiece rim, downstem + bowl on the +x side.
The bowl's top shows what's in it: empty (dark hole), packed (green), half (brown), cashed (ash)."""
import json, os, random, sys
from PIL import Image

RP = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "development_resource_packs", "WKG_Realm_Pack_RP")
random.seed(7)


def wjson(path, obj):
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        json.dump(obj, f, indent=2)
        f.write("\n")


# 32x32 atlas regions (u, v, w, h)
R = {
    "glass": (0, 0, 12, 12), "water": (12, 0, 12, 12), "rim": (24, 0, 6, 6),
    "stem": (24, 6, 6, 2), "bowl_side": (24, 8, 3, 3), "bowl_top": (27, 8, 3, 3),
}
GLASS, GLASS_HI, EDGE = (222, 235, 238), (245, 250, 251), (150, 175, 180)
WATER, WATER_HI = (150, 214, 232), (190, 232, 244)
BOWL = {  # stage -> bowl contents colour
    "empty": (58, 62, 66), "packed": (40, 170, 70), "s1": (110, 72, 40), "s2": (38, 34, 32),
}


def noise(c, amt):
    r = random.randint(-amt, amt)
    return tuple(max(0, min(255, ch + r)) for ch in c) + (255,)


def fill(im, reg, c, amt=4):
    u, v, w, h = R[reg]
    for y in range(v, v + h):
        for x in range(u, u + w):
            im.putpixel((x, y), noise(c, amt))


def texture(stage):
    im = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
    fill(im, "glass", GLASS, 3)
    u, v, w, h = R["glass"]
    for y in range(v, v + h):  # glass edges + a highlight streak
        im.putpixel((u, y), EDGE + (255,))
        im.putpixel((u + w - 1, y), EDGE + (255,))
        im.putpixel((u + 2, y), GLASS_HI + (255,))
    fill(im, "water", WATER, 5)
    u, v, w, h = R["water"]
    for x in range(u, u + w):
        im.putpixel((x, v), WATER_HI + (255,))
    for y in range(v, v + h):
        im.putpixel((u, y), EDGE + (255,))
        im.putpixel((u + w - 1, y), EDGE + (255,))
        im.putpixel((u + 2, y), GLASS_HI + (255,))
    fill(im, "rim", EDGE, 4)
    fill(im, "stem", EDGE, 4)
    fill(im, "bowl_side", EDGE, 6)
    u, v, w, h = R["bowl_side"]
    for y in range(v, v + 2):  # contents visible over the bowl's rim from the side
        for x in range(u, u + w):
            im.putpixel((x, y), noise(BOWL[stage], 12))
    fill(im, "bowl_top", BOWL[stage], 12)
    return im


def cube(origin, size, reg_side, reg_top, reg_bottom=None, rotation=None, pivot=None):
    dims = {"north": (size[0], size[1]), "south": (size[0], size[1]), "east": (size[2], size[1]),
            "west": (size[2], size[1]), "up": (size[0], size[2]), "down": (size[0], size[2])}
    uv = {}
    for face, (fw, fh) in dims.items():
        reg = reg_top if face == "up" else (reg_bottom or reg_top) if face == "down" else reg_side
        u, v, w, h = R[reg]
        uv[face] = {"uv": [u, v], "uv_size": [min(fw, w), min(fh, h)]}
    c = {"origin": origin, "size": size, "uv": uv}
    if rotation:
        c["rotation"] = rotation
        c["pivot"] = pivot
    return c


CUBES = [
    cube([-6, -8, -6], [12, 2, 12], "water", "glass", "rim"),   # wide foot
    cube([-5, -6, -5], [10, 2, 10], "water", "glass"),
    cube([-4, -4, -4], [8, 2, 8], "water", "glass"),
    cube([-3, -2, -3], [6, 1, 6], "glass", "glass"),             # shoulder
    cube([-2, -1, -2], [4, 8, 4], "glass", "glass"),             # neck
    cube([-3, 7, -3], [6, 1, 6], "rim", "rim"),                  # mouthpiece rim
    cube([3, -5, -0.75], [5, 1.5, 1.5], "stem", "stem", rotation=[0, 0, 45], pivot=[3, -5, 0]),  # downstem
    cube([5.5, -1.5, -1.5], [3, 2, 3], "bowl_side", "bowl_top", "bowl_side"),                  # bowl
]

# In held-item space +y points DOWN on screen (the old flat sprite flipped its UVs to hide this),
# so mirror the bong on y (and swap up/down faces, flip side textures) to stand it upright,
# and shrink it - at full size it filled a quarter of the screen.
SCALE = 0.8


def flip_and_scale(c):
    o, s = c["origin"], c["size"]
    out = {
        "origin": [round(o[0] * SCALE, 3), round(-(o[1] + s[1]) * SCALE, 3), round(o[2] * SCALE, 3)],
        "size": [round(v * SCALE, 3) for v in s],
        "uv": {},
    }
    for face, f in c["uv"].items():
        target = {"up": "down", "down": "up"}.get(face, face)
        (u, v), (w, h) = f["uv"], f["uv_size"]
        out["uv"][target] = {"uv": [u, v + h], "uv_size": [w, -h]} if target not in ("up", "down") else dict(f)
    if "rotation" in c:
        r, pv = c["rotation"], c["pivot"]
        out["rotation"] = [r[0], r[1], -r[2]]
        out["pivot"] = [round(pv[0] * SCALE, 3), round(-pv[1] * SCALE, 3), round(pv[2] * SCALE, 3)]
    return out


CUBES = [flip_and_scale(c) for c in CUBES]

geo = {
    "format_version": "1.16.0",
    "minecraft:geometry": [{
        "description": {"identifier": "geometry.cc.bong", "texture_width": 32, "texture_height": 32,
                        "visible_bounds_width": 2, "visible_bounds_height": 2, "visible_bounds_offset": [0, 0.5, 0]},
        # Root pivot sits near the hand so the hit swings the bong in toward the mouth (designed with
        # cc_tools/pose_study/design_hit.py). Two bones (never name one after a player bone like "body" - it attached to the torso): "cc_bong_shape" holds the resting orientation ([15,-90,0], what the old idle pose used);
        # "root" is animated. Root rotates in the hand's frame, where x is the screen's left-right
        # axis, so an x rotation on root tips the bong toward/away from the camera (on the old
        # single bone it tipped sideways, because the -90 turn was applied on top).
        "bones": [
            {"name": "root", "binding": "q.item_slot_to_bone_name(context.item_slot)", "pivot": [11.0, 6.9, 2.6]},
            {"name": "cc_bong_shape", "parent": "root", "pivot": [0, 0, 0], "rotation": [20, -90, 0], "cubes": CUBES},
        ],
    }],
}
wjson(os.path.join(RP, "models", "entity", "cc_bong.geo.json"), geo)

STAGES = {"bong": "empty", "bong_packed": "packed", "bong_packed_s1": "s1", "bong_packed_s2": "s2"}
for item, stage in STAGES.items():
    tex = f"textures/items/cc_bong_model_{stage}"
    texture(stage).save(os.path.join(RP, tex + ".png"))
    path = os.path.join(RP, "attachables", f"{item}.json")
    att = json.load(open(path, encoding="utf-8"))
    d = att["minecraft:attachable"]["description"]
    d["geometry"]["default"] = "geometry.cc.bong"
    d["textures"] = {"default": tex, "enchanted": tex}
    wjson(path, att)
print("ok")
