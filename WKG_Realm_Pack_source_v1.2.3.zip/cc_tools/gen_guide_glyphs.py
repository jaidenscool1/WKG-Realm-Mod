"""Icon glyphs for the in-game guide book. Writes RP font/glyph_F4.png (16x16 grid of 16px cells; cell n shows
as the character U+F400+n in any text) and BP scripts/cc_glyphs.js (name -> character) so the guide script and the
sheet can never drift apart. Page F4 is unused by vanilla (E0/E1) and by most emoji packs (E2).
Run: python cc_tools/gen_guide_glyphs.py [preview.png]"""
import json, os, sys
from PIL import Image, ImageDraw

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, "..")
RP = os.path.join(ROOT, "development_resource_packs", "WKG_Realm_Pack_RP")
BP = os.path.join(ROOT, "development_behavior_packs", "WKG_Realm_Pack_BP")
PAGE = 0xF4
INK = (72, 58, 46, 255)  # arrows/plus: dark, the guide book page is cream
sys.path.insert(0, HERE)
import render_geo  # noqa: E402


def tex(path):
    return Image.open(os.path.join(RP, path + ".png")).convert("RGBA")


def fit(im):
    """Crop to content and fit into a 16x16 cell (nearest-neighbour, centred, bottom-aligned)."""
    box = im.getbbox()
    if box:
        im = im.crop(box)
    s = min(16 / im.width, 16 / im.height, 1.0 if im.width <= 16 and im.height <= 16 else 99)
    if im.width > 16 or im.height > 16:
        s = min(16 / im.width, 16 / im.height)
        im = im.resize((max(1, round(im.width * s)), max(1, round(im.height * s))), Image.NEAREST)
    cell = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    cell.alpha_composite(im, ((16 - im.width) // 2, 16 - im.height))
    return cell


def block_icon(geo, texture, face="south"):
    """Front view of a block model (one texel per pixel), then fit to 16x16."""
    cs, tw, th = render_geo.cubes(os.path.join(RP, "models", "blocks", geo))
    t = tex("textures/blocks/" + texture)
    im = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
    key = (lambda c: c["origin"][2]) if face == "south" else (lambda c: -c["origin"][2])
    for c in sorted(cs, key=key):
        o, s = c["origin"], c["size"]
        f = render_geo.face_img(t, c, face, tw, th, round(s[0]), round(s[1]))
        if f is None:
            continue
        x = round(16 - o[0] - s[0]) + 8 if face == "south" else round(o[0] + 16) - 8
        im.alpha_composite(f, (max(0, x), round(24 - o[1] - s[1]) + 4))
    return fit(im)


def drawn(fn):
    im = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    fn(ImageDraw.Draw(im))
    return im


def arrow_right(d):
    d.rectangle([2, 7, 11, 8], fill=INK)
    d.polygon([(10, 3), (14, 7.5), (10, 12)], fill=INK)


def arrow_down(d):
    d.rectangle([7, 2, 8, 11], fill=INK)
    d.polygon([(3, 10), (7.5, 14), (12, 10)], fill=INK)


def plus(d):
    d.rectangle([7, 3, 8, 12], fill=INK)
    d.rectangle([3, 7, 12, 8], fill=INK)


def emerald(d):
    d.polygon([(8, 2), (13, 7), (8, 14), (3, 7)], fill=(40, 190, 90, 255))
    d.polygon([(8, 2), (10, 7), (8, 14), (6, 7)], fill=(120, 240, 150, 255))


def clock(d):
    d.ellipse([2, 2, 13, 13], fill=(230, 190, 60, 255))
    d.ellipse([4, 4, 11, 11], fill=(250, 240, 200, 255))
    d.line([(7.5, 7.5), (7.5, 5)], fill=(60, 50, 30, 255))
    d.line([(7.5, 7.5), (10, 7.5)], fill=(60, 50, 30, 255))


def water(d):
    d.polygon([(8, 2), (12, 9), (4, 9)], fill=(70, 130, 240, 255))
    d.ellipse([4, 6, 12, 14], fill=(70, 130, 240, 255))
    d.point((6, 9), fill=(200, 230, 255, 255))


def star(d):
    pts = [(8, 1), (10, 6), (15, 6), (11, 9), (12.5, 14), (8, 11), (3.5, 14), (5, 9), (1, 6), (6, 6)]
    d.polygon(pts, fill=(255, 215, 60, 255))


def dried(im):
    """The bud icon recoloured drier (browner/yellower) for 'dried bud'."""
    out = im.copy(); px = out.load()
    for y in range(out.height):
        for x in range(out.width):
            r, g, b, a = px[x, y]
            if a:
                px[x, y] = (min(255, int(r * 1.15 + 30)), int(g * 0.9 + 10), int(b * 0.6), a)
    return out


def funguy_face():
    t = tex("textures/entity/cc_funguy")
    face = t.crop((8, 8, 16, 18))  # head front (8x10)
    capf = t.crop((76, 12, 88, 15))  # cap front (12x3)
    im = Image.new("RGBA", (12, 12), (0, 0, 0, 0))
    im.alpha_composite(face, (2, 2))
    im.alpha_composite(capf, (0, 0))
    return fit(im.resize((12, 12), Image.NEAREST))


def build():
    bud = tex("textures/items/cc_bud")
    plant4 = tex("textures/blocks/cc_plant_4_green")
    icons = [
        ("seed", fit(tex("textures/items/cc_seed_og_kush"))),
        ("bud", fit(bud)),
        ("dried_bud", fit(dried(bud))),
        ("paper", fit(tex("textures/items/cc_rolling_paper"))),
        ("joint", fit(tex("textures/items/cc_joint"))),
        ("blunt", fit(tex("textures/items/cc_blunt"))),
        ("bong", fit(tex("textures/items/cc_bong"))),
        ("bong_packed", fit(tex("textures/items/cc_bong_packed"))),
        ("tobacco_seeds", fit(tex("textures/items/cc_tobacco_seeds"))),
        ("tobacco_leaf", fit(tex("textures/items/cc_tobacco_leaf"))),
        ("nutrient_thc", fit(tex("textures/items/cc_nutrient_thc"))),
        ("nutrient_yield", fit(tex("textures/items/cc_nutrient_yield"))),
        ("nutrient_growth", fit(tex("textures/items/cc_nutrient_growth"))),
        ("plate_copper", fit(tex("textures/items/cc_press_plate_copper"))),
        ("plate_iron", fit(tex("textures/items/cc_press_plate_iron"))),
        ("plate_diamond", fit(tex("textures/items/cc_press_plate_diamond"))),
        ("plate_netherite", fit(tex("textures/items/cc_press_plate_netherite"))),
        ("rosin", fit(tex("textures/items/cc_rosin"))),
        ("wax", fit(tex("textures/items/cc_wax"))),
        ("shatter", fit(tex("textures/items/cc_shatter"))),
        ("live_resin", fit(tex("textures/items/cc_live_resin"))),
        ("distillate", fit(tex("textures/items/cc_distillate"))),
        ("cart_empty", fit(tex("textures/items/cc_cart_empty"))),
        ("cart", fit(tex("textures/items/cc_cart_filled"))),
        ("battery", fit(tex("textures/items/cc_vape_battery"))),
        ("vape", fit(tex("textures/items/cc_vape_pen"))),
        ("sprout", fit(tex("textures/blocks/cc_plant_0"))),
        ("young_plant", fit(tex("textures/blocks/cc_plant_2"))),
        ("flowering_plant", fit(plant4)),
        ("breeding_station", block_icon("breeding_station.geo.json", "cc_breeding_station", "south")),
        ("rolling_table", block_icon("rolling_table.geo.json", "cc_rolling_table", "north")),
        ("drying_rack", block_icon("drying_rack.geo.json", "cc_rack_drying", "north")),
        ("nug_press", block_icon("nug_press_raised.geo.json", "cc_press_2", "north")),
        ("distiller", block_icon("distiller.geo.json", "cc_distiller_1", "north")),
        ("funguy", funguy_face()),
        ("arrow", drawn(arrow_right)),
        ("down", drawn(arrow_down)),
        ("plus", drawn(plus)),
        ("emerald", drawn(emerald)),
        ("clock", drawn(clock)),
        ("water", drawn(water)),
        ("star", drawn(star)),
        # appended later - keep new icons at the end so existing characters never move
        ("dried_tobacco", fit(tex("textures/items/cc_dried_tobacco"))),
        ("cigarette", fit(tex("textures/items/cc_cigarette"))),
        ("cig_pack", fit(tex("textures/items/cc_cigarette_pack"))),
    ]
    sheet = Image.new("RGBA", (256, 256), (0, 0, 0, 0))
    mapping = {}
    for i, (name, im) in enumerate(icons):
        sheet.alpha_composite(im, ((i % 16) * 16, (i // 16) * 16))
        mapping[name] = PAGE * 256 + i
    os.makedirs(os.path.join(RP, "font"), exist_ok=True)
    sheet.save(os.path.join(RP, "font", "glyph_F4.png"))
    lines = ["// Generated by cc_tools/gen_guide_glyphs.py - do not edit. Each character draws an icon from RP font/glyph_F4.png.",
             "export const G = {"]
    lines += [f'  {k}: "\\u{v:04X}",' for k, v in mapping.items()]
    lines += ["};", ""]
    with open(os.path.join(BP, "scripts", "cc_glyphs.js"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    if len(sys.argv) > 1:
        big = Image.new("RGBA", (256 * 3, (len(icons) // 16 + 1) * 16 * 3), (60, 60, 72, 255))
        big.alpha_composite(sheet.crop((0, 0, 256, (len(icons) // 16 + 1) * 16)).resize((768, (len(icons) // 16 + 1) * 48), Image.NEAREST))
        big.save(sys.argv[1])
    print(f"{len(icons)} glyphs -> font/glyph_F4.png + scripts/cc_glyphs.js")


if __name__ == "__main__":
    build()
