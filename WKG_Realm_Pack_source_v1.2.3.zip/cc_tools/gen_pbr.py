"""Vibrant Visuals (PBR) texture sets for Cannabis Craft's metal / glass content.
For each target texture writes <name>_mer.png (R = metalness, G = emissive, B = roughness) and
<name>.texture_set.json next to it. Pixels are classified by colour:
  gray or copper-toned -> metal, pale blue/white (glass) -> smooth non-metal,
  bright orange/yellow (fire, oil, glow) -> slightly emissive, everything else -> matte.
Only affects players using Vibrant Visuals (RP manifest has "capabilities": ["pbr"]).
Run: python cc_tools/gen_pbr.py [preview.png]"""
import colorsys, json, os, sys
from PIL import Image

RP = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "development_resource_packs", "WKG_Realm_Pack_RP")
TARGETS = (
    ["textures/blocks/cc_breeding_station"]
    + [f"textures/blocks/cc_distiller_{i}" for i in range(3)]
    + [f"textures/blocks/cc_press_{i}" for i in range(5)]
    + [f"textures/items/cc_bong_model_{s}" for s in ("empty", "packed", "s1", "s2")]
    + ["textures/items/cc_vape_pen_model"] + [f"textures/items/cc_vape_pen_model_s{i}" for i in (1, 2, 3)]
)
GLASS_TEXTURES = ("cc_bong_model",)  # the whole bong body is glass


def classify(r, g, b, a, glass_body):
    if a == 0:
        return (0, 0, 255)
    h, s, v = colorsys.rgb_to_hsv(r / 255, g / 255, b / 255)
    hue = h * 360
    if v > 0.75 and s > 0.55 and 20 <= hue <= 60:
        return (0, 90, 120)  # fire / oil / glow: a little emissive
    if glass_body and s < 0.35:
        return (0, 0, 28)  # glass: smooth, not metal
    if 160 <= hue <= 200 and s > 0.35 and v > 0.7:
        return (0, 0, 30)  # diamond: smooth gem
    if s < 0.15 and 0.15 < v < 0.9:
        return (220, 0, 95)  # iron / steel / netherite / battery casing
    if 15 <= hue <= 35 and 0.35 < s < 0.8 and v < 0.85:
        return (200, 0, 80)  # copper
    if v >= 0.9 and (s < 0.06 or (170 <= hue <= 260 and s < 0.3)):
        return (0, 0, 40)  # white or blue-white: glassy highlight
    return (0, 0, 215)  # wood, paper, stone, plant, plastic: matte


def make(path):
    src = Image.open(os.path.join(RP, path + ".png")).convert("RGBA")
    glass_body = any(t in path for t in GLASS_TEXTURES)
    mer = Image.new("RGB", src.size)
    sp, mp = src.load(), mer.load()
    for y in range(src.height):
        for x in range(src.width):
            mp[x, y] = classify(*sp[x, y], glass_body)
    mer.save(os.path.join(RP, path + "_mer.png"))
    name = os.path.basename(path)
    with open(os.path.join(RP, path + ".texture_set.json"), "w", encoding="utf-8") as f:
        json.dump({"format_version": "1.16.100", "minecraft:texture_set": {
            "color": name, "metalness_emissive_roughness": name + "_mer"}}, f, indent=2)
        f.write("\n")
    return src, mer


def main():
    pairs = [make(p) for p in TARGETS]
    if len(sys.argv) > 1:  # preview: colour texture above its MER map, 4x
        w = sum(max(s.width, 32) * 4 + 8 for s, _ in pairs)
        sheet = Image.new("RGB", (w, 2 * 32 * 4 + 24), (60, 60, 70))
        x = 4
        for s, m in pairs:
            sheet.paste(s.convert("RGB").resize((s.width * 4, s.height * 4), Image.NEAREST), (x, 4))
            sheet.paste(m.resize((m.width * 4, m.height * 4), Image.NEAREST), (x, 32 * 4 + 16))
            x += max(s.width, 32) * 4 + 8
        sheet.save(sys.argv[1])
    print(f"wrote {len(pairs)} texture sets")


if __name__ == "__main__":
    main()
